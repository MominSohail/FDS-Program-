/*
 ============================================================================
 Name        : 11th.c
 Author      : SOHAIl
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include<string.h>
struct node
{
	struct node *prev;
	char data;
	struct node *next;
};

struct node *insert(struct node *head);
struct node *del(struct node *head);

void Bdisplay(struct node *head);

void display(struct node *head);
int main(void) {
	int n,i,j,ch=0;
	char st[30];
	printf("Enter Any String :");
	scanf("%s",st);
	printf("\n %s",st);
		n=strlen(st);

		struct node *head=NULL,*n_node,*p_node;

	printf("\nEach Character of string give to each node of dual linked list :");
	for(i=0;i<n;i++)
	{
		if(head==NULL)
		{
		n_node=head=(struct node*)malloc(sizeof(struct node));
		n_node->prev=NULL;
		}
		else
		{

		   n_node->next=(struct node*)malloc(sizeof(struct node));
		   p_node=n_node;
		   n_node=n_node->next;

		}
		n_node->next=NULL;
		n_node->prev=p_node;
		n_node->data=st[i];

	}
	printf("\nDoubly Linked List of given String is Created :");

	while(ch<6)
	{
	printf("\n");
		printf("\n1.Display \n2.Insertion \n3.Deletion \n4.Display Forward \n5.Display Backward\n6.Exit ");
		printf("\nEnter Which Operation u want to perform on linked List :");
		scanf("%d",&ch);
		switch(ch)
		{
		case 1:
			printf("\nYour Doubly Linked List is :");
			display(head);
			break;
		case 2:
			head=insert(head);
			break;
		case 3:
			head=del(head);
			break;
		case 4:
			printf("\nLinked List In Forward Direction:\n");
			display(head);
			break;
		case 5:
			Bdisplay(head);
			break;
		}
		}
	return EXIT_SUCCESS;
}
void display(struct node *head)
{
	struct node *p1,*p2;
	p1=p2=head;
	int i=0;
	printf("\nPosition :->");
	while(p1!=NULL)
		{
		i++;
			printf("  %d  ",i);
			p1=p1->next;
		}
	printf("\nData     :->");
	while(p2!=NULL)
	{
		printf("  %c  ",p2->data);
		p2=p2->next;
	}
}


struct node *insert(struct node *head)//function definition for insertion of new node
{
	int ch=0,pos,i=1;
	struct node *p;
	p=head;

	            struct node *n_node;
			     n_node=(struct node *)malloc(sizeof(struct node));//dynamic memory allocation for node
			     printf("\nEnter new Character for insertion:");
			     scanf("%s",&n_node->data);
			     n_node->next=NULL;
			     n_node->prev=NULL;
			     printf("\n1.At beginning \n2.At End \n3.In Between");
			     				     printf("\nEnter Proper Choice :");
			     				     scanf("%d",&ch);
	switch(ch)
		{
	case 1:                                 //for insertion from front
		n_node->next=head;
		head->prev=n_node;
		     head=n_node;

		     printf("\nNew Node Inserted At the Beginning..");
		break;
	case 2:                                 //for insertion of new node at end
		while(p->next!=NULL)
		{
			p=p->next;
		}
		p->next=n_node;
		n_node->prev=p;

	printf("\n New Node Inserted At the End");
		break;

	case 3:                               //for insertion in between

	   printf("\nEnter Position of node after Which You want to insert New Node :");
		   scanf("%d",&pos);
		   while(i<pos)
		   {
			i++;
			p=p->next;
		   }
		   n_node->next=p->next;
		   p->next=n_node;
		   n_node->prev=p;
		   printf("\nNew Node Inserted in Between of Nodes");

		break;
		}

	return head;
}



struct node *del(struct node *head)//function for Deletion of Node
{
	if(head==NULL)//check for empty
	{
		printf("List Is Empty...");
		return head;
	}
	struct node *p,*p1;

  p=head;

	int n,pos,i=0,f=0;
	while(p!=NULL)
			{
			i++;
				p=p->next;
			}
	n=i;
	while(f==0)
	{
		f=1;
	printf("\nEnter position of node you want to Delete :");
	scanf("%d",&pos);
	if(pos>n)//check for valid position
	{
		f=0;
		printf("Invalid position");
	}
	else
	{
	        if(pos==1)//delete from front
	          {
		         printf("\nYou are Deleting First Node (Delete from front)");
		         p=head;
		          head=p->next;
		          head->prev=NULL;
		          free(p);
		  printf("\nFist Node is Deleted..");
	          }
	         else if(pos==n)//delete from end
	         {
		         printf("\nYou are Deleting Last Element of Linked list ");
		         p=head;

		         while(p->next!=NULL)
		         {

		        	 p=p->next;
		         }
		         p=p->prev;
		         p->next=NULL;
		   //free(p);
		   printf("\nLast Node is Deleted ");
	          }
	         else if(pos>1 && pos<n)//delete from middle
	         {
	        	 p=head;
	        	 i=1;
	        	 while(i<pos)
	        	 {
	        		 i++;
	        		 p1=p;
	        		 p=p->next;
	        	 }
	        	 p->prev=p1;
	        	 p1->next=p;

	        	 p->prev=p;
	        	// free(p);
	        	 printf("\nNode Deleted From middle");
	         }
	}
	}
	return head;
}

void Bdisplay(struct node *head)
{
	struct node *p1,*p2;
	p1=p2=head;
	int i=0,n;
	printf("\nPosition :->");
	 do
		{
		i++;

			p1=p1->next;
		}while(p1->next!=NULL);
	 n=i;
	    for(i=n;i>=1;i--)
	    {
	 	   printf("  %d  ",i);
	    }
	printf("\nData     :->");

	do
	{

		printf("  %c  ",p1->data);
		p1=p1->prev;
		n--;
	}while(p1!=NULL);
}
