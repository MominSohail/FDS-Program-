/* ================================================================================
Assignment no-01
Title          : Implement following set operations using arrays.
								a) Union
								b) Intersection
								c) Difference
								d) Symmetric difference.
Author      : SOHAIL MOMIN
Roll no      : 2074
Class				 : SE
Division		 : I10
Batch				 : H10
 ================================================================================*/


#include <stdio.h>
#include <stdlib.h>

//prototype declaration...
int display(int a[30],int n);
int un(int a[15], int b[15],int U[30], int m, int n);
int intersection(int a[15],int b[15],int I[30],int m,int n);
int diff(int a[15],int b[15],int Dk[15],int m,int n);
int  symm(int DA[15],int DB[15],int x,int y,int sy[15]);

int main(void) {
//arrays and variables declaration
int A[15],B[15],U[30],I[30],DA[30],DB[15],S[30],sy[15];
int i,c,m,n,z,k,da,db,sd;

do  //taking size od set A
{
printf("Enter How many Elements You have of FIRST set :");
scanf("%d",&n);
  if(n>15)
  {
	  printf("your set must be less than 16 elements because of Array Size :\n ");
	  printf("\n Re-enter: \n ");

  }
}while(n>15);
do //taking size of B
{
printf("Enter How many Elements You have of SECOND set :");
scanf("%d",&m);
  if(m>15)
  {
	  printf("your set must be less than 16 elements because of Array Size :\n ");
	  printf("\n Re-enter: \n ");

  }
}while(m>15);
//Taking elements of sets from user
printf("Enter %d Elements of FIRST Set:",n);
for(i=0;i<n;i++)
{
	scanf("%d",&A[i]);
}
printf("Enter %d Elements of SECOND Set:",m);
for(i=0;i<m;i++)
{
	scanf("%d",&B[i]);
}

//display of set given by user
printf("\n Your FIRST set A =");
display(A,n);

printf("\n Your SECOND set B =");
display(B,m);

do//for menu
{
	printf("\n 1.Union \n 2.Intersection \n 3.Difference \n 4.Symmetric_Difference \n 5.Exit\n ");
	printf("Enter Your Choice :\n ");
	scanf("%d",&c);
	switch(c)
	{
	case 1:
         z=un(A,B,U,n,m);
         printf("\n Your Union Set Of given two A & B set is : \n");
         printf("A UNION B= ",display(U,z));
         break;
	case 2:
    k=intersection(A,B,I,n,m);
    printf("Your InterSection Set Of given two A & B set is : \n");
            printf("A INTERSECTION B = ",display(I,k));
		break;
	case 3:
		   da=diff(A,B,DA,n,m);
		   printf("\n A-B : ",display(DA,da));

		   db=diff(B,A,DB,m,n);
		  		   printf("\n B-A : ",display(DB,db));

		break;
	case 4:
		  sd=symm(DA,DB,da,db,sy);
		  printf("Your Symmetric_Difference Set Of given two A & B set is : ",display(sy,sd));
		              ;\
		  		break;
	case 5:
		return 0;
		break;
	}

}while(c!=5);




	return EXIT_SUCCESS;
}

int display(int a[15],int n)//function definition for Display Set
{
 int i=0;
	printf("{%d",a[0]);
	for(i=1;i<n;i++){
		printf(", ""%d",a[i]);
	}
	printf("}");
return 0;

}
int un(int a[15], int b[15],int U[30], int m, int n)///function definition for Union
{
	int i=1,j=0,s,k,f;
	s=m+n;
	U[0]=a[0];
	while(i<s)//up to limite of union
	{
		while(j<n)
		{
			for(k=0;k<i;k++)//check for duplication
			{
				f=0;
		if(U[k]==a[j])
		{
			j++;
			s--;
			f=11;;

		}
			}
			if(f==0)//if no duplicate insert in union set
			{
		U[i]=a[j];
		j++;
		i++;
			}
		}
		j=0;
		while(j<m)
				{
					for(k=0;k<i;k++)//check for duplication
					{
						f=0;
				if(U[k]==b[j])
				{
					j++;
					s--;
					f=1;

				}
					}
					if(f==0)//if no duplicate insert in union set
					{
				U[i]=b[j];
				j++;
				i++;
					}
				}
   }

	return i;//size union set
}

int intersection(int a[15],int b[15],int I[30],int m,int n)//function definition for finding  Intersection
{

	int i,j,k=0;
		  for(i=0;i<m;i++)
		  {
			  for(j=0;j<n;j++)
			  {
					  if(a[i]==b[j])
					  {
					   I[k]=a[i];
					   k++;
					  }
			  }
		  }
		  return k;
}
int diff(int a[15],int b[15],int Dk[15],int m,int n)//function definition for finding difference
{
	int i,j,k;
		  for(i=0,k=0;i<m;i++)
		  {
			  for(j=0;j<n;j++)
			  {
				  if(a[i]==b[j])
					  break;
			  }
			  if(j==n)
			  {
				  Dk[k]=a[i];
				  k++;
			  }
		  }
		  return k;
}
int  symm(int DA[15],int DB[15],int x,int y,int sy[15])//function definition for symmetric difference
{

	int zz=un(DA,DB,sy,x,y);
	return zz;
}
