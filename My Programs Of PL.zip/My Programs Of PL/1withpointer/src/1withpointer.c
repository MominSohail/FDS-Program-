/*
 ============================================================================
 Name        : 1withpointer.c
 Author      : SOHAIL
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

void create(int *ptrA,int *a);
void display(int *ptrA,int *a);
int un(int *ptrA,int *ptrB,int *a,int *b,int *ptrU);
int inter(int *ptrA,int *ptrB,int *a,int *b,int *ptrI);
int diff(int *ptrA,int *ptrB,int *a,int *b,int *ptrD);
int symm(int *ptrDa,int *ptrDb,int *ptrnda,int *ptrndb,int *ptrsy);

int main(void) {
	int A[20],B[20],U[40],I[20],Da[20],Db[20],sy[20];
	int n,m,ch=0,ne,ni,nda,ndb,ns;

	do{
	printf("\nEnter total number of elements of FIRST set A :");
	scanf("%d",&n);

	if(n>20)
	{
		printf("size is OutOffBound Re Enter:");
	}
	}while(n>20);

	printf("Enter elements of set A :");
	create(&A[0],&n);

	printf("Your set A is :\n ");
	  display(&A[0],&n);
	 do
	 {
	  printf("\nEnter total number of elements of Second set B:");
	  scanf("%d",&m);

		  if(m>20)
			  printf("\nSize is OutOff Bound Re Enter :");
	  }while(m>20);

	 printf("\nEnter Elements of Second set B:");
            create(&B[0],&m);
	 printf("Your Second set B is :\n");
	   display(&B[0],&m);

	   while(ch<6)
	   {
		   printf("\n1.Union \n2.Intersection \n3.Difference \n4.symmetric Difference \n5.exit");
	       printf("\nEnter your choice :");
		   scanf("%d",&ch);
		   switch(ch)
		   {
		   case 1:
	             ne=un(&A[0],&B[0],&n,&m,&U[0]);
	             printf("\nUnion of Set A & B is :\n");
	             display(&U[0],&ne);
			   break;
		   case 2:
			   ni=inter(&A[0],&B[0],&n,&m,&I[0]);
			   printf("Intersection of A & B is :");
			   display(&I[0],&ni);
			   break;
		   case 3:
			   nda=diff(&A[0],&B[0],&n,&m,&Da[0]);
			   printf("\nDifference of (A -B)= ");
			   display(&Da[0],&nda);

			   ndb=diff(&B[0],&A[0],&m,&n,&Db[0]);
			    printf("\nDifference of (B-A)= ");
			     display(&Db[0],&ndb);
			   break;
		   case 4:

			   ns=symm(&Da,&Db,&nda,&ndb,&sy[0]);
			   printf("\nSymmetric difference 0f A & B : ");
			   display(&sy[0],&ns);
			   break;
		   }
	   }

	return EXIT_SUCCESS;
}
void create(int *ptrA,int *a)
{
	int i;
	for(i=0;i<*a;i++)
	{
		scanf("%d",&*ptrA);
		ptrA++;
	}
}
void display(int *ptrA,int *a)

{int i;
  printf("{%d",*ptrA);
  ptrA++;
    for(i=1;i<*a;i++)
    {
    	printf(",%d",*ptrA);
    	ptrA++;
    }
    printf("}");
}

int un(int *ptrA,int *ptrB,int *a,int *b,int *ptrU)
{
	int n,f=0,j=0,i,t=1;
	n=*a+*b;
	int *temp;
	temp=ptrU;
	*ptrU=*ptrA;
	ptrA++;


	while(t<n)
	{
		while(j<*a)
		{
			ptrU=temp;
			f=0;
			for(i=0;i<t;i++)
			{

				if(*ptrU==*ptrA)
				{
					f=1;
					ptrU++;
					ptrA++;
					j++;
					n--;
					break;
				}
				ptrU++;
			}
				if(f==0)
				{
					//ptrU++;
					*ptrU=*ptrA;
				    j++;
					t++;
				}

		}
		j=0;
		while(j<*b)
		{
			ptrU=temp;
			f=0;
			for(i=0;i<t;i++)
			{

				if(*ptrU==*ptrB)
				{
					f=1;
					ptrB++;
					ptrU++;
					n--;
					j++;
					break;

				}
				ptrU++;
			}
				if(f==0)
				{
					*ptrU=*ptrB;

					ptrB++;
					t++;
					j++;
				}

		}
	}
	return t;
}
int inter(int *ptrA,int *ptrB,int *a,int *b,int *ptrI)
{
	int n=0;
	int i,j;
	int *temp;
	temp=ptrB;
	for(i=0;i<*a;i++)
	{
		ptrB=temp;
		for(j=0;j<*b;j++)
		{
			if(*ptrA==*ptrB)
			{

				*ptrI=*ptrA;

				ptrI++;
				n++;
				break;
			}
			ptrB++;
		}
		ptrA++;
	}
	return n;
}

int diff(int *ptrA,int *ptrB,int *a,int *b,int *ptrD)
{
	int n;
	int *temp;
	temp=ptrB;
	int i,j;
	for(i=0;i<*a;i++)
	{
		ptrB=temp;
		for(j=0;j<*b;j++)
		{
			if(*ptrA==*ptrB)
			{
				ptrB++;
				break;
			}

			ptrB++;
		}
		if(j==*b)
		{
			*ptrD=*ptrA;

			ptrD++;

		n++;
		}
		ptrA++;
	}

	return n;
}
int symm(int *ptrDa,int *ptrDb,int *ptrnda,int *ptrndb,int *ptrsy)
{
	int n;
	n=un(ptrDa,ptrDb,ptrnda,ptrndb,ptrsy);
	return n;
}
