/*
 ============================================================================
 Name        : 3red.c
 Author      : SOHAIL
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>


int len(char stp[]);
void rev(char stp[],char str[]);
void copy(char stp[],char cst[]);
void display(char stp[]);
int comp(char st1[],char st2[]);
int palin(char stp[]);
int substring(char a[],char b[]);

int main(void) {
	int ch=0,l,di,pl,sub;
	char st[80],str[80],cst[80],sts[80];
	printf("Enter Any String :");
	scanf("%s",st);
	while(ch<7)
	{       printf("\n");
		    printf("\nWhat u want to do with this String.......????\n");
			printf("1.LENGTH\n2.REVERSE\n3.COPY\n4.COMPARE\n");
			printf("5.PALINDROME\n6.SUBSTRING\n7.EXIT\n");
			printf("enter your choice\n");
			scanf("%d",&ch);
			switch(ch)
			{
			case 1:
				 l= len(st);
				 printf("Length of given String is %d ",l);
		    	break;
			case 2:
				printf("your String After Reversing it : ");
				rev(st,str);
				display(str);
				break;
			case 3:
				copy(st,cst);
				printf("Your String %s copied on second variable which is :",st);
				display(cst);
				break;
			case 4:
				printf("Enter another String to whom u want to compare  firstly given string:");
				scanf("%s",sts);
				di=comp(st,sts);
				if(di==0)
			     printf("the two strings are equal\n" );
				else if(di>0)
				 printf("the string '%s' is alphabetically bigger than string '%s'\n",st,sts);
				else
				 printf("the string '%s' is alphabetically bigger than '%s'\n",sts,st);

				break;
			case 5:
				          pl=palin(st);
				          if(pl!=0)
				          printf("the string '%s' is a palindrome",st);
				          else
				          printf("the string '%s' is not a palindrome",st);
				break;
			case 6:

			printf("Enter another String to whom u want to check Substring firstly given string:");
			scanf("%s",sts);
				 sub=substring(st,sts);
				if(sub==0)
			       printf("%s is a substring",sts);
			   else
					printf("%s is a not a substring",sts);

				break;
			case 7:
				return 0;
				break;
			}
	      }
	return EXIT_SUCCESS;
}

int len(char stp[80])
{
	int i;
	while(stp[i]!='\0')
	{
		i++;
	}
	return i;
}

void rev(char stp[80],char str[80])
{
	int l,i,j=0;

	l=len(stp);
	for(i=l-1;i>=0;i--)
	{
		str[j]=stp[i];
		j++;


	}
	str[j]='\0';
}
void copy(char stp[],char cst[])
{
	int i=0,l=0;
	l=len(stp);
	while(i<l)
	{
		cst[i]=stp[i];
	i++;
	}
	cst[i]='\0';
}
void display(char stp[])
{
	puts(stp);
}
int comp(char st1[],char st2[])
{
	int l,i=0,d;
	if(len(st1)>len(st2))
	   l=len(st1);
	else
		l=len(st2);
	while(l!=0)
	{
		if(st1[i]!=st2[i])
		{
			d=st1[i]-st2[i];
			break;
		}
		else
		{
			l--;
			i++;
		}

	}
	return d;
}

int palin(char stp[])
{
	char str[80];
	rev(stp,str);

	int i=0,j=0;
	while(stp[i]!='\0')
	{
		if(stp[i]!=str[j])
		{
			return 0;
		}
		i++;
		j++;
	}
  return 1;

}


int substring(char a[],char b[])
{
	int i,j,c,d;
	char temp[80];
	for(i=0;i<len(a);i++)
	{
		c=0,d=1;
		for(j=i;j<(i+len(b));j++)
					temp[c++]=a[j];
		temp[c]='\0';
		d=comp(temp,b); // compare
		if(d==0)
			break;
	}
	return d;
}

