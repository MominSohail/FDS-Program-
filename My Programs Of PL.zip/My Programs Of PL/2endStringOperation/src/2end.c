/*
 ============================================================================
 Name        : Matrix.c
 Author      : SOHAIL
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

void input(int a[10][10],int r,int c);
void display(int a[10][10],int r,int c);
void add(int a[10][10],int b[10][10],int re[10][10],int r,int c);
void mul(int a[10][10],int b[10][10],int re[10][10],int r,int c);
void tras(int a[10][10],int re[10][10],int r,int c);

int main(void) {
int A[10][10],B[10][10],C[10][10];
int r1,c1,ch=0;

printf("Enter Number of rows And Columns of your Matrix  :");
scanf("%d %d",&r1,&c1);

printf("we have %d * %d Matrix on which we perform Matrix operation...",r1,c1);
printf("\nEnter Elements your FRIST Matrix Row vice :");
input(A,r1,c1);
printf("Your FIRST A Matrix = \n");
   display(A,r1,c1);
printf("Enter Elements of your SECOND Matrix Row vice :");
input(B,r1,c1);
printf("Your First SECOND B Matrix = \n");
   display(B,r1,c1);

   while(ch<4)
   {
	   printf("1.Addition of Matrix \n 2.Multiplication of Matrix \n 3.Transpose of Matrix \n 4.Exit");
	   printf("\n Enter your choice: ");
	   scanf("%d",&ch);
	   switch (ch)
	   {
	   case 1:
		     add(A,B,C,r1,c1);
		     printf("Addition of A and B Matrix =\n");
		     display(C,r1,c1);
		   break;
	   case 2:
		   mul(A,B,C,r1,c1);
		  		   printf("Multiplication of matrix of A and B Matrix =\n");
		  		   		     display(C,r1,c1);
	   		   break;
	   case 3:
            trans(A,C,r1,c1);
            printf("Your Transpose of Matrix A :\n");
            display(C,r1,c1);
            trans(B,C,r1,c1);
                    printf("Your Transpose of Matrix B :\n");
                    display(B,r1,c1);
	   		   break;
	   case 4:
		   return 0;
	   		   break;
	   }
   }

	return EXIT_SUCCESS;
}
 void input(int a[10][10],int r,int c)
 {
	 int i,j;

	 for(i=0;i<r;i++)
	 {
		 for(j=0;j<c;j++)
		 {
			 scanf("%d",&a[i][j]);
		 }
	 }
 }

 void display(int a[10][10],int r,int c)
 {
	 int i,j;
	 for(i=0;i<r;i++)
		 {
			 for(j=0;j<c;j++)
			 {
				 printf("%d\t",a[i][j]);
			 }
			 printf("\n");
		 }
 }

 void add(int a[10][10],int b[10][10],int re[10][10],int r,int c)
 {
	 int i,j;

		 for(i=0;i<r;i++)
		 {
			 for(j=0;j<c;j++)
			 {
				 re[i][j]=a[i][j]+b[i][j];
			 }
		 }
 }

 void mul(int a[10][10],int b[10][10],int re[10][10],int r,int c)
 {
	 int i,j,k,sum=0;

			 for(i=0;i<r;i++)
			 {
				 for(j=0;j<c;j++)
				 {
					 sum=0;
					 for(k=0;k<c;k++)
					 {
					  sum=sum+a[i][k]*b[k][j];
					            re[i][j]=sum;
					 }
				 }
			 }

 }
 void trans(int a[10][10],int re[10][10],int r,int c)
 {
	 int i,j;

	 		 for(i=0;i<r;i++)
	 		 {
	 			 for(j=0;j<c;j++)
	 			 {
	 				 re[i][j]=a[j][i];

	 			 }
	 		 }

 }
