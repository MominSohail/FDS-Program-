#include <stdio.h>

struct student
	{
		int roll;
		char name[20];
		int mobile;
		char email[20];

	};
struct student create(void);
void display(struct student s);
int modify(struct student St[100], int r);
int del(struct student St[100], int r);

int main(void) {
	int r,i,c=0,sr,f=0,flag=0;
	struct student St[100];
while(c<7)
{
   printf("\n Enter Proper Choice :");
   printf("\n1.Create student \n 2.Display \n 3.Add New student \n 4.Search student \n 5.Modify student \n 6.Delete student \n 7.Exit \n");
   scanf("%d",&c);

   switch(c)
    {
     case 1:
    	 if(flag==0)
    	 {
            printf("how many students you have :");
	    scanf("%d",&r);
	    for(i=0;i<r;i++)
	    {
       St[i]=create();
	    }
       printf("\n student Created");
    	 }
    	 else{
    		 printf("\n DataBase Was Created ....if u want to enter records Please choose Modify option......!!!! \n");
    	 }
     break;

    case 2:
    	printf("your student Record: \n");
        printf("Roll_No  NAME  Mobile_Number  Email ");
    	for(i=0;i<r;i++){
        display (St[i]);
    	}
     break;

    case 3:
    	  printf("\n U want to enter new Record :");
    	  St[r]=create();
    	  r++;
    	break;
    case 4:
    	printf("\n Enter Roll Number of student u want to search :");
    	 scanf("%d",&sr);
    	 for(i=0;i<r;i++)
    	{
    	  if(St[i].roll==sr)
    	{
    		  printf("\n Ur search Record :\n");
    		  printf("Roll_No  NAME  Mobile_Number  Email ");
    	           f=1;
              display (St[i]);
    	}
    	}
    	  if(f==0)
    	{
    	printf("student Not Found,.....!!!");
    	}
    	break;

    case 5:
    	    	  modify(St,r);
    	break;
    case 6:
    	 r= del(St,r);
    	break;
   case 7:
      return(0);
     break;
    default :
    printf("\n Please Enter Proper Choice....!!");
    }
}
return 0;
}
struct student create()
{
       struct student S;

			printf("Enter roll_number of student :");
			scanf("%d",&S.roll);
			printf("Enter Name of student :");
			scanf("%s",S.name);
			printf("Enter mobile number of student :");
			scanf("%d",&S.mobile);
			printf("Enter Email of student :");
			scanf("%s",S.email);
                  

          return S;
}


void display(struct student s)
{

	struct student S;
	S=s;
		printf("\n %d  %s  %d  %s \n",S.roll,S.name,S.mobile,S.email);


}

int modify(struct student St[100], int r)
{
	int i,sr,fs;
	printf("\n Enter Roll number of Record U want to Modify :\n");
	    	scanf("%d",&sr);
	    	 for(i=0;i<r;i++)
	    	    	{
	    	    	  if(St[i].roll==sr)
	    	    	{
	    	    		  printf("\n Please Modify This Record...\n");
	    	    		  printf("Roll_No  NAME  Mobile_Number  Email ");
	    	    	           fs=1;
	    	              display (St[i]);
	    	              St[i]=create();
	    	              printf("Your Record Modified Succefully......!!!");
	    	    	}
	    	    	}
	    	    	  if(fs==0)
	    	    	{
	    	    	printf("student Not Found,.....!!!");
	    	    	}
	    	    	  return 0;

}

int del(struct student St[100], int r)
{
	int i,d,f=0;
	printf("\n Enter Roll number of Record U want to DELETE :\n");
	    	scanf("%d",&d);
	    	 for(i=0;i<r;i++)
	    	    	{
	    	    	  if(St[i].roll==d)
	    	    	{
	    	    		f++;

	    	    		  while(i!=(r-1))
	    	    		 {
                           St[i]=St[i+1];
                           i++;
	    	    		 }

	    	    		  r--;
	    	    		 printf("\\n Your Record is Deleted....!");
	    	    	}
	    	    	}
	    	    	  if(f==0)
	    	    	{
	    	    	printf("\n student's record Not Found,.....!!!");
	    	    	}
                   return r;
}
