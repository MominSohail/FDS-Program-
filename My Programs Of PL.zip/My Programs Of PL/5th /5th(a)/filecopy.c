/* ================================================================================
Assignment no-05
Title          :a) Write C program to implement TYPE and COPY commands
                   of DOS using command line arguments.
                b) Find out number of characters, words, spaces and sentences
                   from a file and write result in another file
Author      : SOHAIL MOMIN
Roll no      : 2074
Class				 : SE
Division		 : I10
Batch				 : H10
 ================================================================================*/



#include<stdio.h>

int main(int argc, char *argv[])
{
    FILE *fp,*fp1;
int i,n;
printf("Number of Arguments Are =%d ",argc);
for(i=0;i<3;i++)
{
    printf("\n %s",argv[i]);
}


printf("Enter Proper Choice : ");
printf("\n 1.Copy \n 2.Type \n 3.exit \n");// type command display content of file
scanf("%d",&n);

switch(n)
{
  case 1:

  fp=fopen(argv[1],"r");
if(fp==NULL)
	{
		puts("unable to Open file...");
		return 0;
	}
  fp1=fopen(argv[2],"w");
if(fp1==NULL)
	{
		puts("unable to Open file...");
		return 0;
	}
 char c;
  while((c=fgetc(fp))!= EOF)
{
     fputc(c,fp1);
}
printf("File Copied!");
fclose(fp);
fclose(fp1);
   break;
case 2:
fp1=fopen(argv[2],"r");
if(fp1==NULL)
	{
		puts("unable to Open file...");
		return 0;
	}
printf("Your Type Command output: \n");
  while((c=fgetc(fp1))!= EOF)
{

    printf(" %c",c);
}
  break;
case 3:
return 0;
break;
}

return 0;
}


/*
->for run this program first we have to create source file(as src.txt) on current directory  .....
->then after to compile this file 'gcc filecopy.c' 
-> to run  './a.out src.txt copied.txt'
*/


/*-----------------------------OUTPUT---------------*/

 sorce file is destop and also .c file
momin@momin-Lenovo-Z50-70:~$ cd
momin@momin-Lenovo-Z50-70:~$ cd Desktop
momin@momin-Lenovo-Z50-70:~/Desktop$ gcc filecopy.c
momin@momin-Lenovo-Z50-70:~/Desktop$ ./a.out src.txt copied.txt
Number of Arguments Are =3 
 ./a.out
 src.txt
 copied.txtEnter Proper Choice : 
 1.Copy 
 2.Type 
 3.exit 
1
File Copied!momin@momin-Lenovo-Z50-70:~/Desktop$ ./a.out src.txt copied.txt
Number of Arguments Are =3 
 ./a.out
 src.txt
 copied.txtEnter Proper Choice : 
 1.Copy 
 2.Type 
 3.exit 
2
Your Type Command output: 
 H e l l o ,   M y s e l f     S o h a i l   M o m i n . . . .

