/*
->for run this program first we have to create source file(as src.txt) on current directory  .....
->then after to compile this file 'gcc filecopy.c' 
-> to run  './a.out src.txt copied.txt'
*/



#include<stdio.h>

int main(int argc, char *argv[])
{
    FILE *fp,*fp1;
int i,n;
printf("Number of Arguments Are =%d ",argc);
for(i=0;i<3;i++)
{
    printf("\n %s",argv[i]);
}


printf("Enter Proper Choice : ");
printf("\n 1.Copy \n 2.Type \n 3.exit \n");// type command display content of file
scanf("%d",&n);

switch(n)
{
  case 1:

  fp=fopen(argv[1],"r");
if(fp==NULL)
	{
		puts("unable to Open file...");
		return 0;
	}
  fp1=fopen(argv[2],"w");
if(fp1==NULL)
	{
		puts("unable to Open file...");
		return 0;
	}
 char c;
  while((c=fgetc(fp))!= EOF)
{
     fputc(c,fp1);
}
printf("File Copied!");
fclose(fp);
fclose(fp1);
   break;
case 2:
fp1=fopen(argv[2],"r");
if(fp1==NULL)
	{
		puts("unable to Open file...");
		return 0;
	}
printf("Your Type Command output: \n");
  while((c=fgetc(fp1))!= EOF)
{

    printf(" %c",c);
}
  break;
case 3:
return 0;
break;
}

return 0;
}
