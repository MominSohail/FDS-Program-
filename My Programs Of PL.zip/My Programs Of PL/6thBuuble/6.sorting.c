/*
 * sort.c
 *
 *  Created on: 25-Aug-2015
 *  Vaibhav Lohani
 *  SE - 10
 *  2048
 */

# include <stdio.h>
#include <string.h>

# define max 50


typedef struct
{
    char name[30];
    int rollno;
    float perc;

} student ;

void input(student[],int*);
void bubble_sort(student[],int);
void selection_sort(student[],int);
void searchroll(student[],int);
void displayrecord(student);

void main()
{
	student a[max];
	int i,n;
	char choice;

	input(a,&n);

	do
	{
		printf("\nWhich operation you want to perform ");
		printf("\n1. Display the data in ascending order of name (Bubble Sort) ");
		printf("\n2. Display the data in descending order of name(Selection sort)");
		printf("\n3. Display data for RollNo specified by user (Binary search -  Input should be sorted in ascending order of roll number )");
		printf("\n4. Exit");
		printf("\nPlease give the number of your choice ");
		scanf("%d",&i);
		switch(i)
		{
			 case 1:  bubble_sort(a,n);
					  break;

			 case 2:  selection_sort(a,n);
					  break;

			 case 3:  searchroll(a,n);
					  break;

			 case 4:  exit(0);
					  break;

			 default : printf("\nWrong input !!!!!!!!!! Please try again");
		}

		printf("\nDon you want to perforn some other operation ");
		scanf("%s",&choice);

	} while(choice == 'y' || choice == 'Y');

}

void input(student a[],int*n)
{
	int i,rno;
	float perc;
	char name[30],ch;
	printf("\nPlease Enter the input");
	printf("\nEnter the number of students ");
	scanf("%d",n);

	if(*(n) >  max)
	{
		printf("Maximum limit is  :  %d",max);
		input(a,n);
	}
	for(i=0 ; i < (*n) ; i++)
	{
		printf("Enter the details of student  %d",i+1);   // taking input details of record
		printf("\n\nEnter Roll number ");
		scanf("%d",&rno);
		while ((ch = getchar()) != '\n' && ch != EOF);
		printf("Enter Name ");
		gets(name);
		printf("Enter Percentage ");
		scanf("%f",&perc);

		a[i].rollno = rno;
		a[i].perc = perc;
		strcpy(a[i].name , name);
	}

}	// end of input function


void bubble_sort(student a[],int n)
{
	int i,j,complexity = 0;
	student s[max],temp;

	for(i=0 ; i<max ; i++)
		s[i] = a[i] ;


	for(i=0 ; i < (n-1) ; i++)
	{
		complexity ++ ;
		for(j=0 ; j < (n-i-1) ; j++)
		{
			complexity ++ ;
			if (strcmp(s[j].name,s[j+1].name)  > 0)

			{
				temp = s[j];
				s[j] = s[j+1];
				s[j+1] = temp;
			}

		}


		printf("\nAfter pass  %d , names are as ",i+1);
		for(j=0 ; j<n ; j++)
			printf("      %s",s[j].name);
	}

	printf("\nThe sorted Database is as follows : ");
	for(i=0 ; i<n ; i++)
		displayrecord(s[i]);

	printf("\nTime Complexity : O(%d)",complexity);

} // end of function bubble

void selection_sort(student a[],int n )
{
	 int i,j,maxindex,complexity=0;
	 student s[50],temp;

	 for(i=0 ; i<n ; i++)
		 s[i] = a[i];

	 for(i=0 ; i < (n-1) ; i++)
	 {
		 complexity++;
		 maxindex = i ;

		 for(j=i+1 ; j<n ; j++)
		 {
			 complexity++;
			 if( strcmp(s[j].name,s[maxindex].name) > 0)
				 maxindex = j;
		 }

		 if(maxindex != i)
		 {
			 temp = s[i];
			 s[i] = s[maxindex];
			 s[maxindex] = temp;
		 }

		 printf("\nAfter pass  %d , names are as ",i+1);
		 for(j=0 ; j<n ; j++)
			 printf("      %s",s[j].name);
	 }

	 printf("\nThe sorted Database is as follows : ");
	 for(i=0 ; i<n ; i++)
		 displayrecord(s[i]);

	 printf("\nTime Complexity : O(%d)",complexity);



} // end of selection sort function

void searchroll(student a[],int n)
{
	int rno,low,high,mid,pos;
	int complexity = 0;

	printf("\nEnter Roll number to be searched for ");
	scanf("%d",&rno);

	low = 0;
	high = n-1;

	while(low <= high)
	{
		complexity++ ;
		mid = (low+high)/2 ;

		if(rno == a[mid].rollno)
		{
			pos = mid;
			break;
		}

		else if (rno < a[mid].rollno)
			high = mid-1;

		else if (rno > a[mid].rollno)
			low = mid+1;
	 }

	printf("\nThe searched record was found at location  %d",pos+1);
	displayrecord(a[pos]);
	printf("\nTime Complexity :  %d",complexity);

} // end of binary search function

void displayrecord(student s)    // To display records
{
	printf("\n Roll Number :  %d",s.rollno);
	printf("\n Name :  %s",s.name);
	printf("\n Percentage :  %f",s.perc);
}
