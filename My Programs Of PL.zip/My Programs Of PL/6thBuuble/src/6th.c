#include <stdio.h>

struct student
	{
		int roll;
		char name[20];
		int mobile;
		char email[20];

	};
void create(struct student s[100],int r);
void display(struct student s);
void bubble(struct student St[100],int r);
void dis(struct student St[100],int r);


int main(void) {
	int r,i,c=0,sr,f=0;
	struct student St[100];

	printf("how many Records of  students you have :");
    scanf("%d",&r);

	       create(St,r);
	       printf("\n student Created");
	    printf("Your Students Record :\n ");
	    printf("Roll_No  NAME  Mobile_Number  Email ");
            for(i=0;i<r;i++)
           {
    	 display(St[i]);
           }



while(c<7)
{
   printf("\n Enter Proper Choice :");
   printf("\n1.Bubble Sort \n 2.descending order(Selection Sort) \n 5.Binary Search \n 6.Delete student \n 7.Exit \n");
   scanf("%d",&c);

   switch(c)
    {
     case 1:
    	 bubble(St,r);
     break;

    case 2:

    	dis(St,r);
    	printf("your student Record After Selection Sort : \n");

    	for(i=0;i<r;i++){
        display (St[i]);
    	}
     break;

    case 3:


    	break;
    case 4:

      dis(St,r);

    	break;


    case 5:

    	break;
    case 6:

    	break;
   case 7:
      return(0);
     break;
    default :
    printf("\n Please Enter Proper Choice....!!");
    }
}
return 0;
}
void create(struct student S[100],int r)
{
       int i,ro,j,f=0,no;
       for(i=0;i<r;i++)
       {
    	   f=0;
              while(f==0)//validation for unique roll number
                 {
            	  f=1;
            	  j=0;
			       printf("Enter roll_number of student :");
			       scanf("%d",&ro);
			       while(j<=i)
			       {
			        if(ro==S[j].roll)
		       	     {
				     f=0;
			         }
			       j++;
			        }
			       if(f==0)
			    	   printf("Roll number can not be equal...please re-enter..");
                }
              if(f==1)
              {
            S[i].roll=ro;
			printf("Enter Name of student :");
			scanf("%s",S[i].name);
			printf("Enter mobile number of student :");
			scanf("%d",&S[i].mobile);
			printf("Enter Email of student :");
			scanf("%s",S[i].email);

              }
       }

}


void display(struct student s)
{

	struct student S;
	S=s;
		printf("\n %d      %s  %d  %s \n",S.roll,S.name,S.mobile,S.email);


}


void bubble(struct student St[100],int r)
{
 int i,j;
struct student temp;
    	  for(i=1;i<r;i++)
    	  {
    		  for(j=0;j<r-1;j++)
    		  if(St[j].roll>St[j+1].roll)
    		  {
    			 temp=St[j];
    			 St[j]=St[j+1];
    			 St[j+1]=temp;
    		  }
    	  }
    	  printf("\n Your Sorted Array Is : \n ");
    	  printf("Roll_No  NAME  Mobile_Number  Email ");
    	  for(i=0;i<r;i++){
    	          display (St[i]);
    	      	}

}


void dis(struct student St[100],int r)
{
struct student Stemp;
int i,s;
char g[20];


g[20]=St[i].name;
while(r==0)
for(i=0;i<r;i++)
{
    s=strcmp(St[i].name,St[i+1].name);

if(s==-1)
{
   g[20]=St[i+1].name;
}

}
int j=0;
for(i=0;i<r;i++)
    	{
    	  if(St[i].name==g)
    	{
            Stemp = St[i];
             St[i]=St[j];
             St[j]=Stemp;
               	       j++;


    	}
    	}
printf("\n Your Sorted Array ABy Selection Is : \n ");
    	  printf("Roll_No  NAME  Mobile_Number  Email ");
    	  for(i=0;i<r;i++){
    	          display (St[i]);
    	      	}

}
