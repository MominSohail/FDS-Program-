/*
 ============================================================================
 Name        : 7thQuick.c
 Author      : SOHAIL
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#define max 50
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct MobileUser
{
	char name[20];
	int mobile;
	float bill;
};

void create(struct MobileUser mu[max],int n);
void display(struct MobileUser[max],int n);
void quicksort(struct MobileUser a[],int lower, int upper, int n);
int partition(struct MobileUser a[max],int lower,int upper);


int main(void) {
	int n;
	struct MobileUser MU[max];
	printf("\nEnter How Many Records of Mobile User You Have:");
	scanf("%d",&n);
	if(n>max)
	{
		printf("You can Create only %d Records as its limit DataBase ",max);
		printf("\nRe-Enter ");
		main();
	}
	create(MU,n);
	printf("Your Data Base for Mobile user is Created As Follow(Before Quick Sort) :");
	display(MU,n);

	quicksort(MU,0,n-1,n);
	printf("\n");
	printf("\nSorted(Descending Order) Data Base of Mobile User by Quick Sort technique Is ");
	displayS(MU,n);
	return 0;
}
void create(struct MobileUser mu[max],int n)
{

	int i,no,f=0;
	for(i=0;i<n;i++)
	{
	printf("\nEnter Name of %d Mobile User :",i+1);
	scanf("%s",mu[i].name);
	f=0;
	while(f==0)
	{
		f=1;

    printf("\nEnter 10 digit Mobile Number of %d Mobile User:",i+1);
    scanf("%d",&no);
    if(no<1000000000 || no>9999999999)
    {
       f=0;
       printf("\nMobile Number should be 10 Digit ....");
       printf("\nRe _Enter Mobile Number..");
	}
    if(f==1)
    {

    	mu[i].mobile=no;
	}
	}
	printf("Enter Bill Amount of %d Mobile User :",i+1);
	scanf("%f",&mu[i].bill);
	}
}

void display(struct MobileUser mu[max],int n)
{ int i;
	printf("\nName    Mobile Number    Bill amount");
	for(i=0;i<n;i++)
	{
		printf("\n%s     %d        %f",mu[i].name,mu[i].mobile,mu[i].bill);
	}
}
void displayS(struct MobileUser mu[max],int n)
{ int i;
	printf("\nName    Mobile Number    Bill amount");
	for(i=n-1;i>=0;i--)
	{
		printf("\n%s     %d        %f",mu[i].name,mu[i].mobile,mu[i].bill);
	}
}
void quicksort(struct MobileUser a[],int lower, int upper, int n)
{
	int pivot;
	if(lower < upper)
	{
		pivot = partition(a,lower,upper);
		printf("\nAfter this pass, pivot position  :  %d",pivot+1);
		display(a,n);
		quicksort(a,lower,pivot-1,n);
		quicksort(a,pivot+1,upper,n);
	}
}

int partition(struct MobileUser a[max],int lower,int upper)
{
	int i,j;
	struct MobileUser temp;
	i = lower+1;
	j = upper;

	while(i<j)
	{
		while( strcmp(a[i].name,a[lower].name) < 0 && i < upper )
			i++ ;

		while( strcmp(a[j].name,a[lower].name) > 0 && j > lower)
			j-- ;

		if(i < j)
		{
			temp = a[i];
			a[i] = a[j];
			a[j] = temp;
		}
	} // end of while(i < j)

	temp = a[j];
	a[j] = a[lower];
	a[lower] = temp;
	return j;

} // end of function
