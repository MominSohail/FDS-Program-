/*
 ============================================================================
 /*
 ============================================================================
 Name        : Assinmnt_7.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include<string.h>
typedef struct
{
	char name[40];
	char cellno[11];
	char address[100];
	float bill;
}user;

void mobile(user s[],int i);
void display(user s[],int l,int r);
void name(user s[],int i);
void swapit(user *s,user *j);
int quick_sort(user s[],int lb,int ub,int pass,int n);
int split(user s[],int lb,int ub,int n);
int main(void)
{
	user s[20];
	int i,p,t,ub,lb=0,pass;
	printf("Enter number of entries - ");
	scanf("%d",&t);
	ub=t;
	while(getchar()!='\n');
	for(i=0;i<t;i++)
	{
		name(s,i);
		mobile(s,i);
		printf("Enter Address-");
		while(getchar()!='\n');
		gets(s[i].address);
		printf("Enter Bill- ");
		scanf("%f",&s[i].bill);
		while(getchar()!='\n');
	}

	pass=quick_sort(s,lb,ub,1,t);
	//sorted database

	printf("\nSorted List\n");
	for(i=0;i<t;i++)
			{
				printf("%s",s[i].cellno);
				printf("\t%s",s[i].name);
				printf("\t%.2f",s[i].bill);
				printf("\t%s\n",s[i].address );
			}
	printf("\nNo. of passes %d",pass);

	printf("\nTime analysis is: O(%d*log(%d))",t,t);

	return EXIT_SUCCESS;
}


void mobile(user s[],int i)
{
	int j=0,k,n=0,c;

		do
			{
			printf("Enter 10 digit mobile number\n");
			scanf("%s",s[i].cellno);
			k=strlen(s[i].cellno);
			if(k!=10)
				{
				printf("Invalid mobile number enter again\n");
				continue;
				}
			else
				{
					for(n=0;n<i;n++)
					{
						c=strcmp(s[n].cellno,s[i].cellno);
						if(c==0)
						{
						printf("Already Exists Enter again\n");
						break;
						}
					}

					if(n!=i)
						{continue;printf("hello");}
				}
			for(j=0;j<k;j++)		//Validation of mobile number
			{

				if((s[i].cellno[j]>47&&s[i].cellno[j]<58))
					continue;
				else
					{
						printf("Only numbers allowed.Enter again\n");
						break;
					}
			}
			}
		while(j!=k);
}



//Function for name acception and validation
void name(user s[],int i)
{
	int j,k;
	printf("\nFor %d employee ",i+1);
	do
		{
		printf("\nEnter name\n");
		gets(s[i].name);
		k=strlen(s[i].name);
		for(j=0;j<k;j++)		//Validation of name
		{
			if((s[i].name[j]>96&&s[i].name[j]<123)||(s[i].name[j]>64&&s[i].name[j]<91)||s[i].name[j]==' ')
				continue;
			else
				{
					printf("Only characters/spaces allowed.Enter again\n");
					break;
				}
		}
		}
	while(j!=k);
}

void display(user s[],int l,int r)
{
	int i;
	printf("*********************************************\n");
	printf("To the left of pivot-\n");
	if(l==0)
		printf("-");
	else
	{
		printf("CellNo\t\tName\tBill\tAddress\n");
		for(i=0;i<l;i++)
		{
			printf("%s",s[i].cellno);
			printf("\t%s",s[i].name);
			printf("\t%.2f",s[i].bill);
			printf("\t%s\n",s[i].address );
		}
	}
	printf("To the right of pivot-\n");
		if(l==r-1)
			printf("-");
		else
		{
			printf("CellNo\t\tName\tBill\tAddress\n");
			for(i=l+1;i<r;i++)
			{
				printf("%s",s[i].cellno);
				printf("\t%s",s[i].name);
				printf("\t%.2f",s[i].bill);
				printf("\t%s\n",s[i].address );
			}
		}
	printf("\n********************************************");
}

int quick_sort(user s[],int lb,int ub,int pass,int n)
{
	int i;

	if(lb<ub)
	{
		printf("Pass %d",pass++);
		i=split(s,lb,ub,n);
		pass=quick_sort(s,lb,i-1,pass,n);
		pass=quick_sort(s,i+1,ub,pass,n);
	}
	return pass;
}

int split(user s[],int lb,int ub,int n)
{
	int p,comp=0;
	int i=lb+1,j=ub,flag=1,t;
	p=lb;

	printf("\npivot = %s\n",s[p].name);
	while(flag)
	{

			t=strcmp(s[i].name,s[p].name);
		while(t>0&&i<=ub)
		{
			i++;
			comp++;
			t=strcmp(s[i].name,s[p].name);
		}

		t=strcmp(s[j].name,s[p].name);
		while(t<0)
		{
			j--;
			comp++;
			t=strcmp(s[j].name,s[p].name);
		}
		if(i<j)
			swapit(&s[i],&s[j]);
		else
			flag=0;
	}
	swapit(&s[lb],&s[j]);
	display(s,j,n);

	printf("\nNumber of comparisons=%d\n\n",comp);
	return j;
}


void swapit(user *s,user *j)
{
	user t;
	t=*s;
	*s=*j;
	*j=t;
}

