/*
 ============================================================================
 Name        : 9th.c
 Author      : SOHAIL
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
struct node
{
	int data;
	struct node *next;
};


void dispplay(struct node *head);

struct node *insert(struct node *head);
struct node *del(struct node *head);
struct node *disrev(struct node *head);

int main(void) {
	int i,n,ch=0;
	struct node *head=NULL,*n_node;
	printf("How Many Node You have :");
	scanf("%d",&n);
	printf("\nEnter Data of each Node :");
	for(i=1;i<=n;i++)
	{
		if(head==NULL)
		{
		n_node=head=(struct node*)malloc(sizeof(struct node));
		}
		else
		{

		   n_node->next=(struct node*)malloc(sizeof(struct node));
		   n_node=n_node->next;

		}
		n_node->next=NULL;
		 printf("\n Enter Data Of %d Node :",i);
				   scanf("%d",&(n_node->data));
	}
	printf("Single Linked List of given Data is Created :");
while(ch<5)
{
	printf("\n");
	printf("\n1.Display \n2.Insertion \n3.Deletion \n4.Revert the List \n5.Exit ");
	printf("\nEnter Which Operation u want to perform on linked List :");
	scanf("%d",&ch);
	switch(ch)
	{
	case 1:
		printf("\nYour Linked List is :");
			display(head);
		break;
	case 2:
             head=insert(head);
		break;
	case 3:
		head=del(head);
		break;
	case 4:
		 head=disrev(head);
		 printf("\n Your linked List After Reverting It :");
		 display(head);
		break;
}

}


	return EXIT_SUCCESS;
}
void display(struct node *head)
{
	struct node *p1,*p2;
	p1=p2=head;
	int i=0;
	printf("\nPosition :->");
	while(p1!=NULL)
		{
		i++;
			printf("  %d  ",i);
			p1=p1->next;
		}
	printf("\nData     :->");
	while(p2!=NULL)
	{
		printf(" %d  ",p2->data);
		p2=p2->next;
	}
}

struct node *insert(struct node *head)//function definition for insertion of new node
{
	int ch=0,pos,i=1;
	struct node *p;
	p=head;
	printf("\n1.At beginning \n2.At End \n3.In Between");
				     printf("\nEnter Proper Choice :");
				     scanf("%d",&ch);
	 struct node *n_node;
			     n_node=(struct node *)malloc(sizeof(struct node));//dynamic memory allocation for node
			     printf("\nEnter data of New Node :");
			     scanf("%d",&(n_node->data));
			     n_node->next=NULL;
	switch(ch)
		{
	case 1:                                 //for insertion from front
		n_node->next=head;
		     head=n_node;
		     printf("\nNew Node Inserted At the Beginning..");
		break;
	case 2:                                 //for insertion of new node at end
		while(p->next!=NULL)
		{
			p=p->next;
		}
		p->next=n_node;
	printf("\n New Node Inserted At the End");
		break;

	case 3:                               //for insertion in between
		   printf("\nEnter Position of node after Which You want to insert New Node :");
		   scanf("%d",&pos);
		   while(i<pos)
		   {
			i++;
			p=p->next;
		   }
		   n_node->next=p->next;
		   p->next=n_node;
		   printf("\nNew Node Inserted in Between of Nodes");

		break;
		}

	return head;
}
struct node *del(struct node *head)//function for Deletion of Node
{
	if(head==NULL)//check for empty
	{
		printf("List Is Empty...");
		return head;
	}
	struct node *p,*p1;

  p=head;

	int n,pos,i=0,f=0;
	while(p!=NULL)
			{
			i++;
				p=p->next;
			}
	n=i;
	while(f==0)
	{
		f=1;
	printf("\nEnter position of node you want to Delete :");
	scanf("%d",&pos);
	if(pos>n)//check for valid position
	{
		f=0;
		printf("Invalid position");
	}
	else
	{
	        if(pos==1)//delete from front
	          {
		         printf("\nYou are Deleting First Node (Delete from front)");
		         p=head;
		          head=p->next;
		          free(p);
		  printf("\nFist Node is Deleted..");
	          }
	         else if(pos==n)//delete from end
	         {
		         printf("\nYou are Deleting Last Element of Linked list ");
		         p=head;

		         while(p->next!=NULL)
		         {
		        	 p1=p;
		        	 p=p->next;
		         }
		         p1->next=NULL;
		   free(p);
		   printf("\nLast Node is Deleted ");
	          }
	         else if(pos>1 && pos<n)//delete from middle
	         {
	        	 p=head;
	        	 i=1;
	        	 while(i<pos)
	        	 {
	        		 i++;
	        		 p1=p;
	        		 p=p->next;
	        	 }
	        	 p1->next=p->next;
	        	 free(p);
	        	 printf("\nNode Deleted From middle");
	         }
	}
	}
	return head;
}

struct node *disrev(struct node *head)//function for reverting liked list
{
	struct node *p,*q,*r;
	p=NULL;
	q=head;

	r=q->next;
	while(q!=NULL)
	{

		q->next=p;
		p=q;
		q=r;
		if(q!=NULL)
		{
			r=q->next;
		}

	}

	return p;
}
