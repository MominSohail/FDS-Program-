/*
 ============================================================================
 Name        : 10th.c
 Author      : SOHAIl
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
struct poly
{
	int coff;
	int power;
	struct poly *next;
};
void display(struct poly *head);
struct poly *create(struct poly *head);
struct poly *add(struct poly *h1,struct poly *h2);
int main(void) {

	int n,i;
	struct poly *head1=NULL,*head2=NULL,*headA=NULL;

	printf("\nEnter First Polynomial:");
	head1=create(head1);
	printf("\nYour First Polynomial is :\n");
       display(head1);

     printf("\nEnter Second Polynomial :");
     head2=create(head2);
     printf("\nYour Second Polynomial is :\n");
            display(head2);

  headA=add(head1,head2);

     printf("\n");
     printf("\nAddition of Polynomial is :\n");
     display(headA);
	return EXIT_SUCCESS;
}

struct poly *create(struct poly *head)
{
	struct poly *n_node,*p_node;
	int n,i;
	printf("\nEnter Total Number of Terms of Polynomial :");
		scanf("%d",&n);


	for(i=1;i<=n;i++)
			{
				if(head==NULL)
				{
				n_node=head=(struct poly*)malloc(sizeof(struct poly));
				head->next=head;
						//n_node->next=n_node;
				}
				else
				{
				   n_node->next=(struct poly*)malloc(sizeof(struct poly));
				   n_node=n_node->next;

				}
				n_node->next=head;
				printf("Enter coefficient and Power of %d Term of Polynomial (C/P):",i);
						scanf("%d %d",&n_node->coff,&n_node->power);
			}
	       printf("Polynomial stored");
	       return head;
}


void display(struct poly *head)
{

	struct poly *p1;
	p1=head;
	int i=0;
	printf("%dX^%d ",p1->coff,p1->power);
	while(p1->next!=head)
		{
		i++;

			p1=p1->next;
			printf("+ %dX^%d ",p1->coff,p1->power);
		}

}
struct poly *add(struct poly *h1,struct poly *h2)
{
	struct poly *headA=NULL,*headB=NULL,*n_node=NULL,*p1=NULL,*p2=NULL,*headR=NULL;
	int n=0,m=0,i,f=0;
	p1=h1;
	p2=h2;

   m=p1->power;
    p1=p1->next;
	do                        //Find Greatest Power of poly1 in m
	{
		if(m<p1->power)
		{
			m=p1->power;

			p1=p1->next;
		}
		p1=p1->next;
	}while(p1->next!=h1);
	printf("\n high power is %d",m);

	n=p2->power;
	    p2=p2->next;
		do                             //Find Greatest power of poly2 in n
		{
			if(n<p2->power)
			{
				n=p2->power;

				p2=p2->next;
			}
			p2=p2->next;
		}while(p2->next!=h2);
		printf("\n high power is %d",n);


		    p1=h1;
			p2=h2;

		for(i=m;i>=0;i--) //According to greatest power sequence poly1
		{
			f=0;
			do
			{
			if(i==p1->power)
			{
                f=1;
				if(headA==NULL)
				{
				n_node=headA=(struct poly*)malloc(sizeof(struct poly));
				headA->next=headA;
				n_node->coff=p1->coff;
				n_node->power=i;
				}
				else
				{
                   n_node->next=(struct poly*)malloc(sizeof(struct poly));
				   n_node=n_node->next;
				   n_node->next=headA;
				   n_node->coff=p1->coff;
				   n_node->power=i;
				}

			}
			p1=p1->next;
			}while(p1!=h1);
            if(f==0)
            {
            	if(headA==NULL)
            					{

            					n_node=headA=(struct poly*)malloc(sizeof(struct poly));
            					headA->next=headA;
            					n_node->coff=0;
            					n_node->power=i;
            					}
            					else
            					{

            					   n_node->next=(struct poly*)malloc(sizeof(struct poly));
            					   n_node=n_node->next;
            					   n_node->next=headA;
            					   n_node->coff=0;
            					   n_node->power=i;
            					}

            }
		}
		printf("\nYour First polynomial in sequence\n");
		display(headA);
		p2=h2;

				for(i=n;i>=0;i--)          //according to n sequence poly2
				{
					f=0;
					do
					{
					if(i==p2->power)
					{
		                f=1;
						if(headB==NULL)
						{

						n_node=headB=(struct poly*)malloc(sizeof(struct poly));
						headB->next=headB;
						n_node->coff=p2->coff;
						n_node->power=i;
						}
						else
						{

						   n_node->next=(struct poly*)malloc(sizeof(struct poly));
						   n_node=n_node->next;
						   n_node->next=headB;
						   n_node->coff=p2->coff;
						   n_node->power=i;
						}

					}
					p2=p2->next;
					}while(p2!=h2);
		            if(f==0)
		            {
		            	if(headB==NULL)
		            					{

		            					n_node=headB=(struct poly*)malloc(sizeof(struct poly));
		            					headB->next=headB;
		            					n_node->coff=0;
		            					n_node->power=i;
		            					}
		            					else
		            					{

		            					   n_node->next=(struct poly*)malloc(sizeof(struct poly));
		            					   n_node=n_node->next;
		            					   n_node->next=headB;
		            					   n_node->coff=0;
		            					   n_node->power=i;
		            					}

		            }
				}
				printf("\nYour Second polynomial in sequence\n");
				display(headB);


				p1=headA;
				p2=headB;

			  do
			  {
				if(headR==NULL)
				{
					n_node=headR=(struct poly*)malloc(sizeof(struct poly));
					headR->next=headR;
					n_node->coff=p1->coff+p2->coff;
					n_node->power=p1->power;
				}
				else
				{
                    n_node->next=(struct poly*)malloc(sizeof(struct poly));
					  n_node=n_node->next;
					  n_node->next=headR;
					  n_node->coff=p1->coff+p2->coff;
					  n_node->power=p1->power;
				}

										p1=p1->next;
										p2=p2->next;


			  }while(p1!=headA && p2!=headB);

			  while(p1!=headA)
						{
							if(headR==NULL)
																	{

																	n_node=headR=(struct poly*)malloc(sizeof(struct poly));
																	headR->next=headR;
																	n_node->coff=p1->coff;
																	n_node->power=p1->power;
																	}
																	else
																	{

																	   n_node->next=(struct poly*)malloc(sizeof(struct poly));
																	   n_node=n_node->next;
																	   n_node->next=headR;
																	   n_node->coff=p1->coff;
																	   n_node->power=p1->power;
																	}

																	p1=p1->next;

						}

			               while(p2!=headB)
			  						{
			  							if(headR==NULL)
			  																	{

			  																	n_node=headR=(struct poly*)malloc(sizeof(struct poly));
			  																	headR->next=headR;
			  																	n_node->coff=p2->coff;
			  																	n_node->power=p2->power;
			  																	}
			  																	else
			  																	{

			  																	   n_node->next=(struct poly*)malloc(sizeof(struct poly));
			  																	   n_node=n_node->next;
			  																	   n_node->next=headR;
			  																	   n_node->coff=p2->coff;
			  																	   n_node->power=p2->power;
			  																	}

			  																	p2=p2->next;

			  						}

                     return headR;
}
