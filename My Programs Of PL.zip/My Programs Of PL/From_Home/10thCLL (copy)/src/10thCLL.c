/*
 ============================================================================
 Name        : 10thCLL.c
 Author      : SOHAIL
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
struct poly
{
	int coff;
	int power;
	struct poly *next;
};
struct poly *create(struct poly *head,int coff,int power);//Function ProtoType
void display(struct poly *head);

struct poly *add(struct poly *head1,struct poly *head2);
struct poly *mul(struct poly *h1,struct poly *h2);
int eva(struct poly *head);

int main(void) {

	struct poly *head1=NULL,*head2=NULL,*headA=NULL,*headM=NULL;
     int n,i,co,po,ch=0,che=0,E;
		printf("\nEnter First Polynomial:");
		printf("\n Enter Total Number of terms of First polynomial :");
		scanf("%d",&n);
		for(i=1;i<=n;i++)
		{
			printf("Enter coefficient and Power of %d Term of Polynomial (C/P):",i);
			scanf("%d %d",&co,&po);
         	head1=create(head1,co,po);
		}

		printf("\nYour First Polynomial is :\n");
	       display(head1);

	       printf("\nEnter SECOND Polynomial:");
	       		printf("\n Enter Total Number of terms of Second polynomial :");
	       		scanf("%d",&n);
	       		for(i=1;i<=n;i++)
	       		{
	       			printf("Enter coefficient and Power of %d Term of Polynomial (C/P):",i);
	       			scanf("%d %d",&co,&po);

	       		head2=create(head2,co,po);
	       		}
	       		printf("\nYour SECOND Polynomial is :\n");
	       	       display(head2);
 while(ch<4)
 {
	 printf("\n1.Addition of Polynomial \n2.Multiplication of Polynomial\n3.Evaluation of Polynomial\n4.Exit");
	 printf("\nEnter Your Choice :");
	 scanf("%d",&ch);
	 switch(ch)
	 {
	 case 1:

                   headA=add(head1,head2);

                   printf("\nAddition of two given Polynomial is :");
                   display(headA);
		 break;
	 case 2:

		      headM=mul(head1,head2);
		      printf("\nMultiplication of given polynomial is :");
		      display(headM);
 		 break;
	 case 3:
	 {
		 printf("\n1.Polynomial :");
				 display(head1);

		   printf("\n2.Polynomial :");
		   display(head2);
		   printf("\nEnter Which Polynomial you want to evaluate :");
		   scanf("%d",&che);
		      switch(che)
		      {
		      case 1:
		    	     E=eva(head1);
		    	     printf("Evaluation Result is = %d",E);
		    	  break;
		      case 2:
		    	  E=eva(head2);
		    	  printf("Evaluation Result is = %d",E);
		    	  break;
		      }

		 break;
	 }

	 default : printf("Enter proper choice:");
	 }
 }
	return EXIT_SUCCESS;
}
struct poly *create(struct poly *head,int coff,int power)//function for creation of polynomial
{
	struct poly *n_node,*temp;
	n_node=(struct poly *)malloc(sizeof(struct poly));//dynamic memory allocation
	n_node->coff=coff;
	n_node->power=power;
	n_node->next=NULL;
	if(head==NULL)//if head is NULL first term at first position
	{
		head=n_node;
		head->next=head;
		return(head);
	}
	if(power==head->power)//if power equal add coefficient
	{
		head->coff=head->coff+coff;
		return head;
	}
	if(power>head->power)//if power is greater place next to current term
	{
		n_node->next=head->next;
		head->next=n_node;
		head=n_node;
		return(head);
	}
	temp=head;
	while(temp->next!=head && power>=temp->next->power)//if power less than search for equal power or place according to power
		temp=temp->next;
	if(n_node->power==temp->power)
	{
		temp->coff=temp->coff+coff;

	}
	else
	{
		n_node->next=temp->next;
		temp->next=n_node;
	}
	return (head);
}

void display(struct poly *head)
{

	struct poly *p1;
	p1=head;
	int i=0;
	printf("%dX^%d ",p1->coff,p1->power);
	while(p1->next!=head)
		{
		i++;

			p1=p1->next;
			printf("+ %dX^%d ",p1->coff,p1->power);
		}

}

struct poly *add(struct poly *h1,struct poly *h2)
{
	struct poly *headA=NULL,*p;
	p=h1->next;
	do
	{
		headA=create(headA,p->coff,p->power);
		p=p->next;
	}while(p!=h1->next);

	p=h2->next;
	do
	{
		headA=create(headA,p->coff,p->power);
		p=p->next;
	}while(p!=h2->next);

	return headA;

}
struct poly *mul(struct poly *h1,struct poly *h2)
{

	struct poly *headM=NULL;
    struct poly *p1,*p2;
    p2=h2->next;
    do
    {
    	p1=h1->next;
    	do
    	{
    		headM=create(headM,(p1->power+p2->power),(p1->coff*p2->coff));
    		p1=p1->next;
    	}while(p1!=h1->next);
    	p2=p2->next;
    }while(p2!=h2->next);
    return headM;
}

int eva(struct poly *head)
{
	int x,result,po;
	printf("Enter value of X for polynomial :");
	scanf("%d",&x);
	struct poly *temp;
	temp=head->next;
	do
	{
		po=pow(x,temp->power);
		result=result+(temp->coff * po);
		temp=temp->next;
	}while(temp!=head->next);

	return result;
}
