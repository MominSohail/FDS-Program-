/*
 ============================================================================
 Name        : 3red.c
 Author      : SOHAIL
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>


int len(char *s);
void rev(char *stp,char *str);
void copy(char *stp,char *cst);
void display(char *stp);
int comp(char *st1,char *st2);
int palin(char *stp);
int substring(char *a,char *b);

int main(void) {
	int ch=0,l,di,pl,sub;
	char st[80],str[80],cst[80],sts[80],c;

	printf("Enter Any String :");
	gets(st);

	while(ch<7)
	{       printf("\n");
		    printf("\nWhat u want to do with this String.......????\n");
			printf("1.LENGTH\n2.REVERSE\n3.COPY\n4.COMPARE\n");
			printf("5.PALINDROME\n6.SUBSTRING\n7.EXIT\n");
			printf("enter your choice\n");
			scanf("%d",&ch);
			switch(ch)
			{
			case 1:
				 l= len(&st[0]);
				 printf("Length of given String is %d ",l);
		    	break;
			case 2:
				printf("your String After Reversing it : ");
				rev(&st[0],&str[0]);
				display(&str[0]);
				break;
			case 3:
				copy(&st[0],&cst[0]);
				printf("Your String %s copied on second variable which is :",st);
				display(&cst[0]);
				break;
			case 4:
				printf("Enter another String to whom u want to compare  firstly given string:");
				scanf("%s",sts);
				di=comp(&st[0],&sts[0]);
				if(di==0)
			     printf("the two strings are equal\n" );
				else if(di>0)
				 printf("the string '%s' is alphabetically bigger than string '%s'\n",st,sts);
				else
				 printf("the string '%s' is alphabetically bigger than '%s'\n",sts,st);

				break;
			case 5:
				        pl=palin(&st[0]);
				          if(pl!=0)
				          printf("the string '%s' is a palindrome",st);
				          else
				          printf("the string '%s' is not a palindrome",st);
				break;
			case 6:

			printf("Enter another String to whom u want to check Substring firstly given string:");
			scanf("%s",sts);
				 sub=substring(&st[0],&sts[0]);
				if(sub==0)
			       printf("%s is a substring",sts);
			   else
					printf("%s is a not a substring",sts);

				break;
			case 7:
				return 0;
				break;
			}
	      }
	return EXIT_SUCCESS;
}

int len(char *s)
{
	int i=0;
	while(*s!='\0')
	{
		s++;
		i++;
	}
	return i;
}

void rev(char *stp,char *str)
{
	int l,i,j=0;

	l=len(stp);
	for(i=l-1;i>=0;i--)
	{
		str++;
	}
	*str='\0';
	str--;
	for(i=l-1;i>=0;i--)
	{
		*str=*stp;
		str--;
		stp++;
	}
}
void copy(char *stp,char *cst)
{
	int i=0,l=0;
	l=len(stp);
	while(i<l)
	{
		*cst=*stp;
		cst++;
		stp++;
	i++;
	}
	*cst='\0';
}
void display(char *stp)
{
	while(*stp!='\0')
	{
		printf("%c",*stp);
		stp++;
	}
}
int comp(char *st1,char *st2)
{
	int l,i=0,d;
	if(len(st1)>len(st2))
	   l=len(st1);
	else
		l=len(st2);
	while(l!=0)
	{
		if(*st1!=*st2)
		{
			d=*st1-*st2;
			break;
		}
		else
		{
			l--;
			st1++;
			st2++;
		}

	}
	return d;
}

int palin(char *stp)
{
	char st[60];

	char *str;
	str=&st[0];

	rev(stp,str);


	while(*stp!='\0')
	{
		if(*stp!=*str)
		{
			return 0;
		}
		stp++;
		str++;
	}
  return 1;

}


int substring(char *a,char *b)
{
	int i,j,c,d;
	char *temp;
	for(i=0;i<len(a);i++)
	{
		c=0,d=1;
		for(j=i;j<(i+len(b));j++)
		{
			temp++;
			*temp=*a;
		}
		*temp='\0';
		d=comp(temp,b); // compare
		if(d==0)
			break;
	}
	return d;
}
