/*
 ============================================================================
 Name        : Assignment5.c
 Author      :
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

void read();//to read
void write();//to write
void stats();//to count words,spaces,chars
void main()
{
	int ch;

	do{
		printf("\nMENU");
		printf("\n1.Read \n2.Write \n3.File Statistics \n4.Exit");
		printf("\nPlease enter your choice : ");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				read();
				break;
			case 2:
				write();
				break;
			case 3:
				stats();
				break;
			case 4:
				exit(0);
				break;
			default:
				printf("*** Invalid Choice ! ***");
				break;
		}
	}while(ch!=4);

}
//to read
void read()
{
	FILE *fp;
	char c;
	fp=fopen("src.txt","r");
	if(fp==NULL)
	{
		printf("Error Opening File !");
	}
	else
	{
		while( ( (c=fgetc(fp)) ) !=EOF)
		{
			printf("%c",c);
		}
	}
	fclose(fp);
}
//to write
void write()
{
	FILE *fp;
	char ch;
	fp=fopen("src.txt","a");
	if(fp==NULL)
	{
		printf("Error Opening File !");
	}
	else
	{
		printf("Enter Data To Write To The File :");
		while((ch=getchar())!='~')
		{
			fputc(ch,fp);
		}
	}
	fclose(fp);
}
//to count words,spaces,chars
void stats()
{
	FILE *fp,*fp1;
	char c;
	int chars=0,words=0,spaces=0,sentence=0;
	fp=fopen("src.txt","r");
	if(fp==NULL)
	{
		printf("Error Opening File !");
	}
	else
	{
		while( ( (c=fgetc(fp)) ) !=EOF)
		{
			if(c==' ' || c=='\n')
			{
				if(c==' ')
				{
					spaces++;
					words++;
				}
				else
				{
					words++;
				}
			}
			else if(c=='.')
			{
				sentence++;
			}
			else
			{
				chars++;
			}
		}
		fclose(fp);
		printf("*** File Statistics ***");
		printf("\nTotal Sentences : %d",sentence);
		printf("\nTotal Words : %d",words);
		printf("\nTotal Characters : %d",chars);
		printf("\nTotal Spaces : %d",spaces);
	}
	fp1=fopen("count.txt","w");
	fprintf(fp1,"\nTotal Sentences : %d \nTotal Words : %d \nTotal Characters : %d \nTotal Spaces : %d",sentence,words,chars,spaces);
	fclose(fp1);
}
