/*
 ============================================================================
 Name        : 6thSorting.c
 Author      : SOHAIL
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>

struct student
	{
		int roll;
		char name[20];
		float per;

	};
void create(struct student s[100],int r);
void display(struct student s);
void bubble(struct student St[100],int r);
void dis(struct student St[100],int r);


int main(void) {
	int r,i,c=0,sr,f=0;
	struct student St[100];

	printf("how many Records of  students you have :");
    scanf("%d",&r);

	       create(St,r);
	       printf("\n student Created");
	    printf("Your Students Record :\n ");
	    printf("Roll_No   NAME   Percentage ");
            for(i=0;i<r;i++)
           {
    	 display(St[i]);
           }



while(c<7)
{

   printf("\nWhich operation you want to perform on Student DataBase ");
   		printf("\n1. Display the data in ascending order of Roll Number (Bubble Sort) ");
   		printf("\n2. Display data for RollNo specified by user (Binary search -  Input should be sorted in ascending order of roll number )");
   		printf("\n3. Display the data in descending order of name(Selection sort)");
   		printf("\n4. Exit");
   		printf("\n Enter Proper Choice :");

   scanf("%d",&c);

   switch(c)
    {
     case 1:
    	 bubble(St,r);
     break;

    case 2:
    	searchroll(St,r);

     break;

    case 3:

         dis(St,r);

    	break;
   case 4:
      return(0);
     break;
    default :
    printf("\n Please Enter Proper Choice....!!");
    }
}
return 0;
}
void create(struct student S[100],int r)
{
       int i,ro,j,f=0,no;
       for(i=0;i<r;i++)
       {
    	   f=0;
              while(f==0)//validation for unique roll number
                 {
            	  f=1;
            	  j=0;
			       printf("Enter roll_number of student :");
			       scanf("%d",&ro);
			       while(j<=i)
			       {
			        if(ro==S[j].roll)
		       	     {
				     f=0;
			         }
			       j++;
			        }
			       if(f==0)
			    	   printf("Roll number can not be equal...please re-enter..");
                }
              if(f==1)
              {
            S[i].roll=ro;
			printf("Enter Name of student :");
			scanf("%s",S[i].name);
			printf("Enter Percentage of student :");
			scanf("%f",&S[i].per);

              }
       }

}


void display(struct student s)
{
	struct student S;
	S=s;
		printf("\n %d          %s       %f  \n",S.roll,S.name,S.per);
}


void bubble(struct student S[100],int r)
{
 int i,j,comp=0;
struct student temp;
    	  for(i=0;i<r-1;i++)
    	  { comp++;
    		  for(j=0;j<(r-i-1);j++)
    		  {
    			  comp++;
    		  if(S[j].roll>S[j+1].roll)
    		  {
    			 temp=S[j];
    			 S[j]=S[j+1];
    			 S[j+1]=temp;
    		  }
    		  }
    		  printf("\n In Bubble Sort Your Record After ' %d ' Pass  : \n ",i+1);
    		      	  printf("Roll_No  NAME  Percentage  ");
    		      	  for(i=0;i<r;i++)
    		      	  {
    		      	          display (S[i]);
                       }
    	  }

    	  printf("\n Your complete Sorted Record of Students By BUBBLE SORT Technique Is : \n ");
    	  printf("Roll_No  NAME  Percentage  ");
    	  for(i=0;i<r;i++){
    	          display (S[i]);}

    	  printf("\nTime Complexity Taken : O(%d)",comp);

}



void dis(struct student S[100],int n)
{
struct student Stemp;
int i,j,maxindex,complexity=0;
for(i=0 ; i < (n-1) ; i++)
{
	 complexity++;
	 maxindex = i ;

	 for(j=i+1 ; j<n ; j++)
	 {
		 complexity++;
		 if( strcmp(S[j].name,S[maxindex].name) > 0)
			 maxindex = j;
	 }

	 if(maxindex != i)
	 {
		 Stemp = S[i];
		 S[i] = S[maxindex];
		 S[maxindex] = Stemp;
	 }

	  printf("\n In Selection Sort Your Record After ' %d ' Pass  : \n ",i+1);
	    		      	  printf("Roll_No  NAME  Percentage  ");
	    		      	  for(i=0;i<n;i++)
	    		      	  {
	    		      	          display (S[i]);
	                       }
}

printf("\n Your complete Sorted Record of Students By SELECTION SORT Technique Is : \n ");
  	  printf("Roll_No  NAME  Percentage  ");
  	  for(i=0;i<n;i++){
  	          display (S[i]);}

  	  printf("\nTime Complexity Taken : O(%d)",complexity);


}

void searchroll(struct student a[],int n)
{
	int rno,low,high,mid,pos;
	int complexity = 0;

	printf("\nEnter Roll number to be searched for ");
	scanf("%d",&rno);

	low = 0;
	high = n-1;

	while(low <= high)
	{
		complexity++ ;
		mid = (low+high)/2 ;

		if(rno == a[mid].roll)
		{
			pos = mid;
			break;
		}

		else if (rno < a[mid].roll)
			high = mid-1;

		else if (rno > a[mid].roll)
			low = mid+1;
	 }

	printf("\nThe searched record was found at location  %d",pos+1);
	display (a[pos]);
	printf("\nTime Complexity :  %d",complexity);

} // end of binary search function
