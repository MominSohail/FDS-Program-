/*
 ============================================================================
 Name        : 7th.c
 Author      : SOHAIL
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#define max 50

# include <stdio.h>
# include <string.h>
# include <ctype.h>

typedef struct
{
	char name[40];
	 unsigned long int mn;
	float billamount;
} mobdata;

void takeinput(mobdata[],int);
void quicksort(mobdata[],int,int,int);
int partition(mobdata[],int,int);
void show(mobdata[],int);


void main()

{
	int n,i;
	mobdata users[max],sorted[max];
	printf("\nEnter total Number of Records of Mobile Users :");
	scanf("%d",&n);

	if(n > max)
	{
		printf("\nMaximum number of users if  %d",max);
		exit(0);
	}


	takeinput(users,n);


	quicksort(users,0,n-1,n);

	printf("\nThe sorted database is as displayed below  : ");
	printf("\nName     Mobile Number       Bill Amount   ");
	show(users,n);
}

void takeinput(mobdata users[],int size)
{
	int i,j,flag=0;
	unsigned long int tmn;
	char ch,mobtemp[11];

	for(i=0 ; i<size ; i++ )
	{
		printf("\nEnter details for record  %d",i+1);
		printf("\nEnter Name   ");
		scanf("%s",users[i].name);
		while(flag==0)
		{
		printf("\nEnter 10 digit mobile number  ");
		scanf("%u",&tmn);
			flag=1;
		if(tmn<1000000000 || tmn>9999999999)
		{
			flag=0;
			printf("mobile number should be 10 digits  Re_enter");
		}
		if (flag==1)
		{
			users[i].mn;
		}
		}

		printf("\nEnter Bill amount   ");
		scanf("%f", &users[i].billamount);
	}

}

void quicksort(mobdata a[],int lower, int upper, int n)
{
	int pivot;
	if(lower < upper)
	{
		pivot = partition(a,lower,upper);
		printf("\nAfter this pass, pivot position  :  %d",pivot+1);
		shownames(a,n);
		quicksort(a,lower,pivot-1,n);
		quicksort(a,pivot+1,upper,n);
	}
}

int partition(mobdata a[],int lower,int upper)
{
	int i,j;
	mobdata temp;
	i = lower+1;
	j = upper;

	while(i<j)
	{
		while( strcmp(a[i].name,a[lower].name) < 0 && i < upper )
			i++ ;

		while( strcmp(a[j].name,a[lower].name) > 0 && j > lower)
			j-- ;

		if(i < j)
		{
			temp = a[i];
			a[i] = a[j];
			a[j] = temp;
		}
	} // end of while(i < j)

	temp = a[j];
	a[j] = a[lower];
	a[lower] = temp;
	return j;

} // end of function


void show(mobdata a[],int n)
{
	int i;

	for(i=0 ; i < n ; i++ )
	{
		printf("\n%s        %1u                  %f",a[i].name,a[i].mn,a[i].billamount);
	}
}

void shownames(mobdata a[],int n)
{
	int i ;

	printf("\nNames are in following order   :  \n");
	for(i=0 ; i < n ; i++ )
		printf("%s        ",a[i].name);
}
