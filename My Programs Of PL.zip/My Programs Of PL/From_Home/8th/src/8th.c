/*
 ============================================================================
 Name        : 8th.c
 Author      : SOHAIL
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
struct sparse
{
	int row;
	int col;
	int val;
};

void createS(int sm[20][20],struct sparse smt[200],int m,int n);
void display(int sm[20][20],struct sparse smt[200]);

void addsm(struct sparse a[20],struct sparse b[20],struct sparse r[20],int adm[20][20]);
//void tran(int a[20][3],int b[20][3]);

int main(void) {
	int ch=0,m,n,m1,n1,f=0,to;
	int sm[20][20],sm2[20][20],adm[20][20];
struct sparse smt1[200],smt2[200],adt[200],T[200];


  while(ch<4)
  {
	  printf("\n1.Addition of Sparse Matrix \n2.Simple Transpose \n3.Fast Transpose\n4.Exit");
	  printf("Enter Your Choice :");
	  scanf("%d",&ch);
	  switch(ch)
	  {
	  case 1:do
	         {
	           printf("Enter row and column of Actual Matrix (R C)");
	           scanf("%d %d",&m,&n);
	  	       if(m>20 && n>20)
	  	      {
	  		   printf("\nArray out off Bound Re-Enter");
	  	       }
	          }while(m>20 && n>20);

	  	      smt1[0].row=m;
	  	      smt1[0].col=n;
	          createS(sm,smt1,m,n);
	          display(sm,smt1);

		  while(f==0)
		  {
		  printf("Enter row and column of Adding Second Matrix (R C)");
		  	scanf("%d %d",&m1,&n1);
		  	if(m==m1 && n==n1)
		  	{
		  		f=1;
		  	smt2[0].row=m1;
		  	smt2[0].col=n1;
		    createS(sm2,smt2,m1,n1);
		    printf("your Second Sparse Matrix is :\n");
		    display(sm2,smt2);
		  	}
		  	if(f==0)
		  	{
		  		printf("in Addition of matrix Both matrix's Row And Column should be Equal");
		  	}
		  }
		  addsm(smt1,smt2,adt,adm);
		  printf("\nAddition of Your Matrix is :\n");
		  display(adm,adt);

		  break;
	  case 2:
	  	  //tran(sm1,T);
	  	    //printf("\nAfter Simple Transpose :\n ");
	  	    //display(T);
	  	  break;
	  }
  }


	return EXIT_SUCCESS;
}

void addsm(struct sparse a[20],struct sparse b[20],struct sparse r[20],int adm[20][20])
{
	int i=1,j=1,k=1,t1,t2;
	r[0].row=a[0].row;
	r[0].col=a[0].col;
	for(i=0;i<r[0].row;i++)
			{
				for(j=0;j<r[0].col;j++)
				{
					adm[i][j]=0;
				}
			}
	t1=a[0].val;
	t2=b[0].val;
	i=j=k=1;
	while(i<=t1 && j<=t2)
	{
		if(a[i].row<b[j].row)
		{
			r[k].row=a[i].row;
			r[k].col=a[i].col;
			r[k].val=a[i].val;
			adm[i][j]=a[i].val;
			k++;
			i++;
		}
		else if(a[i].row>b[j].col)
		{
			r[k].row=b[i].row;
						r[k].col=b[i].col;
						r[k].val=b[i].val;
						adm[i][j]=b[i].val;
						k++;
						j++;
		}
		else if(a[i].col<b[j].col)
		{
			r[k].row=a[i].row;
						r[k].col=a[i].col;
						r[k].val=a[i].val;
						adm[i][j]=a[i].val;
						k++;
						i++;
		}
		else if(a[i].col>b[j].col)
				{
			r[k].row=b[i].row;
									r[k].col=b[i].col;
									r[k].val=b[i].val;
									adm[i][j]=b[i].val;
									k++;
									j++;
				}
		else
		{
			r[k].row=b[i].row;
												r[k].col=b[i].col;
												r[k].val=b[i].val;
												adm[i][j]=b[i].val+a[i].val;
												k++;
												j++;
												i++;
		}
		while(i<=t1)
		{

			r[k].row=a[i].row;
			r[k].col=a[i].col;
			r[k].val=a[i].val;
			adm[i][j]=a[i].val;
			k++;
			i++;

		}
		while(j<=t2)
		{
			r[k].row=b[i].row;
			r[k].col=b[i].col;
			r[k].val=b[i].val;
			adm[i][j]=b[i].val;
			k++;
			j++;
		}
	}
	r[0].val=k-1;


}







void createS(int sm[20][20],struct sparse smt[200],int m,int n)
{
	int t,i,j,tn;
	int f=0,r,c,v;
	tn=m*n;
	tn=tn/2;
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			sm[i][j]=0;
		}
	}

  do
  {
	printf("\nEnter total number of non-zero elements of matrix :\n");
	scanf("%d",&t);
	if(t>tn)
	{
		printf("\nIts Not Sparse Matrix :");
		printf("NOTE: non-zero elements should be 50% less elements to total number of elements of Matrix:");
	}
  }while(t>tn);
	smt[0].val=t;
    i=1;
	printf("Enter Row Column and Non-zero value As:\n ");
	do
	{
		f=0;
		printf("Row :");
		scanf("%d",&r);
		printf("Column:");
		scanf("%d",&c);

		for(j=1;j<i;j++)
		{
		if(r==smt[j].row && c==smt[j].col)
		{
			f=1;
			printf("Row Column pair is present or at this position non-zero elements is there");
			printf("\n Re-Enter row col and value");
			break;
		}
		}
		if(f==0)
		{
			printf("Value :");
					scanf("%d",&v);
			smt[i].row=r;
			smt[i].col=c;
		    smt[i].val=v;
		    sm[r][c]=v;
		    i++;
		}



	}while(i<=t);

}

void display(int s[20][20],struct sparse smt[200])
{
	int i,n,j;
	n=smt[0].val;
	printf("\nYour Sparse Matrix is :\n");
	for(i=0;i<smt[0].row;i++)
	{
		for(j=0;j<smt[0].col;j++)
		{
			printf("%d  ",s[i][j]);
		}
		printf("\n");
	}
	//printf("\nTotalRow= %d Total Columns =%d AND Total Non-zero Elements= %d \n", smt[0][0],s[0][1],s[0][2]);
	printf("\nSparse Table is :");
	printf("\nRow Column value");
	for(i=0;i<=n;i++)
	{
		printf("\n %d    %d      %d",smt[i].row,smt[i].col,smt[i].val);
	}
}
void tran(int a[20][3],int t[20][3])
{

	int c,r,n,k=1;
	t[0][0]=a[0][1];
	t[0][1]=a[0][0];
	t[0][2]=a[0][2];

	n=a[0][2];
	if(n>0)
	{
	for(c=0;c<a[0][1];c++)
	{
		for(r=1;r<=n;r++)
		{
			if(c==a[r][1])
			{
				t[k][0]=c;
				t[k][1]=a[r][0];
				t[k][2]=a[r][2];
				k++;
			}
		}
	}
	}
}
