#include <stdio.h>
#include <stdlib.h>

void unionCal(int a[100],int b[100],int m,int n);//Union
void intersection(int a[100],int b[100],int m,int n);//Intersection
void diff1(int a[100],int b[100],int m,int n,int ans[100]);//A-B
void symmetric(int a[100],int b[100],int m,int n,int demo[100],int demo2[100]);//Symmetric Difference
void main()
{
	int a[100],b[100],m,n,ch,i,j,ans[100],ans1[100];
	printf("Total No. Of Elements For Set 1 : ");
	scanf("%d",&m);
	printf("Total No. Of Elements For Set 2 : ");
	scanf("%d",&n);
	printf("Enter Elements For Set 1 : \n");
	for(i=0;i<m;i++)
	scanf("%d",&a[i]);

	printf("Enter Elements For Set 2 : \n");
	for(i=0;i<n;i++)
	scanf("%d",&b[i]);
	do{
		printf("\n MENU");
		printf("\n 1.Union");
		printf("\n 2.Intersection");
		printf("\n 3.Difference");
		printf("\n 4.Symmetric Difference");
		printf("\n 5.Exit");

		printf("\n Please enter your choice :");
		scanf("%d",&ch);

		//print set1 and set2
		printf("\n Set 1 : \n");
		for(i=0;i<m;i++)
		{
		 printf("%d\t",a[i]);
		}

		printf("\n Set 2 : \n");
		for(j=0;j<n;j++)
		{
		 printf("%d\t",b[j]);
		}
		switch(ch)
		{
		 case 1:
			 printf("\nUnion");
			 unionCal(a,b,m,n);
			 break;
		 case 2:
			 printf("\nIntersection");
			 intersection(a,b,m,n);
			 break;
		 case 3:
			 printf("\nDifference");
			 printf("\nA-B");
			 diff1(a,b,m,n,ans);
			 printf("\nB-A");
			 diff1(b,a,m,n,ans);
			 break;
		 case 4:
			 printf("\nSymmetric Difference");
			 symmetric(a,b,m,n,ans,ans1);
			 break;
		 case 5:
			 exit(0);
			 printf("\nThank You...");
			 break;
		 default:
			 printf("Invalid Choice !");
			 break;
		}
	}while(ch!=5);
	//getch();
}
void unionCal(int a[100],int b[100],int m,int n)
{
		int i,j,c[100],k=0,flag=0;
		for(i=0;i<m;i++)
		 {
			 c[k]=a[i];
			 k++;
		 }//Copy Whole a[] to c[]

		 for(j=0;j<n;j++)//B
		 {
			 flag=0;
			 for(i=0;i<m;i++)//A
			 {
				 if(b[j]==a[i])
				 {
					 flag=1;
					 break;
				 }
			 }
			 if(flag==0)
			 {
				 c[k]=b[j];
				 k++;
			 }
		 }

		 for(i=0;i<k;i++)
		 printf("\n %d",c[i]);//Printing the resulting Set
}
void intersection(int a[100],int b[100],int m,int n)
{
		int i,j,k=0,c[100];
		for(j=0;j<n;j++)//B
		 {
			 for(i=0;i<m;i++)//A
			 {
				 if(b[j]==a[i])
				 {
					 c[k]=b[j];
					 k++;
				 }
			 }
		 }
		for(i=0;i<k;i++)
		printf("\n %d",c[i]);
}
void diff1(int a[100],int b[100],int m,int n,int ans[100])
{
		int i,j,k=0,c[100],flag=0;
		for(i=0;i<m;i++)//A
		 {
			 flag=0;
			 for(j=0;j<n;j++)//B
			 {
				 if(a[i]==b[j])
				 {
					 flag=1;
					 break;
				 }
			 }
			 if(flag==0)
			 {
				 c[k]=a[i];
				 k++;
			 }
		 }
		for(i=0;i<k;i++)
		ans[i]=c[i];
		for(i=0;i<k;i++)
		printf("\n %d",ans[i]);
}

void symmetric(int a[100],int b[100],int m,int n,int demo[100],int demo2[100])
{
	printf("\nA-B\n");
	diff1(a,b,m,n,demo);
	printf("B-A\n");
	diff1(b,a,m,n,demo2);
	printf("(A-B) U (B-A)\n");
	unionCal(demo,demo2,m,n);
}
