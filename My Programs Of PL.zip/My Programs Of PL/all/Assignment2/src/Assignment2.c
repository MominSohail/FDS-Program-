#include <stdio.h>
#include <stdlib.h>

void add(int a[4][4],int b[4][4]);//matrix addition
void mul(int a[4][4],int b[4][4]);//matrix multiplication
void transpose(int a[4][4],int b[4][4]);//matrix multiplication

void main()
{
	int a[4][4],b[4][4],i,j,ch;
	printf("Enter Elements Of A :");
	for(i=1;i<=3;i++)
	{
		for(j=1;j<=3;j++)
		scanf("%d",&a[i][j]);
	}
	printf("\nEnter Elements Of B :");
	for(i=1;i<=3;i++)
	{
		for(j=1;j<=3;j++)
		scanf("%d",&b[i][j]);
	}
	printf("\nMatrix A \n");
	for(i=1;i<=3;i++)
	{
		for(j=1;j<=3;j++)
		{
			printf("%4d",a[i][j]);
		}
		printf("\n");
	}
	printf("\nMatrix B \n");
	for(i=1;i<=3;i++)
	{
		for(j=1;j<=3;j++)
		{
			printf("%4d",b[i][j]);
		}
		printf("\n");
	}
	do{
		printf("\nMENU");
		printf("\n1.Addition \n2.Multiplication \n3.Transpose \n4.Exit");
		printf("\nPlease enter your choice : ");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				add(a,b);
				break;
			case 2:
				mul(a,b);
				break;
			case 3:
				transpose(a,b);
				break;
			case 4:
				exit(0);
			default:
				printf("Invalid Choice");
		}
	}while(ch!=4);
}
//to add
void add(int a[4][4],int b[4][4])
{
			int i,j,c[4][4];
			for(i=1;i<=3;i++)
			{
				for(j=1;j<=3;j++)
				{
					c[i][j]=a[i][j] + b[i][j];
				}
			}
			printf("\nAddition Of Matrix A & B \n");
			for(i=1;i<=3;i++)
			{
				for(j=1;j<=3;j++)
				{
					printf("%4d",c[i][j]);
				}
				printf("\n");
			}
			printf("\n*******************************\n");
}
//matrix multiplication
void mul(int a[4][4],int b[4][4])
{
			int i,j,k,c[4][4];
			for(i=1;i<=3;i++)
			{
				for(j=1;j<=3;j++)
				{
					c[i][j]=0;
					for(k=1;k<=3;k++)
					{
						c[i][j]=a[i][k] * b[k][j]+c[i][j];
					}
				}
			}
			printf("\nMultiplication Of Matrix A & B \n");
			for(i=1;i<=3;i++)
			{
				for(j=1;j<=3;j++)
				{
					printf("%4d",c[i][j]);
				}
				printf("\n");
			}
			printf("\n*******************************\n");
}
//matrix multiplication
void transpose(int a[4][4],int b[4][4])
{
			int i,j;
			printf("\nTranspose Of Matrix A & B \n");
			printf("\n Matrix A \n");
			for(i=1;i<=3;i++)
			{
				for(j=1;j<=3;j++)
				{
					printf("%4d",a[j][i]);
				}
				printf("\n");
			}
			printf("\nMatrix B \n");
			for(i=1;i<=3;i++)
			{
				for(j=1;j<=3;j++)
				{
					printf("%4d",b[j][i]);
				}
				printf("\n");
			}
			printf("\n*******************************\n");
}
