#include <stdio.h>
#include <stdlib.h>

int length(char str[100]); //For length
void substr(char str[100],char key[100]); //For Substring
void compare(); //For Compare
void copy(); //For Copy
void reverse(char str[100]); //For Reverse
void palindrome(char str[100]); //For Palindrome
void main()
{
	int i,ch,l1,l2;
	char str[100],key[100];
	do{
		printf("\n\nMENU \n1.Substring \n2.Palindrome \n3.Compare \n4.Copy \n5.Reverse \n6.Exit");
		printf("\nPlease Enter Your Choice : ");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				printf("Enter Any String :");
				scanf("%s",str);
				printf("\nEnter Word To Find :");
				scanf("%s",key);
				substr(str,key);
				break;
			case 2:
				printf("Enter Any String : ");
				scanf("%s",str);
				palindrome(str);
				break;
			case 3:
				compare();
				break;
			case 4:
				copy();
				break;
			case 5:
				printf("Enter Any String : ");
				scanf("%s",str);
				reverse(str);
				break;
			case 6:
				printf("Thank You !");
				exit(0);
		}
	}while(ch!=6);
}
//length
int length(char str[1000])
{
	int i,len=0;
	for(i=0;str[i]!='\0';i++)
	len=len+1;
	return len;
}
//substring
void substr(char str[100],char key[100])
{
	int i,c;
	i=0;
	c=0;
	while (str[i]!='\0')
	{
		if (str[i]==key[c] && str[c]!='\0' && str[i]!=' ')
		{
		 c++;
		}
		else
		{
		 c=0;
		}
		i++;
	}
	if (c==length(key))
	printf("\nWord found");
	else
	printf("\nWord not found");
}
//compare
void compare()
{
	char str[100],str1[100];
	int l1,l2,i;
	printf("Enter String 1 : ");
	scanf("%s",&str);
	printf("Enter String 2 : ");
	scanf("%s",&str1);
	l1=length(str);
	l2=length(str1);
	if(l1==l2)
	{
		for(i=0;i<l1;i++)
		{
			if(str[i]==str1[i])
			{ }
			else
				break;
		}
		if(i==l1)
		{
			printf("Both Strings Are Equal !!!");
		}
		else
		{
			printf("Both Strings Are Not Equal !!!");
		}
	}
	else
	printf("Both Strings Are Not Equal !");
}
//copy
void copy()
{
	int i;
	char str[20],str1[20];
	printf("Enter String To Copy : ");
	scanf("%s",str);
	for(i=0;str[i]!='\0';i++)
	{
		str1[i]=str[i];
	}
	str1[i]='\0';
	printf("\nString Copied Successfully !");
	printf("\nOriginal String : %s",str);
	printf("\nCopied String : %s",str1);
}
//reverse
void reverse(char str[100])
{
	int len,i;
	len=length(str);
	printf("String Reverse Is : ");
	for(i=len-1;i>=0;i--)
	printf("%c",str[i]);
}
//palindrome
void palindrome(char str[100])
{
	int len,len1,i;
	char str1[100];
	len=length(str);
	for(i=len-1;i>=0;i--)
	{
		str1[i]=str[i];
	}
	len1=length(str1);
	for(i=0;i<len1;i++)
	{
		if(str[i]==str1[i])
		{ }
		else
			break;
	}
	if(i==len1)
	{
		printf("Given String Is Palindrome String");
	}
	else
	{
		printf("Given String Is Not Palindrome String");
	}

}
