/*
 ============================================================================
 Name        : Assignment4.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

//create struct
struct database
{
	int rno;
	char city[100],mob[11];
};

int create(struct database x[100]);//to read
void show(struct database x[100],int n);//to show DB
int insert(struct database x[100],int n);//to insert records
int delete(struct database x[100],int n);//to delete a record
int search(struct database x[100],int n,int rn);//to search
void update(struct database x[100],int n);//to update
//main
void main()
{
	struct database x[100];
	int i,n,ch,rn;
	printf("\t\t *** Welcome To Student Database ***\n\n");
	n=create(x);
	do{
		printf("\nMENU");
		printf("\n1.Insert \n2.Delete \n3.Search \n4.Update \n5.Show DB \n6.Exit");
		printf("\nPlease enter your choice : ");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				n=insert(x,n);
				printf("*** Record Inserted Successfully ! ***");
				break;
			case 2:
				n=delete(x,n);
				break;
			case 3:
				printf("Enter Roll No. To Search : ");
				scanf("%d",&rn);
				i=search(x,n,rn);
				if(i!=-1)
				{
					printf("\t\t*** Record Found! ***");
					printf("\nSr.");
					printf("\tRoll No.");
					printf("\t\tCity");
					printf("\t\t\tMobile");
					printf("\n%d",i+1);
					printf("\t%4d",x[i].rno);
					printf("\t\t\t%s",x[i].city);
					printf("\t\t\t%s",x[i].mob);
				}
				else
				{
					printf("\t\t*** Record Not Found! ***");
				}
				break;
			case 4:
				update(x,n);
				break;
			case 5:
				printf("\n\t\t\tSTUDENT DATABASE\n");
				show(x,n);
				break;
			case 6:
				printf("*** Thank You ! ***");
				break;
			default:
				printf("*** Invalid Choice ! ***");
				break;
		}
	}while(ch!=6);
}
//create
int create(struct database x[100])
{
	int i,n;
	printf("How Many Records You Want ?");
	scanf("%d",&n);

	for(i=0;i<n;i++)
	{
		printf("\nRecord %d",i+1);
		printf("\nRoll No. : ");
		scanf("%d",&x[i].rno);
		printf("City : ");
		scanf("%s",x[i].city);
		printf("Mobile No. : ");
		scanf("%s",x[i].mob);
	}
	return(n);
}
//show DB
void show(struct database x[100],int n)
{
	int i;
	printf("\nSr.");
	printf("\tRoll No.");
	printf("\t\tCity");
	printf("\t\t\tMobile");
	for(i=0;i<n;i++)
	{
		printf("\n%d",i+1);
		printf("\t%4d",x[i].rno);
		printf("\t\t\t%s",x[i].city);struct database *x;

		printf("\t\t\t%s",x[i].mob);
	}
}
//insert records
int insert(struct database x[100],int n)
{
	int i=n+1;
	printf("\nRecord %d",i);

	printf("\nRoll No. : ");
	scanf("%d",&x[n].rno);
	printf("City : ");
	scanf("%s",x[n].city);
	printf("Mobile No. : ");
	scanf("%s",x[n].mob);
	return(i);
}
//to delete a record
int delete(struct database x[100],int n)
{
	int rn;
	printf("Enter Roll.No To Delete :");
	scanf("%d",&rn);
	rn=rn-1;
	x[rn]=x[rn+1];
	n--;
	printf("\t\t*** Record Deleted! ***");
	return(n);
}
//to search a record
int search(struct database *x,int n,int rn)
{
	int i=0;
	while(i<n && x->rno!=rn)
	{
		i++;
		x++;
	}

	if(i<n)
	{
		return(i);
	}
	else
	{
		return(-1);
	}
}
//to update
void update(struct database x[100],int n)
{
	int ch,rn,i,index;
	char city[100],mob[11];
	printf("\nEnter Roll No. To Update :");
	scanf("%d",&rn);
	if(search(x,n,rn)==-1)
	{
		printf("\t\t*** Record Not Found! ***");
	}
	else
	{
		for(i=0;i<n;i++)
		{
			if(x[i].rno==rn)
			{
				index=i;
			}
		}
		do{
				printf("\nWhich Field You Want To Update ?");
				printf("\n1.City \n2.Mobile \n3.Exit");
				printf("\nPlease enter your choice : ");
				scanf("%d",&ch);

				switch(ch)
				{
					case 1:
						printf("\nEnter City :");
						scanf("%s",x[index].city);
						printf("\n*** City Updated ! ***");
						break;
					case 2:
						printf("\nEnter Mobile No. :");
						scanf("%s",x[index].mob);
						printf("\n*** Mobile No. Updated ! ***");
						break;
					case 3:
						break;
					default:
						printf("*** Invalid Choice ! ***");
						break;
				}
			}while(ch!=3);
	}

}
