/*
 ============================================================================
 Name        : Assignment5a.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

void copy(char src[200],char dest[200],int arg); //to copy contents
void type(char src[200]); //to read

void main(int argc,char *argv[])
{
	int ch,i;

	if(argc<3)
	{
		printf("Too Few Arguements.\nUsage : ./a.out src_file dest_file");
	}
	else
	{
		printf("\nMENU");
		printf("\n1.Copy \n2.Type \n3.Exit");
		printf("\nPlease enter your choice : ");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				copy(argv[1],argv[2],argc);
				break;
			case 2:
				type(argv[1]);
				break;
			case 3:
				exit(0);
				break;
			default:
				break;
		}
	}
}
void copy(char src[200],char dest[200],int arg)
{
	FILE *fp,*fp1;
	char ch ;
	if(arg<3)
	{
		printf("Too Few Arguements.\nUsage : ./a.out src_file dest_file");
	}
	else
	{
		if( (fp=fopen(src,"r"))!=NULL )
		{
			fp1=fopen(dest,"w");
			while( ( (ch=fgetc(fp)) ) !=EOF)
			{
				fputc(ch,fp1);
			}
			printf("\n*** File Contents Copied Successfully ! ***");
		}
		else
		{
			printf("Error Opening File");
		}
	}
	fclose(fp);
	fclose(fp1);
}
//to read
void type(char src[200])
{
	FILE *fp;
	char c;
	fp=fopen(src,"r");
	if(fp==NULL)
	{
		printf("Error Opening File !");
	}
	else
	{
		printf("*** Data Of The File Is ***\n");
		while(((c=fgetc(fp)))!=EOF)
		{
			printf("%c",c);
		}
	}
}
