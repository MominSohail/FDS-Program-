
#include <stdio.h>
#include <stdlib.h>

//create struct
struct database
{
	int rno;
	char city[100],mob[11];
};

int create(struct database x[100]);//to read
void show(struct database x[100],int n);//to show DB
int search(struct database x[100],int n,int rn);//to search
void bubble_sort(struct database x[100],int n);//sorting roll no in ascending order

//main
void main()
{
	struct database x[100];
	int i,n,ch,rn;
	printf("\t\t *** Welcome To Student Database ***\n\n");
	n=create(x);
	do{
		printf("\nMENU");
		printf("\n1.Bubble Sort \n2.Selection Sort \n3.Binary Search \n4.Show DB \n5.Exit");
		printf("\nPlease enter your choice : ");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				bubble_sort(x,n);
				break;
			case 2:

				break;
			case 3:

				break;
			case 4:
				printf("\n\t\t\tSTUDENT DATABASE\n");
				show(x,n);
				break;
			case 5:
				printf("*** Thank You ! ***");
				break;
			default:
				printf("*** Invalid Choice ! ***");
				break;
		}
	}while(ch!=5);
}
//create
int create(struct database x[100])
{
	int i,n;
	printf("How Many Records You Want ?");
	scanf("%d",&n);

	for(i=0;i<n;i++)
	{
		printf("\nRecord %d",i+1);
		printf("\nRoll No. : ");
		scanf("%d",&x[i].rno);
		printf("City : ");
		scanf("%s",x[i].city);
		printf("Mobile No. : ");
		scanf("%s",x[i].mob);
	}
	return(n);
}
//show DB
void show(struct database x[100],int n)
{
	int i;
	printf("\nSr.");
	printf("\tRoll No.");
	printf("\t\tCity");
	printf("\t\t\tMobile");
	for(i=0;i<n;i++)
	{
		printf("\n%d",i+1);
		printf("\t%4d",x[i].rno);
		printf("\t\t\t%s",x[i].city);
		printf("\t\t\t%s",x[i].mob);
	}
}
//sorting using bubble
void bubble_sort(struct database x[100],int n)
{
	int i,j,flag,t;
	for(i=0;i<n-1;i++)	//for passes
	{
		flag=0;
		printf("*** Pass %d ***\n",i+1);
		for(j=0;j<n-1;j++)	//for comparison
		{
			if(x[j].rno>x[j+1].rno)
			{
				t=x[j].rno;
				x[j].rno=x[j+1].rno;
				x[j+1].rno=t;
				flag=1;
				printf("*** Comparison %d ***\n",j+1);
			}
			show(x,n);
		}
		if(flag==0)
			break;
	}

}
