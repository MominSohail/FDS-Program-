/*
 * armstrong.c
 *
 *  Created on: 30-Jun-2015
 *      Author: pict
 */


#include <stdio.h>

void main()

{
	int number,i,number1 = 0;

	for(i=1 ; i <= 500 ; i++)
	{
		number1 = 0 ;
		number = i;
	    while(number != 0)
	    {
		  number1 = number1 + ( (number % 10) * (number % 10) * (number % 10) );
		  number = number / 10 ;
	    }
	    if(number1 == i)
	       printf("        %d",i);
	}
}
