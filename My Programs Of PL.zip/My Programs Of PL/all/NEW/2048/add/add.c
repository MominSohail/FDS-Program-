/*
 * add.c
 *
 *  Created on: 15-Jun-2015
 *      Author: pict
 */


#include <stdio.h>

int main()

{
	int a = 5 , b = 8 ;
	printf("\nSum is %d",a+b);
	return 0;
}
