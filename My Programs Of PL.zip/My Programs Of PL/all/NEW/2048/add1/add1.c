/*
 * add1.c
 *
 *  Created on: 15-Jun-2015
 *      Author: pict
 */


#include <stdio.h>

int main()

{
	int a,b;
	printf("\nEnter the numbers ");
	fflush(NULL);
	scanf("%d %d",&a,&b);
	printf("\nSum is %d",a+b);
	return 0 ;
}
