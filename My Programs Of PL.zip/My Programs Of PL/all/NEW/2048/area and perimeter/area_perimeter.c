/*
 * area_perimeter.c
 *
 *  Created on: 17-Jun-2015
 *      Author: pict
 */

#include <stdio.h>
#include <math.h>


void circle(float a);
void triangle(float a, float b, float c);
void rectangle(float a, float b);
void square(float a);

void main()

{
	char choice ;
	float a,b,c;
	printf("\nEnter the polygon whose area and parameter you want to find ");
	printf("\na. Circle");
	printf("\nb. Triangle");
	printf("\nc. Square");
	printf("\nd. Rectangle\n");
	scanf("%c",&choice);

	switch(choice)
	    {
	         case 'a' :  printf("\nEnter Radius \n");
	                     scanf("%f",&a);
	        	         circle(a);
	        	         break;

	         case 'b' :  printf("\nEnter three sides \n");
	                     scanf("%f%f%f",&a,&b,&c);
	                     triangle(a,b,c);
	                     break;

	         case 'c' : printf("\nEnter side \n");
	                     scanf("%f",&a);
	                     square(a);
	                     break;

	         case 'd' :  printf("\nEnter length and breadth \n");
	                     scanf("%f%f",&a,&b);
	                     rectangle(a,b);
	                     break;

	         default  :  printf("\nWrong Input!!! Please Try again!!!!");

	    }

}

void circle(float a)
{
	float p,area;
	p = 2*3.14*a;
	area = 3.14*a*a;
	printf("\nPerimeter is  :  %f",p);
	printf("\nArea is  :  %f",area);
}

void triangle(float a,float b,float c)
{
	float p,area,s;
	p = a+b+c;
	s = p/2;
	area = sqrt(s*(s-a)*(s-b)*(s-c));
	printf("\nPerimeter is  :  %f",p);
	printf("\nArea is  :  %f",area);
}

void square(float a)
{
	float p,area;
	p = 4*a;
	area = a*a;
	printf("\nPerimeter is   :  %f",p);
	printf("\nArea is  :   %f",area);
}

void rectangle(float a,float b)
{
	float p,area;
	p = 2*(a+b);
	area = a*b;
	printf("\nPerimeter is  :  %f",p);
	printf("\nArea is  :  %f",area);
}


