/*
 * arm2.c
 *
 *  Created on: 30-Jun-2015
 *      Author: pict
 */


#include<stdio.h>
int main()
{
	int a,b,c,d,q,x;
	printf("enter 3 digit no");
	scanf("%d",&a);
	  x=a;
	  b=a%10;
	  a=a/10;
	  c=a%10;
	  a=a/10;
	  d=a%10;
	  q=b*b*b+c*c*c+d*d*d;
	  if (q==x)
		  printf("%d is an armstrong number",x);
	  else
		  printf("%d is not an armstrong number",x);
	  return 0;
}
