/*
 * string.c
 *
 *  Created on: 15-Jul-2015
 *      Author: pict
 */


#include <stdio.h>

int  checksub(char[],char[]);
int  pallindrom(char[]);
int  compare(char[],char[]);
void copy(char[],char[]);
void reverse(char[]);

void main()

{
	char str1[50],str2[50],choice1,choice2;
	int i ;

	do
	{
		printf("\nEnter string 1 \n");
		fflush(NULL);
		gets(str1);
		printf("\nEnter string 2 \n");
		fflush(NULL);
		gets(str2);
	    do
	    {
		   printf("\nWhich string operation do you want to perform  ");
		   printf("\n1.Check substring ");
		   printf("\n2.Check for pallindrom ");
		   printf("\n3.Compare ");
		   printf("\n4.Copy ");
		   printf("\n5.Reverse ");
		   printf("\nEnter the number of your choice ");
		   scanf("%d",&i);
		   switch(i)

		   {
		         case  1  :  if( checksub(str1,str2) )
		        	            printf("\n %s  is a substring of  %s",str2,str1);
		                     else if( checksub(str2,str1))
			        	        printf("\n %s  is a substring of  %s",str1,str2);
		                     else
		                        printf("\nSubstring check failed ");
		                     break;

		         case  2  :  if( pallindrom(str1) )
      	                        printf("\n %s  is a pallindrom string ",str1);
		                     else
		                    	printf("\n %s  is a not pallindrom string ",str1);
		                     if( pallindrom(str2))
	        	                printf("\n %s  is a pallindrom string ",str2);
		                     else
		                    	printf("\n %s  is not a pallindrom string ",str2);
		                     break;


		         case  3  :  if( !compare(str1,str2) )
                                printf("\n %s  is equal to   %s ",str1,str2);
		                     else if( compare(str1,str2) > 0)
		                    	printf("\n %s  is greater than  %s",str1,str2);
		                     else
		                    	printf("\n %s  is greater than  %s",str2,str1);

		                     break;

		         case  4  :  copy(str1,str2);
		                     printf("\nString 2 copied to string 1  ");
		                     printf("\nString 1  :   %s ",str1 );
		                     break;

		         case  5  :  reverse(str1);
		                     reverse(str2);
		                     printf("\nReverse of String 1  :   %s",str1);
		                     printf("\nReverse of String 2  :   %s",str2);
		                     break;

		         default  :  printf("\nInvalid input !!!!!!!!!!  ");
		   }

		   printf("\nDo you want to perform more operations with same strings (y/n)");
		   scanf("%s",&choice1);
	     } while (choice1 == 'Y' || choice1 == 'y');

	    printf("\nDo you want to perform more operations with other strings (y/n)");
	    scanf("%s",&choice2);
	}  while (choice2 == 'Y' || choice2 == 'y') ;

}


int checksub(char str1[] , char str2[])

{
	int i,j,flag ;

	for(i = 0 ; str1[i] != '\0' ; i++)
	{
	    flag = 1;
		for(j = 0 ; str2[j] != '\0'; j++)
		 {
			if(str1[i+j] != str2[j])
			 {
			    flag = 0 ;
			    break;
			 }
	     }
	    if (flag)
	    	break ;
	}

	if(flag)
		return 1;
	else
		return 0;
}

int pallindrom (char str[])
{
	int i,j,flag = 1 ;

	for(i=0 ; str[i] != '\0' ; i++)
		                  ;                 // Null Statement

	j = 0 ;
	i-- ;

	while (i > j)
	{
		if(str[i] != str[j])
		{
			flag = 0 ;
			break;
		}

		i-- ;
		j++ ;
	}

	if(flag)
		return 1;
	else
		return 0;
}

int compare(char str1[] , char str2[])
{
	int i ;
	for(i=0 ; str1[i] != '\0' || str2[i] != '\0' ; i++)
	{
		if(str1[i] != str2[i])
			return (str1[i] - str2[i]) ;
	}

	return 0 ;
}

void copy(char str1[] , char str2[])
{
	printf("\nWelcome to copy ");
	int i = 0 ;
    for(i=0 ; str2[i] != '\0' ; i++ )
		 str1[i] = str2[i];
	str1[i] = '\0' ;
}

void reverse(char str[])
{
	int i,j ;
	char temp ;

	for(i=0 ; str[i] != '\0' ; i++)
		                  ;                 // Null Statement
	j = 0 ;
	i-- ;

	while (i > j)
	{
	    temp = str[i] ;
	    str[i] = str[j];
	    str[j] = temp;
        i-- ;
		j++ ;
	}
}






