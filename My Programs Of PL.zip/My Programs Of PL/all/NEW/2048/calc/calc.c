/*
 * calc.c
 *
 *  Created on: 15-Jun-2015
 *      Author: pict
 */


#include <stdio.h>

int main()

{
	int a,b,choice;

	printf("\nEnter the numbers ");
	scanf("%d %d",&a,&b);
	printf("\nEnter the code of the operation you want to perform");
	printf("\n 1. Addition");
	printf("\n 2. Subtraction");
	printf("\n 3. Multiplication ");
	printf("\n 4. Divison");
	scanf("%d",&choice);

	switch (choice)

	   {
	         case 1:   printf("\n Sum is :  %d",a+b);
	                   break;

	         case 2:   printf("\n Difference is :  %d",a-b);
	                   break;

	         case 3:   printf("\n Product is  :   %d", a*b);
                       break;

	         case 4:   printf("\n Divison is :  %d",a/b);
                       break;

	         default : printf("\nWrong input !!!!!!!!!!!");

	   }
    return 0;
}
