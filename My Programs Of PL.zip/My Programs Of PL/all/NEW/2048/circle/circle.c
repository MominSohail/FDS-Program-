/*
 * circle.c
 *
 *  Created on: 17-Jun-2015
 *      Author: pict
 */


#include <stdio.h>

float area(float a);
float perimeter(float b);

void main()

{
	float r;
	printf("\nEnter Radius");
	scanf("%f",&r);
	printf("\nArea is  :   %f",area(r));
	printf("\nPerimeter is  :  %f",perimeter(r));
}

float area(float x)
{
	return (3.14*x*x);
}

float perimeter(float y)
{
	return (2*3.14*y);
}
