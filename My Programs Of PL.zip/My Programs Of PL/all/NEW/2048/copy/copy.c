/*
 * copy.c
 *
 *  Created on: 03-Sep-2015
 *      Author: lite
 */


# include <stdio.h>

void main (int argc, char *argv[])
{
	char ch ;

	if (argc < 3)
		printf("\nToo few arguments");
	else
	{
		FILE *fp1, *fp2 ;
		fp1 = fopen(argv[1],"r");
		fp2 = fopen(argv[2],"w");



		if(fp1 == NULL)
			printf("\n%s - No such file \n",argv[1]);

		else
		{
			ch = getc(fp1);

			while(ch != EOF)
			{
				putc(ch,fp2);
				ch = getc(fp1);
			}

		}
	}

}
