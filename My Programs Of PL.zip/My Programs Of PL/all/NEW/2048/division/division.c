/*
 * division.c
 *
 *  Created on: 24-Jun-2015
 *      Author: pict
 */

#include <stdio.h>

void main()

{
	int a,b;
    printf("\nEnter dividend\n ");
    scanf("%d",&a);
    printf("\nEnter divisor\n");
    scanf("%d",&b);
    printf("\nThe answer is  :   %f ",(float)a/b);
 }
