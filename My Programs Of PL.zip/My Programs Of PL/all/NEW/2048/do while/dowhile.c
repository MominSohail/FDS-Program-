/*
 * dowhile.c
 *
 *  Created on: 17-Jun-2015
 *      Author: pict
 */


#include <stdio.h>


void main()

{
	int a;
	char ch;

	do
	  {
		printf("\nPlease enter a number \n");
		scanf("%d",&a);
		printf("The number you entered is  :  %d",a);
		printf("\nDo you want to enter another number  (y/n) \n ");
		scanf("%c",&ch);
      }while(ch =='y');
}
