/*
 * evenodd.c
 *
 *  Created on: 24-Jun-2015
 *      Author: pict
 */

# include <stdio.h>

void main()

{
	int no;
	printf("\nEnter number  \n");
	scanf("%d",&no);
	if(no%2==0)
		printf("\nThe number is even  ");
	else
		printf("\nThe number is odd   ");
}
