/*
 * file.c
 *
 *  Created on: 13-Aug-2015
 *      Author: pict
 */


#include <stdio.h>
#include <string.h>

void main()

{
	FILE *fp, *fp1, *fp2 ;
	int character=0,words=0,spaces=0,sentences=0;
    fp = fopen("myfile.txt","w");
	char s[50],ch[2]="\n",ch1,result[100];
	printf("\nEnter Data (Press only enter to stop )");
	gets(s);
	strcat(s,"\n");

	while(strcmp(s,ch))
	{
	   fputs(s,fp);
	   gets(s);
	   strcat(s,"\n");
	}

	fclose(fp);

	fp = fopen("myfile.txt","r");

	ch1 = getc(fp);

	while(ch1 != EOF)
	{
		if(ch1 != '\n')
			character++ ;

		else
		{
			sentences++ ;
			words++;
		}

		if(ch1 == ' ' || ch1 == '\t' )
		{
			spaces++ ;
			words++ ;
		}


		ch1 = getc(fp);
	}

	fclose(fp);
	sprintf(result,"Total number of characters - %d \nTotal number of spaces - %d \nTotal number of words - %d \nTotal number of sentences - %d \n",character,spaces,words,sentences);

	fp = fopen("result.txt","w");

	fprintf(fp,"%s",result);
	printf("%s",result);

	fclose(fp);
}
