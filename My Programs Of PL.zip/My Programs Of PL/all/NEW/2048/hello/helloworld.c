/*
 * helloworld.c
 *
 *  Created on: 15-Jun-2015
 *      Author: pict
 */


#include <stdio.h>

int main()

{
	printf("\nHello World");
	return 0 ;

}
