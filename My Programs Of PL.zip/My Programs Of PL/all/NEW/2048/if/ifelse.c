/*
 * ifelse.c
 *
 *  Created on: 17-Jun-2015
 *      Author: pict
 */


#include <stdio.h>

main()

{
	int i;
	printf("Enter 1 or 2 ");
	scanf("%d",&i);
	if(i==1)
		printf("\nYou got first prize ");

	else
	{
		if(i==2)
			printf("\nYou got second prize");

		else
			printf("\nYou got third prize ");
	}
}

