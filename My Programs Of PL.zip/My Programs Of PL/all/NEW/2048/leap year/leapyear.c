/*
 * leapyear.c
 *
 *  Created on: 24-Jun-2015
 *      Author: pict
 */


#include <stdio.h>

void main()

{
	int year ;
	printf("\nEnter year \n");
	scanf("%d",&year);
	if(year % 4 == 0)
		printf("\nIt is a leap year ");
	else
		printf("\nIt is not a leap year");
}
