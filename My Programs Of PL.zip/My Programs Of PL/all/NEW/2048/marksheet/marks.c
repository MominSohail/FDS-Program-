/*
 * marks.c
 *
 *  Created on: 16-Jun-2015
 *      Author: pict
 */


#include <stdio.h>

int main()

{
	float mark_1,mark_2,mark_3,sum, avg;
	printf("\nEnter the marks of three subjects (Out of 100)");
	fflush(NULL);
	scanf("%f%f%f",&mark_1, &mark_2, &mark_3);

	sum = (mark_1 + mark_2 + mark_3);
	avg = sum/3;

	printf("\nSum is  :  %f",sum);
	printf("\nAverage or Percentage is  :  %f",avg);

	if (avg > 70)
		printf("\nThe student has passed with distinction");
	else if (avg < 70 && avg>60)
		printf("\nThe student has passed with first class");
	else if (avg < 60 && avg > 50)
		printf("\nThe student has passed with second class");
	else if (avg <50 && avg > 40 )
		printf("\nThe student has passed with third class");
	else
		printf("\nThe student has failed  !!!! Better luck next time !!!");
    return 0;
}


