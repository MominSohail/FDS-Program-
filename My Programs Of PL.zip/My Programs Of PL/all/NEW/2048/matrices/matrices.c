/*
 * matrices.c
 *
 *  Created on: 09-Jul-2015
 *      Author: pict
 */


#include <stdio.h>

#define max 10

void input(int[][max],int r,int c);

void add(int[][max], int[][max], int[][max], int, int, int, int);

void subtract(int[][max], int[][max], int[][max], int, int, int, int);

void multiply(int[][max], int[][max], int[][max], int, int, int, int);

void transpose(int[][max],int[][max], int, int);

void print(int[][max],int, int);

void main()

{
	char ch;
	int choice, a[max][max], b[max][max], res[max][max] = {0};
	int r1,r2,c1,c2 ;

	     do
	     {
	    	 printf("\nWhich matrix operation do you want to perform    : ");
	    	 printf("\n1.Addition ");
	    	 printf("\n2.Subtraction ");
	    	 printf("\n3.Multiplication (A X B)");
	    	 printf("\n4.Transpose ");
	    	 printf("\nEnter the number your choice ");
	    	 scanf("%d",&choice);

	    	 switch(choice)
	    	 {
	    	     case 1   :     printf("\nEnter the two matrices  :  ");
		                        printf("\nEnter number of rows and columns of first matrix respectively  ");
	    	                    scanf("%d%d",&r1,&c1);
	    	                    printf("\nEnter number of rows and columns of second matrix respectively  ");
	    	                    scanf("%d%d",&r2,&c2);

	    	                    if(r1 == r2 && c1 == c2)
	    	                    {
		                           printf("\nEnter first matrix  ");
	    	                       input(a,r1,c1);
	    	                       printf("\n");
	    	                       print(a,r1,c1);
	    	                       printf("\nEnter second matrix ");
	    	                       input(b,r2,c2);
	    	                       printf("\n");
	    	                       print(b,r2,c2);
	    	                       add(a,b,res,r1,c1,r2,c2);
	    	                       printf("\n");
	    	                       printf("\nAddition is  \n");
	    	                       print(res,r1,c1);
	    	                    }

	    	                    else
	    	                    	printf("\nAddition of these two matrices not possible ");
	    	                    break;

	    	     case 2   :     printf("\nEnter the two matrices  :  ");
				                printf("\nEnter number of rows and columns of first matrix respectively  ");
			    	            scanf("%d%d",&r1,&c1);
			    	            printf("\nEnter number of rows and columns of second matrix respectively  ");
			    	            scanf("%d%d",&r2,&c2);

			    	            if(r1 == r2 && c1 == c2)
			    	              {
			    	            	printf("\nEnter first matrix  ");
			    	                input(a,r1,c1);
			    	                printf("\n");
			    	                print(a,r1,c1);
			    	                printf("\nEnter second matrix ");
			    	                input(b,r2,c2);
			    	                printf("\n");
			    	            	print(b,r2,c2);
			    	                subtract(a,b,res,r1,c1,r2,c2);
			    	                printf("\n");
			    	                printf("\nSubtraction is \n ");
			    	                print(res,r1,c1);
			    	               }

			    	            else
			    	                printf("\nSubtraction of these two matrices not possible ");
			    	            break;

	    	     case 3   :     printf("\nEnter the two matrices  :  ");
				                printf("\nEnter number of rows and columns of first matrix respectively  ");
			    	            scanf("%d%d",&r1,&c1);
			    	            printf("\nEnter number of rows and columns of second matrix respectively  ");
			    	            scanf("%d%d",&r2,&c2);


			    	            if(c1 == r2)
			    	              {
				                      printf("\nEnter first matrix  ");
			    	                  input(a,r1,c1);
			    	                  printf("\n");
			    	                  print(a,r1,c1);
			    	                  printf("\nEnter second matrix ");
			    	                  input(b,r2,c2);
			    	                  printf("\n");
			    	                  print(b,r2,c2);
			    	                  multiply(a,b,res,r1,c1,r2,c2);
			    	                  printf("\n Multiplication is \n");
			    	                  print(res,r1,c2);
			    	              }

			    	            else
			    	                printf("\nAddition of these two matrices not possible ");
			    	            break;

	    	     case 4   :     printf("\nEnter the two matrices  :  ");
				                printf("\nEnter number of rows and columns of first matrix respectively  ");
			    	            scanf("%d%d",&r1,&c1);
				                printf("\nEnter matrix  ");
			    	            input(a,r1,c1);
			    	            printf("\n ");
			    	            print(a,r1,c1);
			    	            transpose(a,res,r1,c1);
			    	            printf(" \n  Transpose is  \n");
			    	            print(res,r1,c1);
			    	            break;

	    	     default  :     printf("\nWrong input !!!!!!!! Please Try Again  :  ");
	    	 }
	    	 printf("\nDo you want to perform more operations (y/n)");
	    	 scanf("%s",&ch);
	     } while(ch == 'Y' || ch == 'y');
}

void input(int a[][max], int r, int c)

{
	int i,j;

	for(i=0 ; i < r ; i++ )
	{
		for(j=0 ; j < c ; j++ )
		{
			printf("\nEnter element  %d of  %d row ", j+1 , i+1);
			scanf("%d", &a[i][j]);
		}
	}
}

void add(int a[][max], int b[][max], int res[][max], int r1, int c1, int r2, int c2)

{
	int i , j;

	for(i=0 ; i < r1 ; i++)

	    {
		     for(j=0 ; j < c1 ; j++)
		    	 res[i][j] = a[i][j] + b[i][j] ;
		}

}

void subtract(int a[][max], int b[][max], int res[][max], int r1, int c1, int r2, int c2)
{
	int i , j;
	for(i=0 ; i < r1 ; i++)

		{
			 for(j=0 ; j < c1 ; j++)
			     res[i][j] = a[i][j] - b[i][j] ;
	    }
}

void multiply(int a[][max], int b[][max], int res[][max], int r1, int c1, int r2, int c2)
{
	int i , j , k ;
    for(i=0 ; i < r1 ; i++)
    {
        for(j=0 ; j < c2 ; j++)
        {
    	    for(k=0 ; k < c1 ; k++)
    		   res[i][j] = res[i][j] + ( a[i][k] * b[k][j] ) ;
        }
    }
}

void transpose(int a[][max], int res[][max], int r1, int c1)
{
	int i , j ;
	for(i=0 ; i < r1 ; i++)
	 {
		 for(j=0 ; j < c1 ; j++)
			 res[i][j] = a[j][i] ;
	 }
}

void print(int res[][max], int r1 , int c1)
{
	int i,j ;

	for(i=0 ; i < r1 ; i++ )
	  {
		 printf("  |");
		 for(j=0 ; j < c1 ; j++)
			 printf("  %d",res[i][j]);

		 printf("  |\n");
	  }
}


