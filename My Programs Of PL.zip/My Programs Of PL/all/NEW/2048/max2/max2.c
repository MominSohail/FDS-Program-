/*
 * max2.c
 *
 *  Created on: 24-Jun-2015
 *      Author: pict
 */

#include <stdio.h>

void main()

{
	int a,b,c;
	printf("\nEnter the three numbers   ");
	scanf("%d%d%d",&a,&b,&c);
	if(a > b && a > c)
		printf("\nMaxumum number is  :  %d",a);
	else if(b > a && b > c)
		printf("\nMaxumum number is  :  %d",b);
	else
		printf("\nMaxumum number is  :  %d",c);
}
