/*
 * maximum.c
 *
 *  Created on: 24-Jun-2015
 *      Author: pict
 */

#include <stdio.h>

void main()

{
	int a,max=0,i;
	printf("Enter the three numbers  ");

	for(i=0;i<3;i++)
	{
		scanf("%d",&a);
		if(a > max)
		    max = a;
	}

	printf("\nThe maximum number is  :   %d",max);
}
