/*
 * database.cpp
 *
 *  Created on: 09-Sep-2015
 *      Author: lite
 */

class database
{

};
