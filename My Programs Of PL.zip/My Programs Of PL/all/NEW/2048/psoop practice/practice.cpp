/*
 * practice.cpp
 *
 *  Created on: 03-Sep-2015
 *      Author: lite
 */

#include <iostream>
#include <string.h>

using namespace std ;

class person
{
	char *name;
	int age;

  public :

	person()
  {
		name = "Vaibhav";
		age = 19;
  }
	person(char name[],int age)
  {
		//strcpy(this->name,name);
		this->name = name;
		this->age = age;
  }

	person(const person &p)
	{
		name = new char[strlen(p.name)];
		strcpy(name,p.name);
		age = p.age;
	}

	void ChangeNameandAge(char name1[],int age1)
	{
		strcpy(this->name,name1);
		this->age = age1;
	}

	void introduce()
	{
		cout<<"Hey I am "<<name<<" I am "<<age<<" years old";
	}
};


int main()
{

	person p("Shashank",20);
	p.introduce();
	cout<<"\np\n";
	//person p1(p);
	//p1.introduce();
	//cout<<"\np1\n";
	//person p2 = p;
	//p2.introduce();
	//cout<<"\np2\n";
	person p3;
	//p3 = p;
	p3.introduce();
	return 0;
}


