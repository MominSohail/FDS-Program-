/*
 * quicksort.c
 *
 *  Created on: 03-Sep-2015
 *      Author: lite
 */

#define max 50

# include <stdio.h>
# include <string.h>
# include <ctype.h>

typedef struct
{
	char mobno[11],name[40];
	int billamount;
} mobdata;

void takeinput(mobdata[],int);
void quicksort(mobdata[],int,int,int);
int partition(mobdata[],int,int);
void show(mobdata[],int);


void main()

{
	int n,i;
	mobdata users[max],sorted[max];
	printf("\nEnter the number of elements ");
	scanf("%d",&n);

	if(n > max)
	{
		printf("\nMaximum number of users if  %d",max);
		exit(0);
	}


	takeinput(users,n);

	for(i=0 ; i<n ; i++)
		sorted[i] = users[i];

	quicksort(sorted,0,n-1,n);

	printf("\nThe sorted database is as displayed below  : ");

	show(sorted,n);
}

void takeinput(mobdata users[],int size)
{
	int i,j,flag=1;
	char ch,mobtemp[11];

	for(i=0 ; i<size ; i++ )
	{
		printf("\nEnter details for record  %d",i+1);
		printf("\nEnter Name   ");
		while ((ch = getchar()) != '\n' && ch != EOF);
		gets(users[i].name);

		flag = 1;

		while(flag)
		{
			if(flag == 1)
				printf("\nEnter 10 digit mobile number  ");
			else if(flag == 2)
				printf("\nPlease enter a valid mobile number   ");

			gets(mobtemp);

			for(j=0 ; j<10 ; j++)
				{
					if( !isdigit(mobtemp[j]) )
						break;
				}

			if(j == 10 && strlen(mobtemp) == 10)
				flag=0;
			else
				flag = 2;
		 }

		strcpy(users[i].mobno,mobtemp);

		printf("\nEnter Bill amount   ");
		scanf("%d", &users[i].billamount);
	}

}

void quicksort(mobdata a[],int lower, int upper, int n)
{
	int pivot;
	if(lower < upper)
	{
		pivot = partition(a,lower,upper);
		printf("\nAfter this pass, pivot position  :  %d",pivot+1);
		shownames(a,n);
		quicksort(a,lower,pivot-1,n);
		quicksort(a,pivot+1,upper,n);
	}
}

int partition(mobdata a[],int lower,int upper)
{
	int i,j;
	mobdata temp;
	i = lower+1;
	j = upper;

	while(i<j)
	{
		while( strcmp(a[i].name,a[lower].name) < 0 && i < upper )
			i++ ;

		while( strcmp(a[j].name,a[lower].name) > 0 && j > lower)
			j-- ;

		if(i < j)
		{
			temp = a[i];
			a[i] = a[j];
			a[j] = temp;
		}
	} // end of while(i < j)

	temp = a[j];
	a[j] = a[lower];
	a[lower] = temp;



	return j;

} // end of function


void show(mobdata a[],int n)
{
	int i;

	for(i=0 ; i < n ; i++ )
	{
		printf("\nDetails of record   %d",i+1);
		printf("\nName    :  %s",a[i].name);
		printf("\nMobile number   :  %s",a[i].mobno);
		printf("\nBill Amount    :  %d",a[i].billamount);
	}
}

void shownames(mobdata a[],int n)
{
	int i ;

	printf("\nNames are in following order   :  \n");
	for(i=0 ; i < n ; i++ )
		printf("%s        ",a[i].name);
}

