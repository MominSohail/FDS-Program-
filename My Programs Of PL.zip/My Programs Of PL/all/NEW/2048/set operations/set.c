/*
 * set.c
 *
 *  Created on: 30-Jun-2015
 *      Author: pict
 */


#include<stdio.h>

 void uni(int[],int[
					],int[],int ,int );
 void inter(int[],int[],int[],int ,int );
 void diff(int[],int[],int[],int,int);
 void sdiff(int[],int[],int[],int,int);
 void takeinput(int[],int);

 int count = 0;


 void main()

{

    int arr1[20],arr2[20],res[40],m,n,i;
    char ch = 'Y',ch1 ;

    do
      {

	     printf("Enter size of first set   ");
	     scanf("%d",&m);
	     printf("Enter size of second set  ");
	     scanf("%d",&n);
	     printf("\nEnter set A  :    \n");
	     takeinput(arr1,m);
	     printf("\nEnter set B  :  \n");
         takeinput(arr2,n);

         do
         {
			 printf("%d %d %d",m,n,count);
        	 for(i=0;i<m;i++)
				 printf("\t %d",arr1[i]);
			 for(i=0;i<n;i++)
			 	printf("\t %d",arr2[i]);
        	 printf("\n\nEnter which operation you want to perform   ");
			 printf("\n1.Union  ");
			 printf("\n2.Intersection  ");
			 printf("\n3.Difference  ");
			 printf("\n4.Symmetric difference  ");
			 printf("\nEnter the number of your choice  ");
			 scanf("%d",&i);

			 switch(i)

			   {
				  case 1:    uni(arr1,arr2,res,m,n);
							 printf("\nThe Union is   :   \n");
							 for(i=0 ; i < count ; i++)
								 printf("        %d",res[i]);
							 break;

				  case 2:    inter(arr1,arr2,res,m,n);
							 printf("\nThe Intersection is   :   \n");
							 if(count == 0)
								 printf("  NULL SET");
							 for(i=0 ; i < count ; i++)
								 printf("        %d",res[i]);
							 break;

				  case 3:    diff(arr1,arr2,res,m,n);
							 printf("\nThe Difference (A - B ) is   :   \n");
							 if(count == 0)
								 printf("  NULL SET ");
							 for(i=0 ; i < count ; i++)
								 printf("        %d",res[i]);
							 break;

				  case 4:    sdiff(arr1,arr2,res,m,n);
							 printf("\nThe Symmetric Difference (Union - Intersection) is   :   \n");
							 if(count == 0)
								 printf("  NULL SET ");
							 for(i=0 ; i < count ; i++)
								 printf("        %d",res[i]);
							 break;

				  default:   printf("\nWrong input value !!!!!  Try again .......  ");

			   }
			 printf("\nDo you want to perform some other operation with same sets  :  (Y/N)    ");
			 scanf("%s",&ch1);
         }while(ch1 == 'y' || ch1 == 'Y');

         printf("\nDo you want to perform with different sets   : (Y/N)     ");
		 scanf("%s",&ch);

      }while(ch == 'Y' || ch == 'y' );
}

void uni(int arr1[],int arr2[],int res[],int m,int n)

{
	int i,j,k=0;
	count = 0;
	for(i=0 ; i < m ; i++)
		res[i] = arr1[i];

	count = m;

	for(i=0 ; i < n ; i++)
	{
		for(j=0 ; j < m ; j++)
		{
			if(arr2[i] == arr1[j])
				break;
		}

		if(j == m)
		{
			res[m + k] = arr2[i];
		    k++;
		    count++;
		}
	}
}

void inter(int arr1[],int arr2[],int res[],int m,int n)
{
	int i,j, k=0 ;
    count = 0;
	for(i=0 ; i < m ; i++)
	{
		for(j=0 ; j < n ; j++)
		{
			if(arr1[i] == arr2[j])
				break;
		}

		if(j != n)
		{
			res[k] = arr1[i] ;
		    k++ ;
		    count ++ ;
		}

	}
}


void diff(int arr1[],int arr2[],int res[],int m,int n)
{
	int res1[20];
	int i,j,k=0,count1=0;
	count = 0;
	inter(arr1,arr2,res1,m,n);

	for(i = 0 ; i < m ; i++)
	{
		for(j = 0 ; j < count ; j++)
		{
			if(arr1[i] == res1[j])
				break;
		}

		if(j == count)
		{
			res[k] = arr1[i];
			k++ ;
			count1++;
		}
	}
	count = count1;
}

void sdiff(int arr1[],int arr2[],int res[],int m,int n)
{
    int u[40],i[20];
    count = 0 ;
    int count1 , count2;
    uni(arr1,arr2,u,m,n);
    count1 = count;
    inter(arr1,arr2,i,m,n);
    count2 = count;
    diff(u,i,res,count1,count2);
}

void takeinput(int arr[],int m)
{
	int i,j;
	for(i=0 ; i < m ; i++)
	{
		printf("Enter the element      %d     " ,i+1);
		scanf("%d",&arr[i]);
		for(j = i-1 ; j >= 0 ; j--)
		{
			if(arr[i] == arr[j])
			{
				printf("\nYou have entered a duplicate value !!!!!!!... ");
				printf("\nPlease enter again     \n");
				i-- ;
			}
		}
	}
}
