/*
 * sparse.c
 *
 *  Created on: 01-Sep-2015
 *      Author: pict
 */

#define max 100

typedef struct
{
	int row_id,col_id,value;
} sparse ;

void main()
{
	int m,n,nzero,i;
	sparse sp1[max],sp2[max],spadd[max],sptrans[max],spfast[max];
	do
	{
		printf("\nEnter what you want to perform ");
		printf("\n1.Sparse matrix addition ");
		printf("\n2.Sparse matrix transpose ");
		printf("\n3.Sparse matrix fast transpose ");
		printf("\n4.Exit ");
		sacnf("%d",&i)
		switch(i)
		{
			case 1 : 	printf("\nEnter matrix one");
						input(sp1);
						printf("\n");
						display(sp1);
						printf("\nEnter matrix two");
						input(sp2);
						printf("\n");
						display(sp2);
						add(sp1,sp2,spadd);
						display(spadd);

			case 2 :    printf("\nEnter matrix ");
						input(sp1);
						printf("\n");
						display(sp1);
						transpose(sp1,sptrans);
						display(sptrans);

			case 3 :    printf("\nEnter matrix ");
						input(sp1);
						printf("\n");
						display(sp1);
						ftranspose(sp1,sptrans);
						display(sptrans);

			case 4 : 	exit(0);

			default :   printf("\nWrong input !!!!!!!!!!");
		}

		printf("\nDo you want to perform any other operation ");
		he
	printf("\nEnter the size of matrix ");
	printf("\nEnter the number of rows ");
	scanf("%d",&m);
	printf("\nEnter the number of columns ");
	scanf("%d",&n);
	printf("\nEnter the number of non-zero elements ");
	scanf("%d",&nzero);
	sp[0].row_id = m ;
	sp[0].col_id = n ;
	sp[0].value = nzero ;

	for(i=1 ; i<=nzero ; i++)
	{
		printf("\nEnter row of non-zero element  %d",&i);
		scanf("%d",&m);
		printf("\nEnter column of non-zero element  %d",&i);
		scanf("%d",&n);
		printf("\nEnter non-zero element  %d",&i);
		scanf("%d",&nzero);
	}


}
