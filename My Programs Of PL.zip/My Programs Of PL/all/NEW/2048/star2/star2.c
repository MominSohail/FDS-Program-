/*
 * star2.c
 *
 *  Created on: 23-Jun-2015
 *      Author: pict
 */

# include <stdio.h>

void main()

{
	int n,i,j;
	printf("\nEnter the number of lines you want   :  ");
	scanf("\n%d",&n);
    for(i=1;i<=n;i++)
 	  {
		  printf("\n");
		  for(j=1;j<=i;j++)
		      printf("    *");
 	  }
}
