/*
 * star4.c
 *
 *  Created on: 23-Jun-2015
 *      Author: pict
 */

#include <stdio.h>

void main()

{
	int n,i,j;
	printf("\nEnter number of lines   :   ");
	scanf("\n%d",&n);
	for(i=1;i<=n;i++)
	{
		printf("\n");
		for(j=0;j<(n-i);j++)
			printf("   ");
		for(j=0;j<((2*i)-1);j++)
			printf("  *");
	}

}
