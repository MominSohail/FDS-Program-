/*
 * star5.c
 *
 *  Created on: 24-Jun-2015
 *      Author: pict
 */


#include <stdio.h>

void main()

{
	int i,j,n;
	printf("\nEnter number of lines you want  ");
	scanf("%d",&n);

	for(i=0;i<n;i++)
	{
		printf("\n");
		for(j=0;j<i;j++)
			printf("   ");
		for(j=0;j<( 2 * (n-i) - 1 );j++)
			printf("  *");
	}
}
