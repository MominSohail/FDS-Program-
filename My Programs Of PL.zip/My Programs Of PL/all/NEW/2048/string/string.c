/*
 * string.c
 *
 *  Created on: 24-Jun-2015
 *      Author: pict
 */

#include <stdio.h>

void main()

{
	char name[20];
	printf("\nEnter your name");
	scanf(" %s ",name);
    printf("Hello  %s ",name);
}
