/*
 * struct.c
 *
 *  Created on: 23-Jul-2015
 *      Author: pict
 */


#include <stdio.h>
#include <malloc.h>


struct student
{
	int rollno ;
	char name[30],dept[25]  ;
	float marks ;
};


void input(struct student* );
int  search(struct student* , int , int);
void displayone(struct student*);
void modify(struct student* , int, int);
void delet(struct student*,int,int);
void displayy(struct student*,int);


void main()

{
	int i,n,rn,pos,count=0;
	struct student *db ;
	char choice ;
	do
	{
		printf("\nEnter what kind of operation you want to perform   :  ");
		printf("\n1.Create a new datatbase  ");
		printf("\n2.Add a Record in existing database  ");
		printf("\n3.Search for a record in existing database   ");
		printf("\n4.Modify a record in existing database     ");
		printf("\n5.Delete a record   ");
		printf("\n6.Display Database   ");

		scanf("%d",&i);

		switch(i)
		{
		     case 1  :  if(count != 0)
		    	           free(db);
		                else
		                 {
		    	           db = (struct student*) malloc(sizeof(struct student));
		                   printf("\nDatabase Successfuly Created");
		                 }
		                   break ;

		     case 2  :  if(count == 0)
		    	           input(db);
		                else
		                 {
		                   db = (struct student*) realloc(db,(count+1)*sizeof(struct student));
		                   input(db+count);
		                 }
		                count++;
                        break ;

		     case 3  :  printf("\nEnter the roll number of the student  : ");
		    		    scanf("%d",&rn);
		    		    pos = search(db,rn,count);
		                if(pos != -1)
		                    displayone((db+pos)) ;
		                else
		                	printf("\nRecord not found !!!!!!!!!! ");
		                break;

		     case 4  :  printf("\nEnter the roll number of the student  : ");
		                scanf("%d",&rn);
		                modify(db,rn,count);
		                break;


		     case 5  :  printf("\nEnter the roll number of the student  : ");
                        scanf("%d",&rn);
                        pos = search(db,rn,count);
                        if(pos != -1)
                         {
                           delet(db,pos,count);
                           count-- ;
                         }
                        else
             	          printf("\nRecord not found !!!!!!!!!! ");
                        break;

		     case 6  :  displayy(db,count);
		                break;

		     default :  printf("\nWrong input ");
		}

		printf("\nDo you want to perform some other operation (Y/N)  ");
		scanf("%s",&choice);
	} while (choice == 'y' || choice == 'Y');
}


void input(struct student* rec)
{
	char ch ;
	printf("\nEnter Roll Number ");
	scanf("%d",&(rec->rollno));
	while ((ch = getchar()) != '\n' && ch != EOF);
	printf("\nEnter Name ");
	gets(rec->name);
	printf("\nEnter Department ");
	gets(rec->dept);
	printf("\nEnter Total Marks  ");
	scanf("%f",&(rec->marks));
}


int search(struct student* db , int rn , int count)
{
	int i ;

	for(i=0 ; i<count ; i++)
	{
		if( ((db+i)-> rollno )  == rn )
		     return i ;
    }

	return -1 ;
}

void displayone(struct student* rec)
{
	printf("\nRoll No.        :      %d",rec->rollno);
	printf("\nName            :      %s",rec->name );
	printf("\nDepartment      :      %s",rec->dept);
	printf("\nTotal Marks     :      %f",rec->marks);
}

void modify(struct student* db ,int rn,int count)
{
	int pos;
	pos = search(db,rn,count);
	if(pos != -1)
	   input(db+pos) ;
	else
	   printf("\nRecord not found !!!!!!!!!! ");

	printf("Record at position  %d succesfully modified");

}

void delet(struct student* db, int pos , int count)
{
	int i ;
	for(i=pos ; i<count-1 ; i++)
	{
		*(db+pos+i) = *(db+pos+i+1);
	}
}

void displayy(struct student* db , int count)
{
	int i;
	for(i=0;i<count;i++)
	     displayone(db+i);
}








