/*
 * student.c
 *
 *  Created on: 23-Jun-2015
 *      Author: pict
 */



#include <stdio.h>

void main()
{
	int marks[5],sum=0,i;
	float avg;

	for(i=0;i<5;i++)
	{
		printf("\nEnter marks of subject   %d \n",i+1);
		scanf("%d",&marks[i]);
		sum = sum + marks[i];
	}
    for(i=0;i<5;i++)
    	printf("\n%d  ", marks[i]);
	avg = (float)sum/5;
	printf("\nAverage is  :   %f",avg);


}
