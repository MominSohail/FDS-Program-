/*
 * switch.c
 *
 *  Created on: 17-Jun-2015
 *      Author: pict
 */


#include <stdio.h>

void main()

{
	char ch ;
	printf("\nEnter a,b,or c\n");
	scanf("%c",&ch);

	switch(ch)
	{
	   case 'a' :   printf("\nYou are in a");
	                break;

	   case 'b' :   printf("\nYou are in b");
	                break;

	   case 'c'  :  printf("\nYou are in c");
	                break;

	   default  :  printf("\nWrong input !!!!!Please Try again ");

 	}
}
