/*
 * test.c
 *
 *  Created on: 23-Jun-2015
 *      Author: pict
 */

#include <stdio.h>
#include <string.h>

void main()

{
	char ch[2];
    strcpy(ch,EOF);
	printf("%s",ch);
}
