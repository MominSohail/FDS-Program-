/*
 * type.c
 *
 *  Created on: 03-Sep-2015
 *      Author: lite
 */

# include <stdio.h>

void main(int argc,char *argv[])
{
	int i;
	char ch;

	if (argc < 2)
		printf("\nToo few arguments \n");

	else
	{

		FILE *fp;

		for(i=1;i<argc;i++)
		{
			fp = fopen(argv[i],"r");

			if(fp == NULL)
			  {
				printf("\n%s - No such file \n",argv[i]);
				continue;
			  }

			ch = getc(fp);
			while(ch != EOF)
			{
				printf("%c",ch);
				ch = getc(fp);
			}

		}
	}

}
