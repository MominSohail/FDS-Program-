#include<iostream>
using namespace std;
class person
{

	char name[25];
	char dob[6];
	char bld[3];
	int height;
	char tel[10];
	int id;
public:
	person();
	person(char name[],int id, int heights);
	person(const person &p)
	{
		name=p.name;
		id=p.id;
		height=p.height;
	}
	~person();
};
person::person() //default
{
	height=2;
	id=5;
}
person::person(char names[],int ids,int heights)
{
	name=names;
	id=ids;
	height=heights;
}
