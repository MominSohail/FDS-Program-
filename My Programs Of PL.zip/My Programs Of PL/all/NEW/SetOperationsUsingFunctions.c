/* ================================================================================
Assignment no-01
Title          : Implement following set operations using arrays.
								a) Union
								b) Intersection
								c) Difference
								d) Symmetric difference.     
Author      : Pranav Padmasali
Roll no      : 2023
Class				 : SE
Division		 : I10
Batch				 : F10
 ================================================================================*/

#include <stdio.h>
#include <stdlib.h>
#define max 100
//prototype declaration
void input(int x[],int n,int y[]);
void display(int x[],int n);
int union_set(int a[],int n1,int b[],int n2,int c[]);
int intersection(int a[],int n1,int b[],int n2,int c[]);
int difference(int x[],int n1,int y[],int n2,int c[]);
int symmetric_difference(int a[],int n1,int b[],int n2,int c1[],int c2[],int d[]);

int main(void)
{
	//declaration and initialization
	int u[max],a[max],b[max],uni[max],intr[max],diff1[max],diff2[max],symdiff[max];
	int i,n1=0,n2=0,cont,s,k=0,l=0,m=0;
	printf("\nThe universal set is\n");

	for(i=1;i<=100;i++)
    {
		 u[i]=i;
		 printf("%d, ",u[i]);
		 if(u[i]%10==0)
		 printf("\n");
	 }

	//number of elements of set and checking their validity
	printf("Enter the number of elements of set A\n");
	scanf("%d",&n1);
	while(n1>max)
	{
		printf("Size greater than universal set. Enter again. \n");
		scanf("%d",&n1);
	}
	printf("Enter the number of elements of set B\n");
	scanf("%d",&n2);
	while(n2>max)
	{
		printf("Size greater than universal set. Enter again. \n");
		scanf("%d",&n2);
	}
	//Entering elements of sets and displaying them
	printf("Enter the elements of set A");
	input(a,n1,u);
	printf("Enter the elements of set B");
	input(b,n2,u);
	printf("\nThe set A is \n");
	display(a,n1);
	printf("\nThe set B is \n");
	display(b,n2);
	printf("\n Enter the operations to be performed: \n");

	//menu for selection of operations
	    do
	    {
	     printf(" 1: union\n 2: intersection \n 3: difference\n");
	     printf(" 4: Symmetric Difference\n");
	     scanf("%d",&s);
	     switch(s)
	     {
	     case 1: 								//union of sets
	    	     printf("\nThe set A is \n");
		         display(a,n1);
		         printf("\nThe set B is \n");
		         display(b,n2);
	    	     k=union_set(a,n1,b,n2,uni);
	     	 	 printf("\nThe union of 2 sets is\n");
	     	 	 display(uni,k);
	             break;
	     case 2: 								//intersection of sets
	    	     printf("\nThe set A is \n");
		         display(a,n1);
		         printf("\nThe set B is \n");
		         display(b,n2);
	    	     k=intersection(a,n1,b,n2,intr);
	             printf("\nThe intersection of 2 sets is \n");
	             display(intr,k);
	             break;
	     case 3: 								//difference of sets
	    	     printf("\nThe set A is \n");
		         display(a,n1);
		         printf("\nThe set B is \n");
		         display(b,n2);
	    	 	 printf("\nA-B is \n");
	    	 	 l=difference(a,n1,b,n2,diff1);
	    	 	 display(diff1,l);
	    	 	 printf("\nB-A is \n");
	    	 	 m=difference(b,n2,a,n1,diff2);
	    	 	 display(diff2,m);
	    	 	 break;
	     case 4: 								//symmetric difference of sets
	    	 	 printf("\nThe set A is \n");
		    	 display(a,n1);
		    	 printf("\nThe set B is \n");
		    	 display(b,n2);
	    	     printf("\nThe symmetric difference is\n");
	     	 	 k=symmetric_difference(a,n1,b,n2,diff1,diff2,symdiff);
	     	 	 display(symdiff,k);
	     	 	 break;
	     case 5:								//To exit from program
	    	 	 return EXIT_SUCCESS;

	     }
	     printf("\n1:Continue  0:Exit");
	     scanf("%d",&cont);
	    }
	    while(cont==1);
}


//function for entering elements of sets
void input(int x[],int n,int y[])
{
	int i,j;
 for(i=0;i<n;i++)
 {
	scanf("%d",&x[i]);
	for(j=0;j<i;j++)
	  if(x[j]==x[i])                 //check duplication
	 {
	   i--;
	   printf("Already exists. Enter again");
	   break;
	  }


	 for(j=0;j<max;j++)		//Check whether it belongs to Union set
	 {
		 if(x[i]==y[j])
			 break;
	 }
	 if(j==max)
	 {
		 printf("Outside the universal set. Enter again. \n");
		 i--;
	 }

 }

}

//function for displaying elements of set
void display(int x[],int n)
{
	int i;
	if(n==0)
		printf("NULL\n");
	else
	{
		printf("(");
	  for(i=0;i<n;i++)
	   printf("{%d}, ",x[i]);
	}
}

//function for union of sets
int union_set(int a[],int n1,int b[],int n2,int c[])
{
	int i,j,k;
	 for(i=0;i<n1;i++)
	    {
	    	c[i]=a[i];
	    }
	 k=n1;
     for(i=0;i<n2;i++)
      {
	        for(j=0;j<n1;j++)
	        {
	        	if(c[j]==b[i])
	        		break;
	        }
	        if(j==n1)
	        {
	        	c[k]=b[i];
	        	k++;
	        }
      }
     return k;
}

//function for intersection of sets
int intersection(int a[],int n1,int b[],int n2,int c[])
{
	int i,j,k;
	  for(i=0,k=0;i<n1;i++)
	  {
		  for(j=0;j<n2;j++)
		  {
				  if(a[i]==b[j])
				  {
				   c[k]=a[i];
				   k++;
				  }
		  }
	  }
	  return k;
}

//function for difference of sets
int difference(int x[],int n1,int y[],int n2,int c[])
{
	int i,j,k;
	  for(i=0,k=0;i<n1;i++)
	  {
		  for(j=0;j<n2;j++)
		  {
			  if(x[i]==y[j])
				  break;
		  }
		  if(j==n2)
		  {
			  c[k]=x[i];
			  k++;
		  }
	  }
	  return k;

}

//function for symmetric difference of sets
int symmetric_difference(int a[],int n1,int b[],int n2,int c1[],int c2[],int d[])
{
	int l=difference(a,n1,b,n2,c1);
	int m=difference(b,n2,a,n1,c2);
	int n=union_set(c1,l,c2,m,d);
	return n;
}


/* Output-

The universal set is
1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
41, 42, 43, 44, 45, 46, 47, 48, 49, 50,
51, 52, 53, 54, 55, 56, 57, 58, 59, 60,
61, 62, 63, 64, 65, 66, 67, 68, 69, 70,
71, 72, 73, 74, 75, 76, 77, 78, 79, 80,
81, 82, 83, 84, 85, 86, 87, 88, 89, 90,
91, 92, 93, 94, 95, 96, 97, 98, 99, 100,
Enter the number of elements of set A
3
Enter the number of elements of set B
3
Enter the elements of set A3
3
Already exists. Enter again6
9
Enter the elements of set B5
4
5
Already exists. Enter again8

The set A is
({3}, {6}, {9},
The set B is
({5}, {4}, {8},
 Enter the operations to be performed:
 1: union
 2: intersection
 3: difference
 4: Symmetric Difference
1

The set A is
({3}, {6}, {9},
The set B is
({5}, {4}, {8},
The union of 2 sets is
({3}, {6}, {9}, {5}, {4}, {8},
1:Continue  0:Exit
1
 1: union
 2: intersection
 3: difference
 4: Symmetric Difference
2

The set A is
({3}, {6}, {9},
The set B is
({5}, {4}, {8},
The intersection of 2 sets is
NULL

1:Continue  0:Exit
1
 1: union
 2: intersection
 3: difference
 4: Symmetric Difference
3

The set A is
({3}, {6}, {9},
The set B is
({5}, {4}, {8},
A-B is
({3}, {6}, {9},
B-A is
({5}, {4}, {8},
1:Continue  0:Exit
1
 1: union
 2: intersection
 3: difference
 4: Symmetric Difference
4

The set A is
({3}, {6}, {9},
The set B is
({5}, {4}, {8},
The symmetric difference is
({3}, {6}, {9}, {5}, {4}, {8},
1:Continue  0:Exit
0
*/
