/* ============================================================================
Assignment no: 2
 Title       : Represent matrix using two dimensional arrays and perform
							following operations:
							a) Addition using pointers
							b) Multiplication without pointers
							c) Transpose using pointers
Author       : Pranav Padmasali
Roll no      : 2023
Class		     : SE
Division	   : I10
Batch		     : F10
 ==========================================================================*/
#include<stdio.h>
int **create(int rows,int col);
void init(int **matrix,int rows,int col);
void display(int **matrix,int rows,int col);
void add(int **a,int **b,int **c,int rows,int col);
void trans(int **a,int **b,int rows,int col);
void mult(int **a,int **b,int **c,int rows,int x,int col);
int main()
{
	int i,p,q,l,m,**o,**r,**s;
	do{
		printf("enter your choice\n1 addition\n2 multiplication\n3 transpose\n4 exit");
		scanf("%d",&i);
		switch(i)
		{
		case 1:		//addition
			printf("enter rows and columns of matrix 1");
			scanf("%d%d",&l,&m);
			o=create(l,m);		//dynamic memory allocation of matrix
			init(o,l,m);		//initialisation of matrix
			display(o,l,m);
			printf("enter rows and columns of matrix 2");
		    scanf("%d%d",&p,&q);
			r=create(p,q);
			init(r,p,q);
			display(r,p,q);
			if(l==p && m==q)
			{
				s=create(p,q);
				add(o,r,s,l,m);
				printf("addition of matrix is\n");
				display(s,l,m);
			}
			else
				printf("invalid matrices\n");
			break;
		case 2:		//multiplication
			printf("enter rows and columns of matrix 1");
			scanf("%d%d",&l,&m);
			o=create(l,m);		//dynamic memory allocation of matrix
			init(o,l,m);		//initialisation of matrix
			display(o,l,m);
			printf("enter rows and columns of matrix 2");
			scanf("%d%d",&p,&q);
			r=create(p,q);
			init(r,p,q);
			display(r,p,q);
			if(m==p)
			{
				s=create(l,q);
				mult(o,r,s,l,m,q);
				printf("multiplication of matrix is\n");
				display(s,l,q);
			}
			else
				printf("Invalid matrices\n");
			break;
		case 3:			//transpose
			printf("enter rows and columns of matrix 1");
			scanf("%d%d",&l,&m);
			o=create(l,m);		//dynamic memory allocation of matrix
			init(o,l,m);		//initialisation of matrix
			display(o,l,m);
			s=create(m,l);
			trans(o,s,l,m);
			printf("transpose of matrix is\n");
			display(s,m,l);
			break;
		case 4:			//exit
			break;
		default :
			printf("Enter a valid option");
			}
	}while(i!=4);
	return 0;
}
//to dynamically allocate memory to a matrix
int **create(int rows,int col)
{
	int i;
	int **matrix=(int **) malloc(rows*sizeof(int *));
	for(i=0;i<rows;i++)
	{
		matrix[i]=(int *) malloc(col * sizeof(int));
	}
	return matrix;
}
//initialising the matrix
void init(int **matrix,int rows,int col)
{
	int i,j;
	for(i=0;i<rows;i++)
	{
		for(j=0;j<col;j++)
		{
			printf("enter element %d %d\n",i+1,j+1);
			scanf("%d",*(matrix+i)+j);
		}
	}
}
//to display the matrix
void display(int **matrix,int rows,int col)
{
	int i,j;
	for(i=0;i<rows;i++)
	{
		for(j=0;j<col;j++)
		{
			printf("%d\t",*(*(matrix+i)+j));
		}
		printf("\n");
	}
}
//to add two matrices
void add(int **a,int **b,int **c,int rows,int col)
{
	int i,j;
	for(i=0;i<rows;i++)
		for(j=0;j<col;j++)
			*(*(c+i)+j)=*(*(a+i)+j) + *(*(b+i)+j);
}
//to find the transpose of a matrix
void trans(int **a,int **c,int rows,int col)
{
	int i,j;
	for(i=0;i<rows;i++)
		for(j=0;j<col;j++)
			*(*(c+j)+i)=*(*(a+i)+j);
}
//to multiply two matrices
void mult(int **a,int **b,int **c,int rows,int x,int col)
{
	int i,j,k;
	for(i=0;i<rows;i++)
	{
		for(j=0;j<col;j++)
		{
			*(*(c+i)+j)=0;
			for(k=0;k<x;k++)
			{
				*(*(c+i)+j)+=*(*(a+i)+k) * *(*(b+k)+j);
			}
		}
	}
}



/*				output
enter your choice
1 addition
2 multiplication
3 transpose
4 exit1
enter rows and columns of matrix 13
2
enter element 1 1
1
enter element 1 2
2
enter element 2 1
3
enter element 2 2
4
enter element 3 1
5
enter element 3 2
6
1	2
3	4
5	6
enter rows and columns of matrix 23
2
enter element 1 1
1
enter element 1 2
2
enter element 2 1
3
enter element 2 2
4
enter element 3 1
5
enter element 3 2
6
1	2
3	4
5	6
addition of matrix is
2	4
6	8
10	12
enter your choice
1 addition
2 multiplication
3 transpose
4 exit2
enter rows and columns of matrix 13
2
enter element 1 1
1
enter element 1 2
2
enter element 2 1
3
enter element 2 2
4
enter element 3 1
5
enter element 3 2
6
1	2
3	4
5	6
enter rows and columns of matrix 22
3
enter element 1 1
1
enter element 1 2
2
enter element 1 3
3
enter element 2 1
4
enter element 2 2
5
enter element 2 3
6
1	2	3
4	5	6
multiplication of matrix is
9	12	15
19	26	33
29	40	51
enter your choice
1 addition
2 multiplication
3 transpose
4 exit3
enter rows and columns of matrix 12
3
enter element 1 1
4
enter element 1 2
5
enter element 1 3
7
enter element 2 1
8
enter element 2 2
9
enter element 2 3
0
4	5	7
8	9	0
transpose of matrix is
4	8
5	9
7	0
enter your choice
1 addition
2 multiplication
3 transpose
4 exit1
enter rows and columns of matrix 12
3
enter element 1 1
1
enter element 1 2
2
enter element 1 3
3
enter element 2 1
4
enter element 2 2
5
enter element 2 3
6
1	2	3
4	5	6
enter rows and columns of matrix 22
2
enter element 1 1
1
enter element 1 2
2
enter element 2 1
3
enter element 2 2
4
1	2
3	4
invalid matrices
enter your choice
1 addition
2 multiplication
3 transpose
4 exit2
enter rows and columns of matrix 12
2
enter element 1 1
1
enter element 1 2
2
enter element 2 1
3
enter element 2 2
4
1	2
3	4
enter rows and columns of matrix 23
3
enter element 1 1
1
enter element 1 2
2
enter element 1 3
3
enter element 2 1
4
enter element 2 2
5
enter element 2 3
6
enter element 3 1
7
enter element 3 2
8
enter element 3 3
9
1	2	3
4	5	6
7	8	9
Invalid matrices
enter your choice
1 addition
2 multiplication
3 transpose
4 exit4

*/
