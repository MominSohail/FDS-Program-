/* ============================================================================
Assignment no: 2
 Title       : Represent matrix using two dimensional arrays and perform
							following operations:
							a) Addition using pointers
							b) Multiplication without pointers
							c) Transpose using pointers
Author       : Pranav Padmasali
Roll no      : 2023
Class		     : SE
Division	   : I10
Batch		     : F10
 ==========================================================================*/

#include<stdio.h>
#define SIZE 10
void init (int a[][SIZE],int r, int c);
void display(int a[][SIZE],int r, int c);
void mul(int A[][SIZE], int B[][SIZE],int C[][SIZE] ,int r1, int c1, int r2, int c2);
void add(int A[][SIZE], int B[][SIZE],int C[][SIZE] ,int r1, int c1, int r2, int c2);
void trans(int A[][SIZE],int r1, int c1, int C[][SIZE]);
int main()
{
	int r2,c2,r1,c1,z,key;
	int a[SIZE][SIZE],b[SIZE][SIZE],c[SIZE][SIZE];

	do {
		printf("1.MULTIPLICATION\n2.ADDITION\n3.TRANSPOSE\n4.EXIT");
		scanf("%d",&z);
	switch(z)
	{
	case 1:
		printf("Enter rows and columns of first matrix\n");
		scanf("%d%d",&r1,&c1);
		init(a,r1,c1);
		display(a,r1,c1);
		printf("Enter rows and columns of second matrix\n");
		scanf("%d%d",&r2,&c2);
		init(b,r2,c2);
		display(b,r2,c2);
		mul(a, b, c, r1, c1, r2, c2);
	break;
	case 2:
		printf("Enter rows and columns of first matrix\n");
		scanf("%d%d",&r1,&c1);
		init(a,r1,c1);
		display(a,r1,c1);
		printf("Enter rows and columns of second matrix\n");
		scanf("%d%d",&r2,&c2);
		init(b,r2,c2);
		display(b,r2,c2);
		add(a, b, c, r1, c1, r2, c2);
	break;
	case 3:
		printf("[1] Matrix A \n[2] Matrix B\n");
		printf("Enter rows and columns of first matrix\n");
		scanf("%d%d",&r1,&c1);
		init(a,r1,c1);
		display(a,r1,c1);
		trans(a,r1,c1,c);


			break;
	case 4 : break;
	default :printf("invalid option\n");
	}
	}while(z != 4);
}

void init(int a[][SIZE], int r, int c)
{
int i,j;
for(i=0;i<r;i++)
	for(j=0;j<c;j++)
		{
		printf("Enter element row=%d column=%d : \n",i+1,j+1);
		scanf("%d",&a[i][j]);
		}
}

void display (int a[][SIZE], int r,int c)
{
	int i, j;
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
			printf("%d\t",a[i][j]);
		printf("\n");
	}
}

void mul(int A[][SIZE], int B[][SIZE],int C[][SIZE],int r1, int c1, int r2, int c2)
{
	int i, j, k;
	if(c1 == r2)
	{

	printf("Multiplication is:\n");
	for(i=0; i < r1; i++)
	{
		for(j=0; j < c2; j++)
		{
			C[i][j] = 0;
			for(k=0; k < c1; k++)
				C[i][j] += A[i][k] * B[k][j];
		}
	}
	display(C,r1,c2);
	}
	else
		printf("Invalid");
}

void add(int a[][SIZE], int b[][SIZE],int c[][SIZE] ,int r1, int c1, int r2, int c2)
{
	int i,j;
	if(r1 == r2 && c1 == c2)
	{
		for(i=0;i<r1;i++)
		{
			for(j=0;j<c1;j++)
			{
				c[i][j]=a[i][j]+b[i][j];
			}
		}
	display(c,r1,c1);
	}
	else
		printf("Invalid");
}

void trans(int A[][SIZE],int r1, int c1,int C[][SIZE])
{
	int i,j;
	for(i=0;i<r1;i++)
	{
		for(j=0;j<c1;j++)
		{
			C[j][i]=A[i][j];
		}
}

	display(C,c1,r1);
}

/*				output
 1.MULTIPLICATION
2.ADDITION
3.TRANSPOSE
4.EXIT1
Enter rows and columns of first matrix
3
2
Enter element row=1 column=1 :
1
Enter element row=1 column=2 :
2
Enter element row=2 column=1 :
3
Enter element row=2 column=2 :
4
Enter element row=3 column=1 :
5
Enter element row=3 column=2 :
6
1	2
3	4
5	6
Enter rows and columns of second matrix
2
3
Enter element row=1 column=1 :
1
Enter element row=1 column=2 :
2
Enter element row=1 column=3 :
3
Enter element row=2 column=1 :
4
Enter element row=2 column=2 :
5
Enter element row=2 column=3 :
6
1	2	3
4	5	6
Multiplication is:
9	12	15
19	26	33
29	40	51
1.MULTIPLICATION
2.ADDITION
3.TRANSPOSE
4.EXIT2
Enter rows and columns of first matrix
3
2
Enter element row=1 column=1 :
1
Enter element row=1 column=2 :
2
Enter element row=2 column=1 :
3
Enter element row=2 column=2 :
4
Enter element row=3 column=1 :
5
Enter element row=3 column=2 :
6
1	2
3	4
5	6
Enter rows and columns of second matrix
3
2
Enter element row=1 column=1 :
1
Enter element row=1 column=2 :
2
Enter element row=2 column=1 :
3
Enter element row=2 column=2 :
4
Enter element row=3 column=1 :
5
Enter element row=3 column=2 :
6
1	2
3	4
5	6

2	4
6	8
10	12
1.MULTIPLICATION
2.ADDITION
3.TRANSPOSE
4.EXIT3
[1] Matrix A
[2] Matrix B
Enter rows and columns of first matrix
2
3
Enter element row=1 column=1 :
1
Enter element row=1 column=2 :
2
Enter element row=1 column=3 :
3
Enter element row=2 column=1 :
4
Enter element row=2 column=2 :
5
Enter element row=2 column=3 :
6
1	2	3
4	5	6

1	4
2	5
3	6
1.MULTIPLICATION
2.ADDITION
3.TRANSPOSE
4.EXIT4

 */
