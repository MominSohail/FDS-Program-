/*
 Perform following String operations with and without pointers
to arrays (without using the library functions) :
a)  string
b) Palindrome
c) Compare
d) Copy
e) Reverse.
  */

#include<stdio.h>
#include<string.h>

#define MAX 50
void init(char a[]);
void display(char a[]);
int length(char a[]);
void copy(char c[],char a[]);
int compare(char a[],char b[]);
void reverse(char c[],char a[]);
int palin(char a[]);
int substring(char a[],char b[]);
int main()
{
	int len,z,d,pal,j,sub;
	char a[MAX],b[MAX],c[MAX];
	printf("press 1.length of string\n2.copy a string\n3.compare two strings\n4.reverse\n5.palindrome\n6.substring\n7.exit\n");
	scanf("%d",&z);
	switch(z)
	{
	case 1:getchar();
		   init(a);
		   display(a);
		   printf("length of string %s is %d\n",a,length(a));
		   break;
	case 2:getchar();
		   init(a);
		   display(a);
		   copy(c,a);
		   printf("string A='%s' is copied in string C='%s'",a,c);
		   break;
	case 3:getchar();
		   init(a);
		   display(a);
		   init(b);
		   display(b);
		   d=compare(a,b);
		   if(d==0)
			   printf("the two strings are equal\n" );
		   else if(d>0)
			   printf("the string '%s' is alphabetically bigger than string '%s'\n",a,b);
		   else
			   printf("the string '%s' is alphabetically bigger than '%s'\n",b,a);
		   break;
	case 4:getchar();
		   init(a);
	       display(a);
	       reverse(c,a);
	       printf("the reversed string of '%s' is '%s'\n",a,c);
	       break;
	case 5:getchar();
		   init(a);
		   display(a);
		   pal=palin(a);
			if(pal==0)
				printf("the string '%s' is a palindrome",a);
			else
				printf("the string '%s' is not a palindrome",a);
		   break;
	case 6:getchar();
		   init(a);
		   display(a);
		   init(b);
		   display(b);
		   sub=substring(a,b);
		   if(sub==0)
			   printf("%s is a substring",b);
		   else
			   printf("%s is a not a substring",b);
		   break;
	case 7:break;
	default :printf("enter a valid option\n");
	}
	return 0;
}

void init(char a[])
{
	printf("Enter a string\n");
	gets(a);
}
void display(char a[])
{
	puts(a);
}
int length(char a[])
{
	int len;
	for(len=0;a[len]!='\0';len++);
	return len;
}
void copy(char c[],char a[])
{
	int i=0;
	while(i<length(a))
	{
		c[i]=a[i];
		i++;
	}
	c[i]='\0';
}
int compare(char a[],char b[])
{
	int len,i,d;
	if(length(a)>length(b))
		len=length(a);
	else
		len=length(b);
	while(len!=0)
	{
		if(a[i]!=b[i])
		{
			d=a[i]-b[i];
			break;
		}
		else
		{
			len--;
			i++;
		}
	}
	return d;
}
void reverse(char c[],char a[])
{
	int j=0,i,len;
	len=length(a);
    for(i=length(a)-1;i>=0;i--,j++)
    	c[j]=a[i];
    c[j]='\0';
}
int palin(char a[])
{
	int i;
	char c[MAX];
	reverse(c,a);
	i=compare(c,a);
	return i;

}
int substring(char a[],char b[])
{
	int i,j,c,d;
	char temp[MAX];
	for(i=0;i<length(a);i++)
	{
		c=0,d=1;
		for(j=i;j<(i+length(b));j++)
					temp[c++]=a[j];
		temp[c]='\0';
		d=strcmp(temp,b); // compare
		if(d==0)
			break;
	}
	return d;
}
