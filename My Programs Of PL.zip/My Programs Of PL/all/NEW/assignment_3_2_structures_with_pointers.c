/* ============================================================================
Assignment no: 3
 Title       : Perform following String operations with pointers
			         to arrays (without using the library functions) :
								a) Substring
								b) Palindrome
								c) Compare
								d) Copy
								e) Reverse.
Author       : Pranav Padmasali
Roll no      : 2023
Class		     : SE
Division	   : I10
Batch		     : F10
 ==========================================================================*/

#include<stdio.h>
#define max 100
int length(char *a);
void reverse(char *a,char *b);
void copy(char *a,char *b);
int compare(char *a,char *b);
void con(char *a,char *b);
int palin(char *a);
int sub(char *a,char *b);
int main()
{
	char a[max],b[max];
	int i,j;
	do{
		printf("enter your choice\n");
		printf("1.LENGTH\n2.REVERSE\n3.COPY\n4.COMPARE\n");
		printf("5.PALINDROME\n6.SUBSTRING\n7.CONCATENATE\n8.EXIT\n");
		scanf("%d",&i);
		getchar();
		switch(i)
		{
		case 1:			//length
			printf("enter a string\n");
			scanf("%[^\n]s",a);
			j=length(a);
			printf("length of string is %d\n",j);
			break;
		case 2:			//reverse
			printf("enter a string\n");
			scanf("%[^\n]s",a);
			reverse(a,b);
			printf("the reversed string is\n%s\n",b);
			break;
		case 3:			//copy
			printf("enter a string\n");
			scanf("%[^\n]s",a);
			copy(a,b);
			printf("the copied string is \n%s\n",b);
			break;
		case 4:			//compare
			printf("enter a string\n");
			scanf("%[^\n]s",a);
			printf("enter a string\n");
			getchar();
			scanf("%[^\n]s",b);
			j=compare(a,b);
			if(j<0)
				printf("Alphabetically bigger string is %s\n",b);
			else if(j>0)
				printf("Alphabetically bigger string is %s\n",a);
			else if(j==0)
				printf("Alphabetically equal strings ");
			break;
		case 5:			//palindrome
			printf("enter a string\n");
			scanf("%[^\n]s",a);
			j=palin(a);
			if(j==0)
				printf("string is a palindrome\n");
			else
				printf("string is not a palindrome\n");
			break;
		case 6:			//substring
			printf("enter a string\n");
			scanf("%[^\n]s",a);
			printf("enter a string\n");
			getchar();
			scanf("%[^\n]s",b);
			j=sub(a,b);
			if(j==0)
				printf("%s is a substring of %s\n",b,a);
			else
				printf("%s is not a substring of %s\n",b,a);
			break;
		case 7:			//concatenate
			printf("enter a string\n");
			scanf("%[^\n]s",a);
			printf("enter a string\n");
			getchar();
			scanf("%[^\n]s",b);
			con(a,b);
			printf("new string is\n%s\n",a);
			break;
		case 8:		//exit
			break;
		default:
			printf("enter a valid option");
		}
	}while(i!=8);
	return 0;
}

//to calculate length of string
int length(char *a)
{
	int i=0;
	while(*(a++)!='\0')
		i++;
	return i;
}
//to reverse a string
void reverse(char *a,char *b)
{
	int i,c=0;
	i=length(a)-1;
	while(i>=0)
		*(b + c++)=*(a + i--);
	*(b+c)='\0';
}
//to copy a string
void copy(char *a,char *b)
{
	while(*(a)!='\0')
		*(b++)=*(a++);
	*(b)='\0';
}
//to compare two strings
int compare(char *a,char *b)
{
	int i=0,d=0,c;
	c=length(a)>length(b)?length(a):length(b);
	while(c!=0)
	{
		if(*(a+i)!=*(b+i))
		{
			d=*(a+i)-*(b+i);
			break;
		}
		else
		{
			c--;
			i++;
		}
	}
	return d;
}
//to concatenate two strings
void con(char *a,char *b)
{
	int i,c=0;
	if(max<(length(a)+length(b)))
		printf("Invalid string size\n");
	else
		for(i=length(a);*(b+c)!='\0';c++)
			*(a+i+c)=*(b+c);
	*(a+i+c)='\0';
}
//to check if a string is palindrome
int palin(char *a)
{
	int i;
	char b[max];
	reverse(a,b);
	i=compare(a,b);
	return i;
}
//to check substring
int sub(char *a,char *b)
{
	int i,j,c,d;
	char temp[max];
	for(i=0;i<length(a);i++)
	{
		c=0;d=0;
		for(j=i;j<(i+length(b));j++)
		{
			*(temp+c)=*(a+j);
			c++;
		}
		*(temp+c)='\0';
		d=compare(temp,b);
		if (d==0)
			break;
	}
	return d;
}




/*									output

 enter your choice
1.LENGTH
2.REVERSE
3.COPY
4.COMPARE
5.PALINDROME
6.SUBSTRING
7.CONCATENATE
8.EXIT
1
enter a string
hello world
length of string is 11
enter your choice
1.LENGTH
2.REVERSE
3.COPY
4.COMPARE
5.PALINDROME
6.SUBSTRING
7.CONCATENATE
8.EXIT
2
enter a string
hello world
the reversed string is
dlrow olleh
enter your choice
1.LENGTH
2.REVERSE
3.COPY
4.COMPARE
5.PALINDROME
6.SUBSTRING
7.CONCATENATE
8.EXIT
3
enter a string
i am a student at pict
the copied string is
i am a student at pict
enter your choice
1.LENGTH
2.REVERSE
3.COPY
4.COMPARE
5.PALINDROME
6.SUBSTRING
7.CONCATENATE
8.EXIT
4
enter a string
hello world
enter a string
hello
Alphabetically bigger string is hello world
enter your choice
1.LENGTH
2.REVERSE
3.COPY
4.COMPARE
5.PALINDROME
6.SUBSTRING
7.CONCATENATE
8.EXIT
4
enter a string
hello
enter a string
hello
Alphabetically equal strings enter your choice
1.LENGTH
2.REVERSE
3.COPY
4.COMPARE
5.PALINDROME
6.SUBSTRING
7.CONCATENATE
8.EXIT
4
enter a string
red
enter a string
redder
Alphabetically bigger string is redder
enter your choice
1.LENGTH
2.REVERSE
3.COPY
4.COMPARE
5.PALINDROME
6.SUBSTRING
7.CONCATENATE
8.EXIT
5
enter a string
naman
string is a palindrome
enter your choice
1.LENGTH
2.REVERSE
3.COPY
4.COMPARE
5.PALINDROME
6.SUBSTRING
7.CONCATENATE
8.EXIT
6
enter a string
hello world
enter a string
hello
hello is  a substring of hello world
enter your choice
1.LENGTH
2.REVERSE
3.COPY
4.COMPARE
5.PALINDROME
6.SUBSTRING
7.CONCATENATE
8.EXIT
6
enter a string
hello world
enter a string
ello
ello is a substring of hello worldenter your choice
1.LENGTH
2.REVERSE
3.COPY
4.COMPARE
5.PALINDROME
6.SUBSTRING
7.CONCATENATE
8.EXIT
7
enter a string
hello
enter a string
world
new string is
helloworld
enter your choice
1.LENGTH
2.REVERSE
3.COPY
4.COMPARE
5.PALINDROME
6.SUBSTRING
7.CONCATENATE
8.EXIT
8
 */

