#include<stdio.h>
#define MAX 100
#include<string.h>
typedef struct student
{
	char name[50];
	int roll_no;
	char email[50];
	char mob_no[11];
}STUD;
int insert(STUD s[MAX],int size,int end);
int length(char mob_no[]);
int check(char mob_no[]);
void display(STUD s[MAX], int size);
int search(STUD s[MAX],int start,int sear);
//int modify()

int main()
{
 	int n,start,last,size,z,sear,no;
	STUD s[MAX];
	printf("Enter the size of database");
	scanf("%d",&last);
	start=insert(s,0,last);
	do
	{
	printf("Enter 1.DISPLAY DATA BASE\n2.ADD ENTRIES\n3.SEARCH ENTRIES");
	scanf("%d",&z);
	switch(z)
	{
	case 1:display(s,start);
	break;
	case 2:
		printf("number of elements to be inserted\n");
		scanf("%d",&last);
		start=insert(s,start,last);
		display(s,start);
		break;
	case 3:
		printf("enter roll no \n");
		scanf("%d",&sear);
		no = search(s,start,sear);
		if(sear==-1)
			printf("not found");
		else
		{
			printf("entry is found at no %d",no);
		}
		break;
	}
	}while(z!=0);
	return 0;
}

int insert(STUD s[MAX],int start,int last)					//create data base
{
	int l,i,j,k,flag;
//	printf("Enter the size of database");
//	scanf("%d",&size);
	for(i=start;i<start+last;i++)
	{
		//fflush(stdin);
		printf("Name : ");		//input name
		//getchar();

		scanf ( "%s", s[i].name) ;
		//gets(s[i].name);
		printf("Roll) No : ");				//input roll no
		scanf("%d",&s[i].roll_no);

		while(s[i].roll_no < 1000 || s[i].roll_no > 5000)		//validation for equal roll no
				{
					printf("Roll is not valid ");
					scanf("%d",&s[i].roll_no);
				}
		for(j=0;j<i;j++)
			{
				while(s[i].roll_no == s[j].roll_no )			//duplicate roll no validation
				{
					printf("Roll no is repeated");
					scanf("%d",&s[i].roll_no);
				}
				while(s[i].roll_no < 1000 || s[i].roll_no > 5000)		//out of range roll no
				{
					printf("Roll is not valid ");
					scanf("%d",&s[i].roll_no);
				}
			}
		printf("\nEmail : ");
		getchar();
		gets(s[i].email);


		printf("\nMobile Number : ");
		gets(s[i].mob_no);
		while(length(s[i].mob_no)!=10 ||check(s[i].mob_no))		//mobile no validation
		{
			printf("\nEnter valid mobile number : ");
			gets(s[i].mob_no);
		}
	}

		printf("\n\n");
		return start+last;
}
int length(char mob_no[])
{
	int j;
	for(j=0;mob_no[j]!='\0';j++);

	return j;
}
int check(char mob_no[] )					//check digits of mobile no
{
	int i,flag=0;
	for(i=0;i<10;i++)
	{
		if(mob_no[i] < '0' || mob_no[i] > '9')
			 {
			flag=1;
			break;
			 }
	}
	if(flag==1)
		return 1;
	else
		return 0;
}
void display(STUD s[MAX],int size)
{
	int i;
	for(i=0;i<size;i++)
	printf("sr.no %d]%s\t%d\t%s\t%s\n\n",i+1,s[i].name,s[i].roll_no,s[i].email,s[i].mob_no);
}
int search(STUD s[MAX],int start,int sear)		//to search entry ROLL NO
{
	int i,flag=0,temp;
	for(i=0;i<start;i++)
	{
			if(s[i].roll_no == sear)
			{
				flag=1;
				temp=i;
				break;
			}
	}
if(flag==1)
	return i;
else
	return -1;
}
//int modify(STUD s[MAX],)










