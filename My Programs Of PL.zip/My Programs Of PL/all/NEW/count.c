//Find out number of characters, words, spaces and sentences from a
//file and write result in another file.
#include<stdio.h>
int main(int argc,char *argv[])
{
	if ( argc != 3 )
	{
	puts ( "Improper number of arguments" ) ;
	}
	int space=0,sentence=0,word=0,chara=0;
	char ch;
	FILE *fp1,*fp2;
	fp1=fopen(argv[1],"r");
	if ( fp1== NULL )
	{
	puts ( "Cannot open  source file" ) ;
	}
	fp2=fopen ( argv[2], "w" );
	if ( fp2 == NULL )
	{
	puts ( "Cannot open target file" ) ;

	}
	while(1)
	{
		if ( ch == EOF )
		break ;
		ch = fgetc ( fp1 ) ;
		chara++;
		if(ch==' ')
		{
			space++;
			word=space+1;
		}
		if(ch=='.')
			{
			sentence++;
			word++;
			}
	}
	fprintf (fp2,"number of character=%d\n",chara) ;
	fprintf (fp2,"number of spaces=%d\n",space) ;
	fprintf (fp2,"number of words=%d\n",word) ;
	fprintf (fp2,"number of sentences=%d\n",sentence) ;
	fclose ( fp1 );
	fclose ( fp2 );
	return 0;
}
