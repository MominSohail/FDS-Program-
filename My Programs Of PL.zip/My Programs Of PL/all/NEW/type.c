#include<stdio.h>
int main ( int argc, char *argv[ ] )
{
FILE *fp1;
char ch;
if ( argc != 2 )
{
puts ( "Improper number of arguments" ) ;

}

fp1=fopen ( argv[1], "r" );
if ( fp1 == NULL )
{
puts ( "Cannot open  source file" ) ;

}

while ( 1 )
{
ch = fgetc ( fp1 ) ;
if ( ch == EOF )
break ;

}
return 0;
}