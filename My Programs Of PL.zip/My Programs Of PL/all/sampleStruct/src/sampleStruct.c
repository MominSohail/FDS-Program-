/*
 ============================================================================
 Name        : sampleStruct.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

struct add
{
	int a,b;
}n;
void main()
{
	int c;
	n.a=10;
	n.b=20;
	c=n.a+n.b;
	printf("%d",c);
}
