/*
 ============================================================================
 Name        : sorting.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>

struct student
	{
		int roll;
		char name[20];
		int mobile;
		char email[20];

	};
struct student create(void);
void display(struct student s);
int bubble(struct student St[100],int r);
int dis(struct student St[100],int r);


int main(void) {
	int r,i,c=0,sr,f=0,flag=0;
	struct student St[100];
	
while(c<7)
{
   printf("\n Enter Proper Choice :");
   printf("\n1.Create student \n 2.Display \n 3.Bubble Sort \n 4.descending order \n 5.Binary Search \n 6.Delete student \n 7.Exit \n");
   scanf("%d",&c);

   switch(c)
    {
     case 1:
    	 if(flag==0)
    	 {
            printf("how many students you have :");
	    scanf("%d",&r);
	    for(i=0;i<r;i++)
	    {
       St[i]=create();
	    }
       printf("\n student Created");
    	 }
    	 else{
    		 printf("\n DataBase Was Created ....if u want to enter records Please choose Modify option......!!!! \n");
    	 }
     break;

    case 2:
    	printf("your student Record: \n");
        printf("Roll_No  NAME  Mobile_Number  Email ");
    	for(i=0;i<r;i++){
        display (St[i]);
    	}
     break;

    case 3:
           bublle(St,r);

    	break;
    case 4:

      dis(St,r);         
 
    	break;


    case 5:
    	    	  
    	break;
    case 6:
    	
    	break;
   case 7:
      return(0);
     break;
    default :
    printf("\n Please Enter Proper Choice....!!");
    }
}
return 0;
}
struct student create()
{
       struct student S;

			printf("Enter roll_number of student :");
			scanf("%d",&S.roll);
			printf("Enter Name of student :");
			scanf("%s",S.name);
			printf("Enter mobile number of student :");
			scanf("%d",&S.mobile);
			printf("Enter Email of student :");
			scanf("%s",S.email);


          return S;
}


void display(struct student s)
{

	struct student S;
	S=s;
		printf("\n %d  %s  %d  %s \n",S.roll,S.name,S.mobile,S.email);


}


int bubble(struct student St[100],int r)
{
 int i;
struct student temp;
    	  for(i=0;i<r;i++)
    	  {
    		  if(St[i].roll>St[i+1].roll)
    		  {
    			 temp=St[i];
    			 St[i]=St[i+1];
    			 St[i+1]=temp;
    		  }
    	  }
    	  printf("\n Your Sorted Array Is : \n ");
    	  for(i=0;i<r;i++){
    	          display (St[i]);
    	      	}
return 0;

}


int dis(struct student St[100],int r)
{
struct student Stemp;
int i,j,s;
char g[20];

while(r=0)
for(i=0;i<r;i++)
{
    s=strcmp(St[i].name,St[i+1].name);
    if(s=1)
{
      g[20]=St[i].name; 
}
else if(s=-1)
{
   g[20]=St[i+1].name;
}
else if(s=0)
{
    g[20]=St[i].name; 
}
} 
for(i=0;i<r;i++)
    	{
    	  if(St[i].name==g)
    	{
            Stemp = St[r];
             St[r]=St[i];
             St[i]=Stemp;
               	       r--;
    	           
            
    	}
    	}
    	 


     printf("\n Your Sorted Array by name in descending order: \n ");
    	  for(i=r;i>=0;i--){
    	          display (St[i]);
    	      	}
return 0;
}

