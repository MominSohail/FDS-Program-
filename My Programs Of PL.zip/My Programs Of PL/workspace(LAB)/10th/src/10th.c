/*
 ============================================================================
 Name        : 10th.c
 Author      : SOHAIl
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
struct poly
{
	int coff;
	int power;
	struct poly *next;
};
void display(struct poly *head);
struct poly *create(struct poly *head);
struct poly *add(struct poly *head);
int main(void) {

	int n,i;
	struct poly *head=NULL,*headA=NULL,*n_node,*p_node;


	head=create(head);


     display(head);

     headA=create(head);

     printf("Addition of Polynomial");
     display(headA);
	return EXIT_SUCCESS;
}

struct poly *create(struct poly *head)
{
	int n;
	printf("Enter Total Number of Terms of Polynomial :");
		scanf("%d",&n);
	int i;
	struct poly *n_node,*p_node;
	for(i=1;i<=n;i++)
			{
				if(head==NULL)
				{
				n_node=head=(struct poly*)malloc(sizeof(struct poly));
				head->next=head;
						//n_node->next=n_node;
				}
				else
				{

				   n_node->next=(struct poly*)malloc(sizeof(struct poly));
				   n_node=n_node->next;

				}
				n_node->next=head;
				printf("Enter coeffient and Power of Each Term of Polynomial (C/P):");
						scanf("%d %d",&n_node->coff,&n_node->power);
			}
	       printf("Polynomial stored");
	       return head;
}


void display(struct poly *head)
{
	printf("Your Polynomial :");
	struct poly *p1;
	p1=head;
	int i=0;
	printf("%dX^%d + ",p1->coff,p1->power);
	while(p1->next!=head)
		{
		i++;

			p1=p1->next;
			printf("%dX^%d ",p1->coff,p1->power);
		}

}

struct poly *add(struct poly *head)
{
	struct poly *head2=NULL,t1,t2,*n_node,*headr;
	printf("Enter Second Polynomial for Adding");
	head2=create(head2);
	t1=head;
	t2=head2;
	while(t1->next!=head && t2->next!=head2)
	{
		if(t1->power==t2->power)
		{
			if(headr==NULL)
							{
							n_node=head=(struct poly*)malloc(sizeof(struct poly));
							headr->next=headr;
									//n_node->next=n_node;
							}
							else
							{

							   n_node->next=(struct poly*)malloc(sizeof(struct poly));
							   n_node=n_node->next;

							}
							n_node->next=headr;
							n_node->coff=t1->coff+t2->coff;
							n_node->power=t1->power;
		       t1=t1->next;
		       t2=t2->next;

		}
		else if(t1->power<t2->power)
		{
			if(headr==NULL)
										{
										n_node=head=(struct poly*)malloc(sizeof(struct poly));
										headr->next=headr;
												//n_node->next=n_node;
										}
										else
										{

										   n_node->next=(struct poly*)malloc(sizeof(struct poly));
										   n_node=n_node->next;

										}
										n_node->next=headr;
										n_node->coff=t2->coff;
										n_node->power=t2->power;
										t2=t2->next;
		}
		else if(t1->power>t2->power)
		{
			if(headr==NULL)
													{
													n_node=head=(struct poly*)malloc(sizeof(struct poly));
													headr->next=headr;
															//n_node->next=n_node;
													}
													else
													{

													   n_node->next=(struct poly*)malloc(sizeof(struct poly));
													   n_node=n_node->next;

													}
													n_node->next=headr;
													n_node->coff=t1->coff;
													n_node->power=t1->power;
													t1=t1->next;
		}

	}
	while(t1->next!=head)
	{
		if(headr==NULL)
															{
															n_node=head=(struct poly*)malloc(sizeof(struct poly));
															headr->next=headr;
																	//n_node->next=n_node;
															}
															else
															{

															   n_node->next=(struct poly*)malloc(sizeof(struct poly));
															   n_node=n_node->next;

															}
															n_node->next=headr;
															n_node->coff=t1->coff;
															n_node->power=t1->power;
															t1=t1->next;
	}
	while(t2->next!=head2)
	{
		if(headr==NULL)
												{
												n_node=head=(struct poly*)malloc(sizeof(struct poly));
												headr->next=headr;
														//n_node->next=n_node;
												}
												else
												{

												   n_node->next=(struct poly*)malloc(sizeof(struct poly));
												   n_node=n_node->next;

												}
												n_node->next=headr;
												n_node->coff=t2->coff;
												n_node->power=t2->power;
												t2=t2->next;
	}
	return headr;
}
