/*
 ============================================================================
 Name        : 4th.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

struct record
	{
		int roll;
		char name[20];
		int marks;
		int mobile;
		char email[20];

	};
void create(struct record d[100], int r);
void display(struct record Di[100], int r);
void add(struct record Da[100], int r);
void search(struct record Da[100], int r,int s);
void del(struct record Da[100], int r,int d);
int main(void) {
	int r,i,j,s,de;
    struct record data[100];
	printf("how many Records you have :");
	scanf("%d",&r);

	create(data,r);

	display(data,r);

	add(data,r);
	printf("\n Enter Which Record u Want to search:");
	scanf("%d",&s);
	search(data,r,s);
	printf("\n Enter Which Record u Want to Delete:");
		scanf("%d",&de);
		del(data,r,de);
}

void create(struct record d[100], int r)
{
	int i;
	for(i=0;i<r;i++)
		{
			printf("Enter your roll_number :");
			scanf("%d",&d[i].roll);
			printf("Enter Name:");
			scanf("%s",&d[i].name);
			printf("Enter marks:");
			scanf("%d",&d[i].marks);
			printf("Enter mobile number:");
			scanf("%d",&d[i].mobile);
			printf("Enter Email:");
			scanf("%s",&d[i].email);

		}
}
void display(struct record Di[100], int r)
{
	int i;
	printf("your Record: \n");

	printf("Roll_No  NAME  Marks  Mobile_Number  Email ");

	for(i=0;i<r;i++)
	{

		printf("\n%d %s %d %d %s",Di[i].roll,Di[i].name,Di[i].marks,Di[i].mobile,Di[i].email);

	}
}

void add(struct record Da[100], int r)
{
	/*while(Da[i]=!'\0')
	{ i++;
		h=i;
	}*/
	int h=r;
				printf("Enter your roll_number :");
				scanf("%d",&Da[h].roll);
				printf("Enter Name:");
				scanf("%s",&Da[h].name);
				printf("Enter marks:");
				scanf("%d",&Da[h].marks);
				printf("Enter mobile number:");
				scanf("%d",&Da[h].mobile);
				printf("Enter Email:");
				scanf("%s",&Da[h].email);
			 printf("Record Saved...1");
                h++;
			 display(Da,h);
}
void search(struct record Da[100], int r,int w)
{
	int i;
  for(i=0;i<r;i++)
  {
	  if(Da[i].roll=!w)
	  {
		  printf("\n Record Not Found");

	  }
	  else
	  {

		  printf("Roll-No=%d Name=%s Marks=%d Mobile_Number=%d Email=%s",Da[i].roll,Da[i].name,Da[i].marks,Da[i].mobile,Da[i].email);

	  }
  }
}

void del(struct record Da[100], int r,int d)
{
	int i,h,j;
	for(i=0;i<r;i++)
	  {
		  if(Da[i].roll=!d)
		  {
			  printf("\n Record Not Found");
		  }
		  else
		  { for(j=i;j<r;j++)
		  {
			  Da[j]=Da[j+1];
			  j=j+1;
			  h=j;
		  }
		  printf("Record Delete...");
		  printf("After Deletion...");

			  display(Da,h);
			  //printf("Roll-No.=%d Name=%s Marks=%d Mobile_Number=%d Email=%s",Da[i].roll,Da[i].name,Da[i].marks,Da[i].mobile,Da[i].email);


		  }
	  }

}
