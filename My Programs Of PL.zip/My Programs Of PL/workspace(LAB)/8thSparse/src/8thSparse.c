/*
 ============================================================================
 Name        : 8th.c
 Author      : SOHAIL
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
void createS(int s[20][3],int m,int n);
void display(int s[20][3]);

void addsm(int a[20][3],int b[20][3],int r[20][3]);
void tran(int a[20][3],int b[20][3]);
void fast_transpose (int a[20][3], int b[20][3]);

int main(void) {
	int ch=0,m,n,m1,n1,f=0;
int sm1[20][3],sm2[20][3],ad[20][3],T[20][3],ft[20][3];

printf("Enter row and column of Actual Matrix (R C)");
	scanf("%d %d",&m,&n);
	sm1[0][0]=m;
	sm1[0][1]=n;
  createS(sm1,m,n);
  display(sm1);
  while(ch<4)
  {
	  printf("\n1.Addition of Sparse Matrix \n2.Simple Transpose \n3.Fast Transpose\n4.Exit");
	  printf("Enter Your Choice :");
	  scanf("%d",&ch);
	  switch(ch)
	  {
	  case 1:

		  while(f==0)
		  {
		  printf("Enter row and column of Adding Second Matrix (R C)");
		  	scanf("%d %d",&m1,&n1);
		  	if(m==m1 && n==n1)
		  	{
		  		f=1;
		  	sm2[0][0]=m1;
		  	sm2[0][1]=n1;
		    createS(sm2,m1,n1);
		    printf("your Second Sparse Matrix is :\n");
		    display(sm2);
		  	}
		  	if(f==0)
		  	{
		  		printf("in Addition of matrix Both matrix's Row And Column should be Equal");
		  	}
		  }
		  addsm(sm1,sm2,ad);
		  printf("\nAddition of Your Matrix is :\n");
		  display(ad);

		  break;
	  case 2:
	  	  tran(sm1,T);
	  	    printf("\nAfter Simple Transpose :\n ");
	  	    display(T);
	  	  break;
	  case 3:
		  fast_transpose(sm1,ft);
		  printf("\nAfter Fast Transpose :\n ");
		  	  	    display(ft);
		  break;
	  }
  }


	return EXIT_SUCCESS;
}

void addsm(int a[20][3],int b[20][3],int r[20][3])
{
	int i=1,j=1,k=1,t1,t2;
	r[0][0]=a[0][0];
	r[0][1]=a[0][1];
	t1=a[0][2];
	t2=b[0][2];
	while(i<=t1 && j<=t2)
	{
		if(a[i][0]<b[j][0])
		{
			r[k][0]=a[i][0];
			r[k][1]=a[i][1];
			r[k][2]=a[i][2];
			k++;
			i++;
		}
		else if(a[i][0]>b[j][0])
		{
			r[k][0]=b[i][0];
						r[k][1]=b[i][1];
						r[k][2]=b[i][2];
						k++;
						j++;
		}
		else if(a[i][1]<b[j][1])
		{
			r[k][0]=a[i][0];
						r[k][1]=a[i][1];
						r[k][2]=a[i][2];
						k++;
						i++;
		}
		else if(a[i][1]>b[j][1])
				{
					r[k][0]=b[i][0];
								r[k][1]=b[i][1];
								r[k][2]=b[i][2];
								k++;
								j++;
				}
		while(i<=t1)
		{

			r[k][0]=a[i][0];
			r[k][1]=a[i][1];
			r[k][2]=a[i][2];
			k++;
			i++;

		}
		while(j<=t2)
		{
			r[k][0]=b[i][0];
			r[k][1]=b[i][1];
			r[k][2]=b[i][2];
			k++;
			j++;
		}
	}
	r[0][2]=k-1;
}


void createS(int s[20][3],int m,int n)
{
	int t,i;

	printf("Enter total number of non-zero elements of matrix :\n");
	scanf("%d",&t);
	s[0][2]=t;
	printf("Enter Row Column and Non-zero value As:\n ");

	for(i=1;i<=t;i++)
	{
		printf("Row :");
		scanf("%d",&s[i][0]);
		printf("Column:");
		scanf("%d",&s[i][1]);
		printf("Value :");
				scanf("%d",&s[i][2]);
	}

}

void display(int s[20][3])
{
	int i,n;
	n=s[0][2];
	printf("TotalRow= %d Total Columns =%d AND Total Non-zero Elements= %d \n", s[0][0],s[0][1],s[0][2]);
	printf("Row Column value");
	for(i=1;i<=n;i++)
	{
		printf("\n %d    %d      %d",s[i][0],s[i][1],s[i][2]);
	}
}
void tran(int a[20][3],int t[20][3])
{

	int c,r,n,k=1;
	t[0][0]=a[0][1];
	t[0][1]=a[0][0];
	t[0][2]=a[0][2];

	n=a[0][2];
	if(n>0)
	{
	for(c=0;c<a[0][1];c++)
	{
		for(r=1;r<=n;r++)
		{
			if(c==a[r][1])
			{
				t[k][0]=c;
				t[k][1]=a[r][0];
				t[k][2]=a[r][2];
				k++;
			}
		}
	}
	}
}

void fast_transpose (int a[20][3], int b[20][3])
{
  int num_cols,num_terms,i,j;
  int row_terms[20],starting_pos[20];
      num_cols = a[0][1];
      num_terms = a[0][2];
b[0][0] = num_cols;
b[0][1] = a[0][0];
b[0][3] = num_terms;
printf("number of terms = %d",b[0][3]);
if (num_terms > 0)
{
for (i = 0; i < num_cols; i++)

{
	row_terms[i] = 0;
}
for (i = 1; i <= num_terms; i++)
{
row_terms[a[i][1]]=1+row_terms[a[i][1]];
}
for (i = 1; i <= num_terms; i++)
{
	printf("\n %d",row_terms[i]);
//row_terms[a[i][1]]=1+row_terms[a[i][1]];
}
starting_pos[0] = 1;

for (i =1; i < num_cols; i++)

{starting_pos[i]=starting_pos[i-1] +row_terms [i-1];}

for (i=1; i <= num_terms; i++)
{
j = starting_pos[a[i][1]];
b[j][0] = a[i][1];
b[j][1] = a[i][0];
b[j][3] = a[i][3];
starting_pos[a[i][1]]++;
}
}
}
