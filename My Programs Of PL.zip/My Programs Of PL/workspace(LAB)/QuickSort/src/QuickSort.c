/*
 ============================================================================
 Name        : sorting.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>

struct student
	{
		int roll;
		char name[20];
		int mobile;
		char email[20];

	};
struct student  create(void);
void display(struct student  s);
int quick(struct student  St[100],int lb,int ub);


int main(void) {int roll;
char name[20];
int mobile;
char email[20];

	int r,i,f=0,flag=0;
	int s;
	struct student  St[100];

while(s<5)
{
   printf("\n Enter Proper Choice :");
   printf("\n1.Create student  \n 2.Display \n 3.Quick Sort  \n 4.Exit \n");
   scanf("%d",&s);

   switch(s)
    {
     case 1:
    	 if(flag==0)
    	 {
            printf("how many students you have :");
	    scanf("%d",&r);
	    for(i=0;i<r;i++)
	    {
       St[i]=create();
	    }
       printf("\n student  Created");
    	 }
    	 else{
    		 printf("\n DataBase Was Created ....if u want to enter records Please choose Modify option......!!!! \n");
    	 }
     break;

    case 2:
    	printf("your student  Record: \n");
        printf("Roll_No  NAME  Mobile_Number  Email ");
    	for(i=0;i<r;i++){
        display (St[i]);
    	}
     break;

    case 3:  printf("At sort..");

             quick(St,0,r);
             printf("your  student  Record After Quick Sort: \n");
             printf("Roll_No  NAME  Mobile_Number  Email ");
         	for(i=0;i<r;i++){
             display (St[i]);
         	}
    	break;


    default :
    printf("\n Please Enter Proper Choice....!!");

}
}
return 0;
}


struct student  create()
{
       struct student  S;

			printf("Enter roll_number of student  :");
			scanf("%d",&S.roll);
			printf("Enter Name of student  :");
			scanf("%s",S.name);
			printf("Enter mobile number of student  :");
			scanf("%d",&S.mobile);
			printf("Enter Email of student  :");
			scanf("%s",S.email);


          return S;
}


void display(struct student  s)
{

	struct student  S;
	S=s;
		printf("\n %d  %s  %d  %s \n",S.roll,S.name,S.mobile,S.email);


}


int quick(struct student  St[100],int lb,int ub)
{
	int j=0;
printf("At sort..");
	if(lb<ub)
	{
	 j=partition(St,1,ub);
	 quick(St,lb,j-1);
         quick(St,j+1,ub);
	}

	return 0;
}
int partition(struct student  St[100],int l,int u)
	{
	int i,j,s;
	char pv[20],g[20];
	struct student  temp;
	pv[20]=St[0].name;


	i=l;
	u=u+1;
	do
	{
	do
	{
		s=strcmp(pv,St[i].name);
		i++;

	}while(s>=0 && i<=u);
	do
	{
		j--;
		if(i<j)
		{
			temp=St[j];
			St[j]=St[i];
			St[i]=temp;
		}
	}while(s<0);
	}while(i<j);
        temp=St[l];
	St[l]=St[j];

	St[j]=temp;
	   return j;
	}
