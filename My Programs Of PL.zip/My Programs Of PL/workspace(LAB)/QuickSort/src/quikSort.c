/*
 ============================================================================
 Name        : sorting.c
 Author      :
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include<string.h>
struct mobileUser
	{

		char name[20];
		int mobile;
		float bill;

	};
struct mobileUser create(struct mobileUser S);
void display(struct mobileUser S);
void quick(struct mobileUser  St[100],int l,int u);
int partition(struct mobileUser St[100],int l,int u);


int main(void) {
	int r,i,c=0;
	struct mobileUser St[100];
  int lb=0;
while(c<=3)
{
   printf("\n Enter Proper Choice :");
   printf("\n1.Create mobileUser  \n 2.Display \n 3.Quick Sort  \n 4.Exit \n");
   scanf("%d",&c);

   switch(c)
    {
     case 1:

                 printf("how many Mobile User U have you have :");
	               scanf("%d",&r);
	             for(i=0;i<r;i++)
	                 {
                      St[i]=create(St[i]);
	                  }
                      printf("\n mobileUser  Created");
    	 break;
      case 2:
    	          printf("your mobileUser  Record: \n");
                   printf("NAME  Mobile_Number  Bill_amount ");
    	          for(i=0;i<r;i++){
                        display (St[i]);
    	                }

    	  break;

       case 3:
    	              printf("At sorting..");
                       quick(St,lb,r-1);

                     printf("your Sorted mobileUser  Record: \n");
                     printf("Roll_No  NAME  Mobile_Number  Email ");
    	              for(i=0;i<r;i++){
                            display (St[i]);
    	                       }
    	              break;
       case 4:
    	    return 0;
    	    break;

       default :
                      printf("\n Please Enter Proper Choice....!!");

          }
    }
return 0;
}
struct mobileUser  create(struct mobileUser S)
{

         	printf("Enter Name of mobileUser  :");
			scanf("%s",S.name);
			printf("Enter mobile number of mobileUser  :");
			scanf("%d",&S.mobile);
			printf("Enter Bill Amount  of mobileUser  :");
			scanf("%f",&S.bill);
      return S;
}


void display(struct mobileUser S)
{


		printf("\n %s  %d  %f \n",S.name,S.mobile,S.bill);


}


void quick(struct mobileUser St[100], int lb, int ub)
{
	int j;
	if(lb<ub)
{

    j =partition(St,lb,ub);
    quick(St,lb,j-1);
    quick(St,j+1,ub);
}

}

int partition(struct mobileUser St[100], int l,int u)
{
    int i,j,s;
   char v[20];
  struct mobileUser  temp;
  strcpy(v,St[l].name);
  //v[20]=St[l].name;
  i=l;
  j=u+1;
  while(i<j)
  {
	  while(s<=0 && i<=u)
	  {
		  i++;
		  s=strcmp(v,St[i+1].name);

	  }
	  while(s>0)
	  {
		  j--;
	  }
	  if(i<j)
	            {
	                temp=St[i];
	                St[i]=St[j];
	                St[j]=temp;
	             }
  }
    St[l]=St[j];
          St[j]=St[0];
         return(j);
}









