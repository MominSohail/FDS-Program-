#include <stdio.h>
#include <stdlib.h>
#define MAX 4

void input(int a[][MAX],int r1,int c1);
void Mat_mul(int (*p)[MAX],int r1,int c2,int r2,int (*q)[MAX],int (*r)[MAX]);
void display(int *p,int r,int c);
void Mat_add(int (*p)[MAX],int r,int c,int (*q)[MAX],int (*res)[MAX]);
void Mat_trans(int (*p)[MAX],int r,int c,int (*q)[MAX],int (*res)[MAX]);
int main(void) {

int r1,c1,r2,c2;

int a[MAX][MAX],b[MAX][MAX],c[MAX][MAX];
printf("enter the number of rows and columns");
scanf("%d %d",&r1,&c1);
input(a,r1,c1);
printf("enter the number of rows and columns");
scanf("%d %d",&r2,&c2);

   input(b, r2, c2);
printf("\n Your First Matrix");
   display(a, r1, c1);

   printf("\n Your Second Matrix");
   display(b, r2, c2);

   printf("\n Addition of given matrix: \n ");
   Mat_add(a,r1,c1,b,c);

   display(c,r1,c1);

   printf("\n  Multiplication of given matrix : \n ");
   Mat_mul(a,r1,c2,r2,b,c);

   display(c,r1,c2);

   Mat_trans(a,r1,c1,b,c);
   printf("\n Your Matrix After Transpose :");
   display(c,r1,c1);

return EXIT_SUCCESS;
}
void input(int a[][MAX],int r1,int c1)
{
int i,j;
printf("enter the elements of the matrix(row-wise)");
for(i=0;i<r1;i++)
    {
         for(j=0;j<c1;j++)
          {
              scanf("%d",&a[i][j]);
              }
    }
}

void display(int *p,int r,int c)
{
   int i,j;
   for(i=0;i<r;i++)
     {
       for(j=0;j<c;j++)
         { printf("%u\t",*(p+(i*MAX)+j));
           printf("\n");}
     }
}

void Mat_add(int (*p)[MAX],int r1,int c1,int (*q)[MAX],int (*r)[MAX])
{
      int i,j;
       int *t,*l,*m;
for(i=0;i<r1;i++)
{
    t=p+i;
    l=q+i;
    m=r+i;
   for(j=0;j<c1;j++)
   *(m+j) = *(t+j) + *(l+j);
}
}

void Mat_mul(int (*p)[MAX],int r1,int c2,int r2,int (*q)[MAX],int (*res)[MAX])
{
int i,j,k;
for(i=0;i<r1;i++)
{
    for(j=0;j<c2;j++)
  {
     *(*(res+i)+j)=0;
    for(k=0;k<r2;k++)
    {

    	*(*(res+i)+j)+=*(*(p+i)+j) * *(*(q+i)+j);
     }
  }
}
}

void Mat_trans(int (*p)[MAX],int r,int c,int (*q)[MAX],int (*res)[MAX])
{
	 int i,j;
for (i=0;i<r;i++)
{
	 for(j=0;j<c;j++)
	 {
		 *(*(res+i)+j)=*(*(p+j)+i);
	 }

}

}
